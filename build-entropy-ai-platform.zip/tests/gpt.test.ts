import { describe, expect, it } from "vitest";
import { GPT, countParams } from "../src/lib/entropy/gpt";
import { KVSession, generateCandidates, sample } from "../src/lib/entropy/generate";
import { RESEARCH_50M } from "../src/lib/entropy/registry";

const cfg = { vocabSize: 23, ctx: 8, dModel: 8, nLayer: 2, nHead: 2, dFF: 16 };

function batch() {
  const B = 2, T = 6;
  const inp = new Int32Array(B * T), tgt = new Int32Array(B * T);
  for (let i = 0; i < B * T; i++) { inp[i] = (i * 7 + 3) % cfg.vocabSize; tgt[i] = (i * 5 + 1) % cfg.vocabSize; }
  tgt[3] = -1; // masked position must be ignored
  return { B, T, inp, tgt };
}

describe("Entropy Transformer", () => {
  it("analytic gradients match finite differences", () => {
    const m = GPT.init(cfg, 42);
    // move away from the tiny-init regime so gradients are well above float32 noise
    for (let i = 0; i < m.params.length; i++) m.params[i] += Math.sin(i * 12.9898) * 0.3;
    const { B, T, inp, tgt } = batch();
    m.forward(inp, tgt, B, T);
    m.zeroGrad();
    m.backward();
    const grads = new Float32Array(m.grads!);
    const eps = 1e-2;
    let maxRel = 0;
    // probe a spread of parameters across every tensor
    for (let k = 0; k < 60; k++) {
      const i = Math.floor((k / 60) * m.params.length);
      const orig = m.params[i];
      m.params[i] = orig + eps; const lp = m.forward(inp, tgt, B, T);
      m.params[i] = orig - eps; const lm = m.forward(inp, tgt, B, T);
      m.params[i] = orig;
      const num = (lp - lm) / (2 * eps);
      const denom = Math.max(1e-2, Math.abs(num) + Math.abs(grads[i]));
      maxRel = Math.max(maxRel, Math.abs(num - grads[i]) / denom);
    }
    expect(maxRel).toBeLessThan(0.05);
  });

  it("training reduces loss (the model genuinely learns)", () => {
    const m = GPT.init(cfg, 1);
    const { B, T, inp, tgt } = batch();
    const first = m.forward(inp, tgt, B, T);
    let last = first;
    for (let s = 0; s < 80; s++) { last = m.forward(inp, tgt, B, T); m.zeroGrad(); m.backward(); m.step({ lr: 1e-2 }); }
    expect(last).toBeLessThan(first * 0.5);
  });

  it("KV-cache decoding matches the full forward pass", () => {
    const m = GPT.init(cfg, 7);
    const toks = [1, 5, 9, 2, 7];
    m.forward(Int32Array.from(toks), null, 1, toks.length);
    const full = m.lastLogits!.slice((toks.length - 1) * cfg.vocabSize);
    const s = new KVSession(m);
    const inc = s.prefill(toks);
    for (let i = 0; i < cfg.vocabSize; i++) expect(inc[i]).toBeCloseTo(full[i], 4);
  });

  it("best-of-N generation respects budget and context", () => {
    const m = GPT.init(cfg, 3);
    const cands = generateCandidates(m, [1, 2], 4, 3, new Set([0]), { temperature: 0.8, topK: 5, topP: 0.9, repetitionPenalty: 1.1, seed: 1 });
    expect(cands).toHaveLength(3);
    for (const c of cands) { expect(c.tokens.length).toBeLessThanOrEqual(4); expect(Number.isFinite(c.meanLogProb)).toBe(true); }
  });

  it("blocks immediate token repeats and repeated trigrams", () => {
    const logits = new Float32Array(8);
    logits[4] = 20;
    logits[5] = 10;
    const opts = { temperature: 0, topK: 8, topP: 1, repetitionPenalty: 1, noRepeatNgramSize: 3 };
    const repeatedTrigram = sample(logits, [2, 3, 4, 2, 3], opts, () => 0.5, undefined, [2, 3, 4, 2, 3]);
    expect(repeatedTrigram).toBe(5);
    const immediateRepeat = sample(logits, [4], opts, () => 0.5, undefined, [4]);
    expect(immediateRepeat).toBe(5);
  });

  it("research config is ~50M parameters", () => {
    const n = countParams(RESEARCH_50M);
    expect(n).toBeGreaterThan(45e6);
    expect(n).toBeLessThan(55e6);
  });
});
