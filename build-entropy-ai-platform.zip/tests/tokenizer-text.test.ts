import { describe, expect, it } from "vitest";
import { BPETokenizer } from "../src/lib/entropy/tokenizer";
import { chunkText, cosine, embed, summarize } from "../src/lib/entropy/text";
import { buildPrompt } from "../src/lib/entropy/context";

const corpus = "The quick brown fox jumps over the lazy dog. ".repeat(30) + "function add(a, b) { return a + b; }\n".repeat(20);

describe("BPE tokenizer", () => {
  const tok = BPETokenizer.train(corpus, 300);
  it("learns merges and compresses text", () => {
    expect(tok.vocabSize).toBeGreaterThan(263);
    expect(tok.encode(corpus).length).toBeLessThan(new TextEncoder().encode(corpus).length / 2);
  });
  it("round-trips arbitrary unicode", () => {
    const s = "Entropy café — naïve 東京 <|user|> done";
    expect(tok.decode(tok.encode(s, false), false)).toBe(s);
  });
  it("encodes special tokens atomically", () => {
    const ids = tok.encode("<|user|>hi<|end|>");
    expect(ids[0]).toBe(tok.special("<|user|>"));
    expect(ids[ids.length - 1]).toBe(tok.special("<|end|>"));
  });
  it("serialises", () => {
    const t2 = BPETokenizer.fromJSON(JSON.parse(JSON.stringify(tok.toJSON())));
    expect(t2.encode("lazy fox")).toEqual(tok.encode("lazy fox"));
  });
});

describe("embeddings and retrieval", () => {
  it("ranks related text higher", () => {
    const q = embed("how do transformers use attention");
    const a = embed("Transformers rely on self-attention to mix token information.");
    const b = embed("The recipe needs two cups of flour and an egg.");
    expect(cosine(q, a)).toBeGreaterThan(cosine(q, b));
  });
  it("chunks long text", () => {
    const text = Array.from({ length: 40 }, (_, i) => `Paragraph ${i} talks about topic number ${i} in some detail.`).join("\n\n");
    const chunks = chunkText(text, 300);
    expect(chunks.length).toBeGreaterThan(3);
  });
  it("summarises extractively (only sentences from the source)", () => {
    const text = "Solar power converts sunlight into electricity. Panels use photovoltaic cells. Wind power uses turbines. Solar power adoption grew quickly in the last decade. Cats are popular pets in many homes.";
    const s = summarize(text, 2);
    for (const x of s) expect(text).toContain(x);
  });
});

describe("context manager", () => {
  const tok = BPETokenizer.train(corpus, 300);
  it("keeps the prompt within the window and drops the oldest turns first", () => {
    const history = Array.from({ length: 30 }, (_, i) => ({ role: (i % 2 ? "assistant" : "user") as "user" | "assistant", content: `turn ${i} the quick brown fox` }));
    const r = buildPrompt(tok, { ctx: 256, reserve: 64, history, context: [], memories: [], system: "Entropy" });
    expect(r.tokens.length).toBeLessThanOrEqual(256 - 64);
    expect(r.droppedTurns).toBeGreaterThan(0);
    expect(tok.decode(r.tokens)).toContain("turn 29");
  });
});
