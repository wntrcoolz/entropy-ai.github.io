"use client";

import { useEffect, useRef, useState } from "react";
import { COMING_MODELS, LEVELS, MODELS, type LevelId, type ModelId } from "@/lib/entropy/registry";
import { IconCheck, IconChevron } from "../icons";

export function ModelPicker({ model, level, onModel, onLevel }: { model: ModelId; level: LevelId; onModel: (m: ModelId) => void; onLevel: (l: LevelId) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const spec = MODELS.find((m) => m.id === model)!;
  const lvl = LEVELS.find((l) => l.id === level)!;
  useEffect(() => {
    const close = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", esc);
    return () => { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", esc); };
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex h-10 items-center gap-1.5 rounded-full bg-paper-3/70 px-4 text-[15px] text-ink transition hover:bg-paper-3"
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <span className="font-medium">{spec.short}</span>
        <span className="text-muted">{lvl.label}</span>
        <IconChevron size={15} className="ml-0.5 text-faint" />
      </button>
      {open && (
        <div className="fade-up absolute bottom-12 left-0 z-50 w-[min(92vw,360px)] overflow-hidden rounded-2xl border border-line bg-white float-shadow">
          <div className="px-4 pb-1 pt-3.5 text-[12px] font-medium uppercase tracking-[0.08em] text-faint">Model</div>
          <div className="px-1.5">
            {MODELS.map((m) => (
              <button key={m.id} type="button" onClick={() => onModel(m.id)} className="flex w-full items-start gap-3 rounded-xl px-3 py-2.5 text-left transition hover:bg-paper-2">
                <div className="min-w-0 flex-1">
                  <div className="text-[15px] text-ink">{m.name}</div>
                  <div className="text-[13px] text-muted">{m.tagline}. {m.description}</div>
                </div>
                {m.id === model && <IconCheck size={18} className="mt-0.5 text-navy" />}
              </button>
            ))}
          </div>
          <div className="mx-4 my-2 border-t border-line" />
          <div className="flex items-center justify-between px-4 pb-2">
            <span className="text-[12px] font-medium uppercase tracking-[0.08em] text-faint">Effort</span>
            <span className="text-[12px] text-muted">{lvl.description}</span>
          </div>
          <div className="mx-3 mb-3 grid grid-cols-5 gap-1 rounded-full bg-paper-2 p-1">
            {LEVELS.map((l) => (
              <button
                key={l.id}
                type="button"
                onClick={() => onLevel(l.id)}
                title={l.description}
                className={`rounded-full px-1 py-1.5 text-[12.5px] leading-tight transition ${l.id === level ? "bg-white text-navy shadow-sm" : "text-muted hover:text-ink"}`}
              >
                {l.label.replace(" High", "")}
                {l.label.includes(" High") && <span className="block text-[10px] opacity-70">High</span>}
              </button>
            ))}
          </div>
          <div className="border-t border-line bg-paper px-4 py-3">
            <div className="mb-1.5 text-[12px] font-medium uppercase tracking-[0.08em] text-faint">Coming later</div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1">
              {COMING_MODELS.map((c) => (
                <div key={c.name} className="text-[13px] text-faint" title={c.description}>
                  {c.name.replace("Entropy ", "")} <span className="text-[11px]">{c.description === "Best overall" ? "best overall" : ""}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
