"use client";

import { Fragment, useState, type ReactNode } from "react";
import type { Citation } from "@/db/schema";
import { EntropyLogo, IconCheck, IconCopy, IconDoc, IconGlobe, IconThumbDown, IconThumbUp } from "../icons";

export interface ChatMessage {
  key: string;
  id?: string | null;
  role: "user" | "assistant";
  content: string;
  citations?: Citation[];
  evidence?: { n: number; sentence: string }[];
  meta?: Record<string, unknown>;
  status?: string[];
  error?: string;
  streaming?: boolean;
  rated?: 1 | -1;
}

function inline(text: string, keyBase: string): ReactNode[] {
  const out: ReactNode[] = [];
  const re = /(`[^`\n]+`|\[\d{1,2}\]|\*\*[^*\n]+\*\*)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index));
    const t = m[0];
    if (t.startsWith("`")) out.push(<code key={keyBase + i++} className="inline">{t.slice(1, -1)}</code>);
    else if (t.startsWith("**")) out.push(<strong key={keyBase + i++} className="font-semibold">{t.slice(2, -2)}</strong>);
    else out.push(<sup key={keyBase + i++} className="mx-0.5 rounded bg-navy-soft px-1 text-[10.5px] font-medium text-navy">{t.slice(1, -1)}</sup>);
    last = m.index + t.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

export function RichText({ text }: { text: string }) {
  const parts = text.split(/```/);
  return (
    <div className="prose-entropy">
      {parts.map((part, idx) => {
        if (idx % 2 === 1) {
          const nl = part.indexOf("\n");
          const lang = nl > 0 ? part.slice(0, nl).trim() : "";
          const code = nl >= 0 ? part.slice(nl + 1) : part;
          return (
            <div key={idx} className="my-3 overflow-hidden rounded-xl border border-line bg-[#f4f3ef]">
              <div className="flex items-center justify-between border-b border-line px-3.5 py-1.5 text-[12px] text-muted">
                <span>{lang || "code"}</span>
                <CopyButton text={code.replace(/\n$/, "")} />
              </div>
              <pre className="scroll-thin overflow-x-auto px-4 py-3 text-ink"><code>{code.replace(/\n$/, "")}</code></pre>
            </div>
          );
        }
        return part
          .split(/\n{2,}/)
          .filter((p) => p.trim())
          .map((p, j) => (
            <p key={`${idx}-${j}`}>
              {p.split("\n").map((line, k, arr) => (
                <Fragment key={k}>{inline(line, `${idx}-${j}-${k}-`)}{k < arr.length - 1 && <br />}</Fragment>
              ))}
            </p>
          ));
      })}
    </div>
  );
}

function CopyButton({ text }: { text: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      onClick={() => { navigator.clipboard?.writeText(text); setDone(true); setTimeout(() => setDone(false), 1400); }}
      className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-muted transition hover:bg-paper-3 hover:text-ink"
      aria-label="Copy"
    >
      {done ? <IconCheck size={14} /> : <IconCopy size={14} />}
    </button>
  );
}

function Sources({ citations, evidence }: { citations: Citation[]; evidence?: { n: number; sentence: string }[] }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-4 rounded-2xl border border-line bg-white/60">
      {evidence && evidence.length > 0 && (
        <div className="border-b border-line px-4 py-3.5">
          <div className="mb-2 text-[12px] font-medium uppercase tracking-[0.08em] text-faint">Extracted from sources</div>
          <ul className="space-y-1.5 text-[14.5px] leading-relaxed text-ink-2">
            {evidence.map((e, i) => (
              <li key={i} className="flex gap-2">
                <sup className="mt-2 h-fit rounded bg-navy-soft px-1 text-[10.5px] font-medium text-navy">{e.n}</sup>
                <span>{e.sentence}</span>
              </li>
            ))}
          </ul>
          <p className="mt-2 text-[11.5px] text-faint">Verbatim sentences selected by retrieval ranking, not written by the model.</p>
        </div>
      )}
      <button type="button" onClick={() => setOpen(!open)} className="flex w-full items-center justify-between px-4 py-2.5 text-[13px] text-muted hover:text-ink">
        <span>{citations.length} source{citations.length > 1 ? "s" : ""}</span>
        <span>{open ? "Hide" : "Show"}</span>
      </button>
      <div className="flex flex-wrap gap-2 px-4 pb-3">
        {citations.map((c) =>
          open ? (
            <div key={c.n} className="w-full rounded-xl bg-paper-2 px-3.5 py-2.5">
              <div className="flex items-center gap-2 text-[13px]">
                <span className="rounded bg-navy-soft px-1.5 text-[11px] font-medium text-navy">{c.n}</span>
                {c.url ? <a href={c.url} target="_blank" rel="noreferrer" className="truncate text-navy underline-offset-2 hover:underline">{c.title}</a> : <span className="truncate text-ink-2">{c.title}</span>}
                <span className="ml-auto shrink-0 text-[11px] text-faint">relevance {c.score.toFixed(2)}</span>
              </div>
              <p className="mt-1.5 line-clamp-4 text-[13px] leading-relaxed text-muted">{c.snippet}</p>
            </div>
          ) : (
            <a key={c.n} href={c.url} target={c.url ? "_blank" : undefined} rel="noreferrer" className="flex max-w-[240px] items-center gap-1.5 rounded-full bg-paper-2 px-3 py-1 text-[12.5px] text-ink-2 hover:bg-paper-3">
              {c.kind === "web" ? <IconGlobe size={13} /> : <IconDoc size={13} />}
              <span className="truncate">{c.title}</span>
            </a>
          ),
        )}
      </div>
    </div>
  );
}

function Feedback({ msg, prompt, onRated }: { msg: ChatMessage; prompt: string; onRated: (r: 1 | -1) => void }) {
  const [pending, setPending] = useState<1 | -1 | null>(null);
  const [comment, setComment] = useState("");
  const [consent, setConsent] = useState(false);
  const [state, setState] = useState<"idle" | "saving" | "error">("idle");
  async function submit() {
    if (!pending || !msg.id) return;
    setState("saving");
    const r = await fetch("/api/feedback", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messageId: msg.id, rating: pending, comment: comment || undefined, consent, prompt }) });
    if (!r.ok) { setState("error"); return; }
    onRated(pending);
    setPending(null);
    setState("idle");
  }
  if (!msg.id) return null;
  return (
    <>
      <div className="flex items-center gap-0.5">
        <CopyButton text={msg.content} />
        {([1, -1] as const).map((r) => (
          <button
            key={r}
            type="button"
            disabled={!!msg.rated}
            onClick={() => setPending(r)}
            aria-label={r === 1 ? "Good response" : "Bad response"}
            className={`rounded-md p-1.5 transition ${msg.rated === r || pending === r ? "text-navy" : "text-muted hover:bg-paper-3 hover:text-ink"} disabled:cursor-default`}
          >
            {r === 1 ? <IconThumbUp size={15} /> : <IconThumbDown size={15} />}
          </button>
        ))}
        {msg.rated && <span className="ml-1 text-[12px] text-faint">Thanks for the feedback</span>}
      </div>
      {pending && (
        <div className="fade-up mt-2 rounded-2xl border border-line bg-white p-3.5 soft-shadow">
          <textarea value={comment} onChange={(e) => setComment(e.target.value)} rows={2} placeholder={pending === 1 ? "What was good? (optional)" : "What went wrong? (optional)"} className="w-full resize-none rounded-lg bg-paper-2 px-3 py-2 text-[14px] outline-none placeholder:text-faint" />
          <label className="mt-2 flex items-start gap-2 text-[13px] text-ink-2">
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-0.5 accent-[#0a0a62]" />
            <span>Share this prompt and response for Sequentia&apos;s curated fine-tuning dataset. Without consent only the rating and comment are stored.</span>
          </label>
          <div className="mt-3 flex justify-end gap-2">
            <button type="button" onClick={() => setPending(null)} className="rounded-full px-3.5 py-1.5 text-[13px] text-muted hover:bg-paper-2">Cancel</button>
            <button type="button" onClick={submit} disabled={state === "saving"} className="rounded-full bg-navy px-4 py-1.5 text-[13px] text-white hover:bg-navy-2 disabled:opacity-60">{state === "saving" ? "Saving" : "Submit"}</button>
          </div>
          {state === "error" && <p className="mt-2 text-[12px] text-danger">Could not save feedback. Please try again.</p>}
        </div>
      )}
    </>
  );
}

export function MessageView({ msg, prompt, onRated }: { msg: ChatMessage; prompt: string; onRated: (r: 1 | -1) => void }) {
  if (msg.role === "user") {
    return (
      <div className="fade-up flex justify-end">
        <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl bg-paper-3 px-4 py-2.5 text-[16px] leading-relaxed text-ink">{msg.content}</div>
      </div>
    );
  }
  const meta = msg.meta as { modelName?: string; generatedTokens?: number; tokensPerSecond?: number; ms?: number; promptTokens?: number; contextWindow?: number; candidates?: number[]; checkpoint?: string } | undefined;
  return (
    <div className="fade-up flex gap-3.5">
      <div className="mt-1 shrink-0">
        <EntropyLogo size={22} className={msg.streaming && !msg.content ? "logo-spin" : ""} />
      </div>
      <div className="min-w-0 flex-1">
        {msg.status && msg.status.length > 0 && (
          <div className="mb-2 space-y-0.5">
            {msg.status.map((s, i) => (
              <div key={i} className={`text-[13px] ${i === msg.status!.length - 1 && msg.streaming ? "text-muted" : "text-faint"}`}>{s}</div>
            ))}
          </div>
        )}
        {msg.content ? (
          <div className={msg.streaming ? "caret" : ""}><RichText text={msg.content} /></div>
        ) : msg.streaming ? (
          <div className="flex gap-1 py-2">{[0, 1, 2].map((i) => <span key={i} className="thinking-dot h-1.5 w-1.5 rounded-full bg-navy" style={{ animationDelay: `${i * 0.18}s` }} />)}</div>
        ) : null}
        {msg.error && (
          <div className="mt-2 rounded-xl border border-[#ead1cf] bg-[#fbf3f2] px-4 py-3 text-[14px] text-danger">
            <div className="font-medium">Entropy could not complete this response</div>
            <div className="mt-0.5 text-[13.5px] opacity-90">{msg.error}</div>
          </div>
        )}
        {msg.citations && msg.citations.length > 0 && <Sources citations={msg.citations} evidence={msg.evidence} />}
        {!msg.streaming && meta?.modelName && (
          <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1">
            <Feedback msg={msg} prompt={prompt} onRated={onRated} />
            <span className="text-[11.5px] text-faint">
              {meta.modelName} · {meta.checkpoint} · {meta.generatedTokens} tokens · {meta.tokensPerSecond} tok/s · context {meta.promptTokens}/{meta.contextWindow}
              {meta.candidates && meta.candidates.length > 1 ? ` · best of ${meta.candidates.length}` : ""}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
