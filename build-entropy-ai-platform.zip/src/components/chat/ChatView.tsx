"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import type { Citation } from "@/db/schema";
import { getModel, LEVELS, type LevelId, type ModelId } from "@/lib/entropy/registry";
import { MenuButton, refreshConversations, useShell } from "../AppShell";
import { EntropyLogo, IconArrowUp, IconClip, IconDoc, IconGhost, IconGlobe, IconPlus, IconStop, IconX } from "../icons";
import { MessageView, type ChatMessage } from "./Message";
import { ModelPicker } from "./ModelPicker";

interface DocItem { id: string; name: string }
let keySeq = 0;
const nextKey = () => `m${++keySeq}-${Date.now()}`;

function greeting() {
  const h = new Date().getHours();
  return h < 5 ? "Working late?" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

export function ChatView() {
  const router = useRouter();
  const params = useSearchParams();
  const { open } = useShell();
  const convParam = params.get("c");
  const [conversationId, setConversationId] = useState<string | null>(convParam);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [model, setModel] = useState<ModelId>("gloss-1");
  const [level, setLevel] = useState<LevelId>("medium");
  const [incognito, setIncognito] = useState(false);
  const [web, setWeb] = useState(false);
  const [attached, setAttached] = useState<DocItem[]>([]);
  const [library, setLibrary] = useState<DocItem[]>([]);
  const [plusOpen, setPlusOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [uploadMsg, setUploadMsg] = useState<string | null>(null);
  const [hello, setHello] = useState("What's on your mind?");
  const abortRef = useRef<AbortController | null>(null);
  const skipLoadRef = useRef<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setHello(greeting());
    const m = localStorage.getItem("entropy.model");
    const l = localStorage.getItem("entropy.level");
    if (m && getModel(m)) setModel(m as ModelId);
    if (l && LEVELS.some((x) => x.id === l)) setLevel(l as LevelId);
  }, []);
  useEffect(() => { localStorage.setItem("entropy.model", model); }, [model]);
  useEffect(() => { localStorage.setItem("entropy.level", level); }, [level]);

  // load conversation from the URL
  useEffect(() => {
    if (convParam && skipLoadRef.current === convParam) {
      // URL was updated by us after creating this conversation; messages are already on screen
      skipLoadRef.current = null;
      return;
    }
    abortRef.current?.abort();
    setConversationId(convParam);
    if (!convParam) { setMessages([]); return; }
    setIncognito(false);
    fetch(`/api/conversations/${convParam}`)
      .then(async (r) => {
        if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || "Could not load conversation");
        return r.json();
      })
      .then((d) => {
        setMessages(
          d.messages.map((m: { id: string; role: "user" | "assistant"; content: string; citations: Citation[]; meta: Record<string, unknown> }) => ({
            key: m.id, id: m.id, role: m.role, content: m.content, citations: m.citations ?? [], meta: m.meta, evidence: (m.meta?.evidence as ChatMessage["evidence"]) ?? [],
          })),
        );
        if (d.conversation?.model && getModel(d.conversation.model)) setModel(d.conversation.model);
      })
      .catch((e) => setMessages([{ key: nextKey(), role: "assistant", content: "", error: e.message }]));
  }, [convParam]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: busy ? "auto" : "smooth" });
  }, [messages, busy]);

  useEffect(() => {
    if (!plusOpen) return;
    fetch("/api/documents").then((r) => r.json()).then((d) => setLibrary(d.documents ?? [])).catch(() => setLibrary([]));
  }, [plusOpen]);

  const autosize = () => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 220) + "px";
  };

  async function upload(file: File) {
    setUploadMsg(`Reading ${file.name}`);
    const fd = new FormData();
    fd.append("file", file);
    const r = await fetch("/api/documents", { method: "POST", body: fd });
    const d = await r.json().catch(() => ({ error: "Upload failed" }));
    if (!r.ok) { setUploadMsg(d.error || "Upload failed"); return; }
    setAttached((a) => [...a, { id: d.id, name: d.name }]);
    setUploadMsg(null);
  }

  const patchLast = useCallback((fn: (m: ChatMessage) => ChatMessage) => {
    setMessages((ms) => {
      const copy = ms.slice();
      copy[copy.length - 1] = fn(copy[copy.length - 1]);
      return copy;
    });
  }, []);

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    requestAnimationFrame(autosize);
    const history = messages.filter((m) => !m.error && m.content).map((m) => ({ role: m.role, content: m.content }));
    setMessages((ms) => [...ms, { key: nextKey(), role: "user", content: text }, { key: nextKey(), role: "assistant", content: "", streaming: true, status: [] }]);
    setBusy(true);
    const ac = new AbortController();
    abortRef.current = ac;
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId: incognito ? null : conversationId, message: text, model, level, incognito, webSearch: web, documentIds: attached.map((a) => a.id), history: incognito ? history : undefined }),
        signal: ac.signal,
      });
      if (!res.ok || !res.body) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error || `Request failed with status ${res.status}`);
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let nl: number;
        while ((nl = buf.indexOf("\n")) >= 0) {
          const line = buf.slice(0, nl);
          buf = buf.slice(nl + 1);
          if (!line.trim()) continue;
          const ev = JSON.parse(line);
          if (ev.type === "meta" && ev.conversationId && !incognito && ev.conversationId !== conversationId) {
            skipLoadRef.current = ev.conversationId;
            setConversationId(ev.conversationId);
            router.replace(`/?c=${ev.conversationId}`, { scroll: false });
            refreshConversations();
          } else if (ev.type === "status") patchLast((m) => ({ ...m, status: [...(m.status ?? []), ev.text] }));
          else if (ev.type === "token") patchLast((m) => ({ ...m, content: m.content + ev.text }));
          else if (ev.type === "citations") patchLast((m) => ({ ...m, citations: ev.citations, evidence: ev.evidence }));
          else if (ev.type === "done") patchLast((m) => ({ ...m, id: ev.messageId, meta: ev.meta, streaming: false }));
          else if (ev.type === "error") patchLast((m) => ({ ...m, error: ev.message, streaming: false }));
        }
      }
    } catch (e) {
      if ((e as Error).name === "AbortError") patchLast((m) => ({ ...m, streaming: false, status: [...(m.status ?? []), "Stopped"] }));
      else patchLast((m) => ({ ...m, streaming: false, error: (e as Error).message }));
    } finally {
      patchLast((m) => ({ ...m, streaming: false }));
      setBusy(false);
      abortRef.current = null;
      if (!incognito) refreshConversations();
    }
  }

  function toggleIncognito() {
    abortRef.current?.abort();
    setIncognito((v) => !v);
    setMessages([]);
    setConversationId(null);
    skipLoadRef.current = null;
    router.push("/");
  }

  const empty = messages.length === 0;
  const composer = (
    <div className="mx-auto w-full max-w-[760px] px-3 pb-[max(env(safe-area-inset-bottom),14px)] sm:px-5">
      <div className="rounded-[26px] border border-line bg-white px-2.5 pb-2.5 pt-2 soft-shadow">
        {(attached.length > 0 || web || uploadMsg) && (
          <div className="flex flex-wrap gap-1.5 px-2 pb-1 pt-1.5">
            {web && (
              <span className="flex items-center gap-1.5 rounded-full bg-navy-soft px-3 py-1 text-[12.5px] text-navy">
                <IconGlobe size={13} /> Web research
                <button aria-label="Disable web research" onClick={() => setWeb(false)}><IconX size={12} /></button>
              </span>
            )}
            {attached.map((d) => (
              <span key={d.id} className="flex max-w-[220px] items-center gap-1.5 rounded-full bg-paper-2 px-3 py-1 text-[12.5px] text-ink-2">
                <IconDoc size={13} /> <span className="truncate">{d.name}</span>
                <button aria-label="Remove document" onClick={() => setAttached((a) => a.filter((x) => x.id !== d.id))}><IconX size={12} /></button>
              </span>
            ))}
            {uploadMsg && <span className="px-2 py-1 text-[12.5px] text-muted">{uploadMsg}</span>}
          </div>
        )}
        <textarea
          ref={taRef}
          value={input}
          rows={1}
          onChange={(e) => { setInput(e.target.value); autosize(); }}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(); } }}
          placeholder={incognito ? "Chat privately with Entropy" : "Chat with Entropy"}
          className="block max-h-[220px] min-h-[52px] w-full resize-none bg-transparent px-3 py-3 text-[17px] leading-relaxed text-ink outline-none placeholder:text-faint"
        />
        <div className="flex items-center gap-2">
          <div className="relative">
            <button type="button" aria-label="Add" onClick={() => setPlusOpen(!plusOpen)} className="grid h-10 w-10 place-items-center rounded-full bg-paper-3/70 text-ink-2 transition hover:bg-paper-3">
              <IconPlus size={20} />
            </button>
            {plusOpen && (
              <div className="fade-up absolute bottom-12 left-0 z-50 w-[290px] rounded-2xl border border-line bg-white p-1.5 float-shadow" onMouseLeave={() => setPlusOpen(false)}>
                <button type="button" onClick={() => { fileRef.current?.click(); setPlusOpen(false); }} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[14.5px] text-ink hover:bg-paper-2">
                  <IconClip size={18} className="text-muted" /> Upload a document
                </button>
                <button type="button" onClick={() => { setWeb(!web); setPlusOpen(false); }} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[14.5px] text-ink hover:bg-paper-2">
                  <IconGlobe size={18} className="text-muted" /> <span className="flex-1">Web research</span>
                  <span className={`h-5 w-9 rounded-full p-0.5 transition ${web ? "bg-navy" : "bg-paper-3"}`}><span className={`block h-4 w-4 rounded-full bg-white transition ${web ? "translate-x-4" : ""}`} /></span>
                </button>
                {library.filter((d) => !attached.some((a) => a.id === d.id)).length > 0 && (
                  <>
                    <div className="px-3 pb-1 pt-2 text-[11.5px] font-medium uppercase tracking-[0.08em] text-faint">From your library</div>
                    <div className="scroll-thin max-h-44 overflow-y-auto">
                      {library.filter((d) => !attached.some((a) => a.id === d.id)).map((d) => (
                        <button key={d.id} type="button" onClick={() => { setAttached((a) => [...a, d]); setPlusOpen(false); }} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-[14px] text-ink-2 hover:bg-paper-2">
                          <IconDoc size={16} className="text-faint" /> <span className="truncate">{d.name}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
          <ModelPicker model={model} level={level} onModel={setModel} onLevel={setLevel} />
          <div className="flex-1" />
          {busy ? (
            <button type="button" aria-label="Stop" onClick={() => abortRef.current?.abort()} className="grid h-10 w-10 place-items-center rounded-full bg-ink text-white">
              <IconStop size={18} />
            </button>
          ) : (
            <button type="button" aria-label="Send" onClick={send} disabled={!input.trim()} className="grid h-10 w-10 place-items-center rounded-full bg-navy text-white transition hover:bg-navy-2 disabled:bg-paper-3 disabled:text-faint">
              <IconArrowUp size={19} />
            </button>
          )}
        </div>
      </div>
      <p className="mt-2 text-center text-[11.5px] text-faint">Entropy runs on small models trained from scratch by Sequentia and can be wrong. Check important information.</p>
      <input ref={fileRef} type="file" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f); e.target.value = ""; }} />
    </div>
  );

  return (
    <div className="flex h-full flex-col">
      <header className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-center justify-between px-4 pt-4 sm:px-5">
        <div className="pointer-events-auto">{!open && <MenuButton />}{open && <span className="lg:hidden"><MenuButton /></span>}</div>
        {incognito && <div className="text-[15px] font-medium text-ink">Incognito chat</div>}
        <button
          aria-label={incognito ? "Leave incognito" : "Start incognito chat"}
          onClick={toggleIncognito}
          className={`pointer-events-auto grid h-11 w-11 place-items-center rounded-full transition float-shadow ${incognito ? "bg-ink text-paper" : "bg-white/80 text-ink-2 backdrop-blur hover:bg-white"}`}
        >
          <IconGhost size={21} />
        </button>
      </header>

      {empty ? (
        <div className="flex flex-1 flex-col">
          <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
            {incognito ? (
              <div className="fade-up max-w-[560px]">
                <IconGhost size={44} filled className="mx-auto text-ink" />
                <p className="mt-6 text-[17px] leading-relaxed text-ink-2">Incognito chats stay out of your history, memory and search, and are never added to any training dataset.</p>
              </div>
            ) : (
              <div className="fade-up">
                <EntropyLogo size={46} className="mx-auto" />
                <h1 className="mt-6 font-serif text-[clamp(30px,4.4vw,44px)] leading-tight tracking-tight text-ink">{hello}</h1>
                <p className="mt-2 text-[15px] text-muted">What would you like to explore?</p>
              </div>
            )}
          </div>
          {composer}
        </div>
      ) : (
        <>
          <div ref={scrollRef} className="scroll-thin flex-1 overflow-y-auto">
            <div className="mx-auto max-w-[760px] space-y-7 px-5 pb-8 pt-20">
              {messages.map((m, i) => (
                <MessageView
                  key={m.key}
                  msg={m}
                  prompt={messages[i - 1]?.role === "user" ? messages[i - 1].content : ""}
                  onRated={(r) => setMessages((ms) => ms.map((x) => (x.key === m.key ? { ...x, rated: r } : x)))}
                />
              ))}
            </div>
          </div>
          {composer}
        </>
      )}
    </div>
  );
}
