"use client";

import type { ReactNode } from "react";
import { MenuButton, useShell } from "./AppShell";

export function PageFrame({ title, subtitle, children, actions }: { title: string; subtitle?: string; children: ReactNode; actions?: ReactNode }) {
  const { open } = useShell();
  return (
    <div className="scroll-thin h-full overflow-y-auto">
      <div className="sticky top-0 z-10 px-4 pt-4 sm:px-5">
        <span className={open ? "lg:hidden" : ""}><MenuButton /></span>
      </div>
      <div className="mx-auto max-w-[920px] px-5 pb-20 sm:px-8">
        <div className="mb-8 mt-2 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-serif text-[36px] leading-tight tracking-tight text-ink">{title}</h1>
            {subtitle && <p className="mt-1.5 max-w-[640px] text-[15px] leading-relaxed text-muted">{subtitle}</p>}
          </div>
          {actions}
        </div>
        {children}
      </div>
    </div>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-2xl border border-line bg-white/70 p-5 ${className}`}>{children}</div>;
}

export function Stat({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div className="rounded-2xl border border-line bg-white/70 px-4 py-3.5">
      <div className="text-[12px] font-medium uppercase tracking-[0.08em] text-faint">{label}</div>
      <div className="mt-1 font-serif text-[26px] leading-tight text-ink">{value}</div>
      {hint && <div className="mt-0.5 text-[12px] text-muted">{hint}</div>}
    </div>
  );
}
