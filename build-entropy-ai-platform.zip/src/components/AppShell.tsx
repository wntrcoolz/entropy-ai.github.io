"use client";

import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { createContext, Suspense, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { EntropyLogo, IconChats, IconDoc, IconFlask, IconMemory, IconMenu, IconNewChat, IconPulse, IconTrash } from "./icons";

interface Conv { id: string; title: string; updatedAt: string; model: string }
interface ShellCtx { open: boolean; setOpen: (v: boolean) => void; refresh: () => void }
const Ctx = createContext<ShellCtx>({ open: false, setOpen: () => {}, refresh: () => {} });
export const useShell = () => useContext(Ctx);

export function refreshConversations() {
  window.dispatchEvent(new Event("entropy:conversations"));
}

export function MenuButton({ className = "" }: { className?: string }) {
  const { open, setOpen } = useShell();
  return (
    <button
      aria-label={open ? "Close sidebar" : "Open sidebar"}
      onClick={() => setOpen(!open)}
      className={`grid h-11 w-11 place-items-center rounded-full bg-white/80 text-ink-2 backdrop-blur transition hover:bg-white float-shadow ${className}`}
    >
      <IconMenu size={20} />
    </button>
  );
}

const NAV = [
  { href: "/chats", label: "Chats", icon: IconChats },
  { href: "/memory", label: "Memory", icon: IconMemory },
  { href: "/documents", label: "Documents", icon: IconDoc },
  { href: "/brain", label: "Brain", icon: IconPulse },
  { href: "/research", label: "Research", icon: IconFlask },
];

function Sidebar({ onNavigate }: { onNavigate: () => void }) {
  const [convs, setConvs] = useState<Conv[]>([]);
  const pathname = usePathname();
  const params = useSearchParams();
  const router = useRouter();
  const active = params.get("c");

  const load = useCallback(() => {
    fetch("/api/conversations").then((r) => (r.ok ? r.json() : { conversations: [] })).then((d) => setConvs(d.conversations ?? [])).catch(() => {});
  }, []);
  useEffect(() => {
    load();
    window.addEventListener("entropy:conversations", load);
    return () => window.removeEventListener("entropy:conversations", load);
  }, [load]);

  async function remove(id: string) {
    await fetch(`/api/conversations/${id}`, { method: "DELETE" });
    if (active === id) router.push("/");
    load();
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-6 pb-4 pt-6">
        <EntropyLogo size={26} />
        <span className="font-serif text-[27px] leading-none tracking-tight text-ink">Entropy</span>
      </div>
      <nav className="px-3">
        {NAV.map(({ href, label, icon: Icon }) => {
          const on = pathname === href;
          return (
            <Link key={href} href={href} onClick={onNavigate} className={`flex items-center gap-3.5 rounded-xl px-3.5 py-2.5 text-[16px] transition ${on ? "bg-paper-3 text-ink" : "text-ink-2 hover:bg-paper-3/70"}`}>
              <Icon size={21} className="text-ink-2" />
              {label}
            </Link>
          );
        })}
      </nav>
      <div className="mt-5 px-6 pb-1.5 text-[13px] font-medium text-muted">Recents</div>
      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-3 pb-3">
        {convs.length === 0 && <p className="px-3.5 py-2 text-sm text-faint">No conversations yet</p>}
        {convs.slice(0, 40).map((c) => (
          <div key={c.id} className={`group flex items-center rounded-xl transition ${active === c.id && pathname === "/" ? "bg-paper-3" : "hover:bg-paper-3/70"}`}>
            <Link href={`/?c=${c.id}`} onClick={onNavigate} className="flex min-w-0 flex-1 items-center gap-3.5 px-3.5 py-2">
              <span className="truncate text-[15px] text-ink-2">{c.title}</span>
            </Link>
            <button aria-label="Delete conversation" onClick={() => remove(c.id)} className="mr-2 hidden rounded-lg p-1.5 text-faint hover:bg-paper-2 hover:text-danger group-hover:block">
              <IconTrash size={15} />
            </button>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between border-t border-line px-4 py-4">
        <div className="flex items-center gap-2.5">
          <div className="grid h-10 w-10 place-items-center rounded-full bg-white font-serif text-[17px] text-ink soft-shadow">S</div>
          <div className="leading-tight">
            <div className="text-[13px] text-ink-2">Local workspace</div>
            <div className="text-[11.5px] text-faint">No account required</div>
          </div>
        </div>
        <Link href="/" onClick={onNavigate} aria-label="New chat" className="grid h-11 w-11 place-items-center rounded-full bg-navy text-white transition hover:bg-navy-2 float-shadow">
          <IconNewChat size={20} />
        </Link>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [desktop, setDesktop] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const apply = () => { setDesktop(mq.matches); setOpen(mq.matches); };
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);
  const refresh = useCallback(() => refreshConversations(), []);
  return (
    <Ctx.Provider value={{ open, setOpen, refresh }}>
      <div className="flex h-dvh overflow-hidden bg-paper">
        {/* overlay for small screens */}
        {open && !desktop && <div className="fixed inset-0 z-30 bg-ink/10 backdrop-blur-[1px]" onClick={() => setOpen(false)} />}
        <aside
          className={`z-40 h-full w-[300px] shrink-0 border-r border-line bg-paper-2 transition-all duration-300 ${desktop ? "relative" : "fixed left-0 top-0"} ${open ? "translate-x-0" : desktop ? "-ml-[300px]" : "-translate-x-full"}`}
        >
          <Suspense fallback={null}>
            <Sidebar onNavigate={() => !desktop && setOpen(false)} />
          </Suspense>
        </aside>
        <main className="relative min-w-0 flex-1">{children}</main>
      </div>
    </Ctx.Provider>
  );
}
