import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement> & { size?: number };
const base = (size = 20): SVGProps<SVGSVGElement> => ({
  width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.6, strokeLinecap: "round", strokeLinejoin: "round",
});

export function EntropyLogo({ size = 28, className, color = "#06065e" }: { size?: number; className?: string; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="40 30 490 505" className={className} fill={color} aria-label="Entropy" role="img">
      <path d="M380 45 A245 245 0 0 0 62 365 Z" />
      <path d="M262 207 L470 207 L180 498 A245 245 0 0 1 75 395 Z" />
      <path d="M335 383 L520 383 A245 245 0 0 1 205 512 Z" />
    </svg>
  );
}

export const IconMenu = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M4 7h16M4 12h12M4 17h8" /></svg>);
export const IconPlus = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M12 5v14M5 12h14" /></svg>);
export const IconArrowUp = ({ size, ...p }: P) => (<svg {...base(size)} strokeWidth={2} {...p}><path d="M12 19V5M6 11l6-6 6 6" /></svg>);
export const IconStop = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><rect x="7" y="7" width="10" height="10" rx="1.5" fill="currentColor" /></svg>);
export const IconChat = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M20 12a8 8 0 0 1-11.6 7.1L4 20l1-4.1A8 8 0 1 1 20 12Z" /></svg>);
export const IconChats = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M15 9.5a6 6 0 0 1-8.7 5.4L3 16l.9-3A6 6 0 1 1 15 9.5Z" /><path d="M9.6 17.4A6 6 0 0 0 17.7 19L21 20l-.9-3a6 6 0 0 0-3.4-8.3" /></svg>);
export const IconMemory = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M12 3a6 6 0 0 0-6 6c0 2.2 1.2 3.6 2.2 4.6.6.6.8 1.3.8 2V17h6v-1.4c0-.7.3-1.4.8-2 1-1 2.2-2.4 2.2-4.6a6 6 0 0 0-6-6Z" /><path d="M9.5 20.5h5" /></svg>);
export const IconDoc = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z" /><path d="M14 3v5h5M9 13h6M9 17h4" /></svg>);
export const IconPulse = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M3 12h4l2.5-6 5 12 2.5-6h4" /></svg>);
export const IconFlask = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M9 3h6M10 3v6L4.8 18a2 2 0 0 0 1.7 3h11a2 2 0 0 0 1.7-3L14 9V3" /><path d="M7.5 14h9" /></svg>);
export const IconGlobe = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" /></svg>);
export const IconClip = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="m20 11.5-8.1 8.1a5 5 0 0 1-7.1-7.1l8.5-8.5a3.3 3.3 0 0 1 4.7 4.7l-8.5 8.5a1.7 1.7 0 0 1-2.4-2.4l7.8-7.8" /></svg>);
export const IconThumbUp = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M7 10v10H4V10Zm0 0 4-7a2 2 0 0 1 2.5 2.4L12.8 9H19a2 2 0 0 1 2 2.3l-1.2 7A2 2 0 0 1 17.8 20H7" /></svg>);
export const IconThumbDown = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M17 14V4h3v10Zm0 0-4 7a2 2 0 0 1-2.5-2.4l.7-3.6H5a2 2 0 0 1-2-2.3l1.2-7A2 2 0 0 1 6.2 4H17" /></svg>);
export const IconCopy = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><rect x="8" y="8" width="12" height="12" rx="2" /><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" /></svg>);
export const IconCheck = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="m5 12.5 4.5 4.5L19 7.5" /></svg>);
export const IconTrash = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3" /></svg>);
export const IconX = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M6 6l12 12M18 6 6 18" /></svg>);
export const IconChevron = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="m6 9 6 6 6-6" /></svg>);
export const IconChevronRight = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="m9 6 6 6-6 6" /></svg>);
export const IconNewChat = ({ size, ...p }: P) => (<svg {...base(size)} {...p}><path d="M20 12a8 8 0 0 1-11.6 7.1L4 20l1-4.1A8 8 0 1 1 20 12Z" /><path d="M12 9v6M9 12h6" /></svg>);
export const IconGhost = ({ size, filled, ...p }: P & { filled?: boolean }) => (
  <svg {...base(size)} {...p}>
    <path d="M5 20V11a7 7 0 0 1 14 0v9l-2.3-1.6L14.3 20 12 18.4 9.7 20l-2.4-1.6Z" fill={filled ? "currentColor" : "none"} />
    <circle cx="9.5" cy="11" r="1" fill={filled ? "var(--color-paper)" : "currentColor"} stroke="none" />
    <circle cx="14.5" cy="11" r="1" fill={filled ? "var(--color-paper)" : "currentColor"} stroke="none" />
  </svg>
);
