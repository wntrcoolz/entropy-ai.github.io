export function LossChart({ series, height = 120 }: { series: { label: string; points: { step: number; loss: number }[]; color: string }[]; height?: number }) {
  const all = series.flatMap((s) => s.points);
  if (all.length < 2) return <div className="grid h-[120px] place-items-center text-[13px] text-faint">No training history yet</div>;
  const W = 560, H = height, pad = 28;
  const maxStep = Math.max(...all.map((p) => p.step)), minL = Math.min(...all.map((p) => p.loss)), maxL = Math.max(...all.map((p) => p.loss));
  const x = (s: number) => pad + (s / Math.max(1, maxStep)) * (W - pad - 8);
  const y = (l: number) => 8 + (1 - (l - minL) / Math.max(1e-6, maxL - minL)) * (H - 28);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Training loss">
      {[0, 0.5, 1].map((f) => {
        const l = minL + f * (maxL - minL);
        return (
          <g key={f}>
            <line x1={pad} x2={W - 8} y1={y(l)} y2={y(l)} stroke="#e5e2da" strokeDasharray="3 4" />
            <text x={0} y={y(l) + 4} fontSize="10" fill="#a29e95">{l.toFixed(1)}</text>
          </g>
        );
      })}
      {series.map((s) => (
        <polyline key={s.label} fill="none" stroke={s.color} strokeWidth="1.8" strokeLinejoin="round" points={s.points.map((p) => `${x(p.step)},${y(p.loss)}`).join(" ")} />
      ))}
      <text x={W - 8} y={H - 4} fontSize="10" fill="#a29e95" textAnchor="end">step {maxStep}</text>
    </svg>
  );
}
