import { asc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { chunks, conversations, documents, memories, messages, type Citation } from "@/db/schema";
import { buildPrompt, type Turn } from "@/lib/entropy/context";
import { getEngine, getTokenizer } from "@/lib/entropy/engine";
import { KVSession, logProb, sample } from "@/lib/entropy/generate";
import { rng } from "@/lib/entropy/gpt";
import { getLevel, getModel } from "@/lib/entropy/registry";
import { extractEvidence, rankPassages, searchWeb } from "@/lib/entropy/research";
import { embed, topK } from "@/lib/entropy/text";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface ChatBody {
  conversationId?: string | null;
  message: string;
  model: string;
  level: string;
  incognito?: boolean;
  webSearch?: boolean;
  documentIds?: string[];
  history?: Turn[]; // used for incognito chats (nothing is stored server-side)
}

const tick = () => new Promise<void>((r) => setImmediate(r));

function rememberIntent(text: string): string | null {
  const m = text.trim().match(/^(?:please\s+)?remember(?:\s+that)?\s+(.{3,500})$/i);
  if (!m) return null;
  return m[1]
    .replace(/[.!]+$/, "")
    .replace(/\bI am\b|\bI'm\b/gi, "The user is")
    .replace(/\bmy\b/gi, "the user's")
    .replace(/\bI\b/g, "the user")
    .replace(/^the/, "The") + ".";
}

export async function POST(req: Request) {
  let body: ChatBody;
  try {
    body = (await req.json()) as ChatBody;
  } catch {
    return Response.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const text = (body.message ?? "").trim();
  if (!text) return Response.json({ error: "Message is empty" }, { status: 400 });
  if (text.length > 20000) return Response.json({ error: "Message is too long (20,000 characters max)" }, { status: 413 });
  const spec = getModel(body.model);
  if (!spec) return Response.json({ error: `Unknown model "${body.model}"` }, { status: 400 });
  const level = getLevel(body.level);
  const incognito = !!body.incognito;

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: Record<string, unknown>) => controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
      const t0 = Date.now();
      let conversationId = body.conversationId ?? null;
      try {
        // 1. load model honestly: if there is no checkpoint, say so
        let engine;
        try {
          engine = getEngine(spec.id);
        } catch (e) {
          throw new Error(`${spec.name} is not available: ${(e as Error).message}`);
        }
        const tok = getTokenizer();
        const { model, meta } = engine;

        // 2. persistence
        let history: Turn[] = [];
        if (!incognito) {
          if (!conversationId) {
            const [c] = await db.insert(conversations).values({ title: text.slice(0, 60), model: spec.id, level: level.id }).returning();
            conversationId = c.id;
          } else {
            const prev = await db.select().from(messages).where(eq(messages.conversationId, conversationId)).orderBy(asc(messages.createdAt));
            history = prev.map((m) => ({ role: m.role as Turn["role"], content: m.content }));
          }
          await db.insert(messages).values({ conversationId, role: "user", content: text, model: spec.id, level: level.id });
        } else {
          history = (body.history ?? []).slice(-20);
        }
        send({ type: "meta", conversationId, model: spec.name, level: level.label, params: meta.numParams, stage: meta.stage });

        // 3. long-term memory (stored notes, never model training)
        const qVec = embed(text);
        let memoryNotes: string[] = [];
        if (!incognito) {
          const note = rememberIntent(text);
          if (note) {
            await db.insert(memories).values({ content: note, embedding: embed(note), source: "chat" });
            send({ type: "status", text: "Saved a note to memory (stored for retrieval, not used to train the model)" });
          }
          const all = await db.select().from(memories);
          memoryNotes = topK(qVec, all, (m) => m.embedding, 3, 0.12).map((x) => x.item.content);
          if (memoryNotes.length) send({ type: "status", text: `Recalled ${memoryNotes.length} memory note${memoryNotes.length > 1 ? "s" : ""}` });
        }

        // 4. retrieval: attached documents + web research
        const citations: Citation[] = [];
        const passagesForPrompt: string[] = [];
        if (body.documentIds?.length) {
          send({ type: "status", text: "Searching attached documents" });
          const docs = await db.select({ id: documents.id, name: documents.name }).from(documents).where(inArray(documents.id, body.documentIds));
          const rows = await db.select().from(chunks).where(inArray(chunks.documentId, body.documentIds));
          const names = new Map(docs.map((d) => [d.id, d.name]));
          for (const r of topK(qVec, rows, (c) => c.embedding, level.retrievalDepth, 0)) {
            citations.push({ n: citations.length + 1, kind: "document", title: names.get(r.item.documentId) ?? "Document", snippet: r.item.content, score: Math.round(r.score * 1000) / 1000 });
          }
        }
        if (body.webSearch) {
          send({ type: "status", text: "Searching the web" });
          const { sources, errors } = await searchWeb(text, Math.max(3, level.retrievalDepth));
          if (errors.length) send({ type: "status", text: `Some sources failed: ${errors.slice(0, 2).join("; ")}` });
          if (!sources.length) send({ type: "status", text: "Web research returned no sources" });
          else send({ type: "status", text: `Read ${sources.length} source${sources.length > 1 ? "s" : ""}` });
          for (const p of rankPassages(text, sources.map((s) => ({ ...s, kind: "web" as const })), level.retrievalDepth)) {
            citations.push({ n: citations.length + 1, kind: "web", title: p.title, url: p.url, snippet: p.text, score: Math.round(p.score * 1000) / 1000 });
          }
        }
        for (const c of citations) passagesForPrompt.push(`[${c.n}] ${c.snippet}`);
        const evidence = extractEvidence(text, citations.map((c) => ({ n: c.n, text: c.snippet })), Math.min(5, level.retrievalDepth));
        if (citations.length) send({ type: "citations", citations, evidence });

        // 5. context management
        const reserve = Math.min(level.maxNewTokens, Math.floor(model.config.ctx / 2));
        const prompt = buildPrompt(tok, {
          ctx: model.config.ctx, reserve,
          history: [...history.filter((h) => h.role === "user" || h.role === "assistant"), { role: "user", content: text }],
          context: passagesForPrompt, memories: memoryNotes,
        });
        if (prompt.droppedTurns) send({ type: "status", text: `Context window: kept ${prompt.usedTurns} earlier turns, dropped ${prompt.droppedTurns} oldest` });

        // 6. generation (real forward passes of Entropy's own Transformer)
        const END = tok.special("<|end|>");
        const banned = new Set<number>(["<|pad|>", "<|bos|>", "<|system|>", "<|user|>", "<|context|>", "<|assistant|>"].map((s) => tok.special(s as never)));
        for (let i = tok.vocabSize; i < model.config.vocabSize; i++) banned.add(i);
        const opts = { temperature: level.temperature, topK: level.topK, topP: level.topP, repetitionPenalty: 1.18, frequencyPenalty: 0.12, noRepeatNgramSize: 3 };
        const seed = Date.now() % 1e9;
        const limit = Math.min(reserve, model.config.ctx - prompt.tokens.length);
        const base = new KVSession(model);
        const prefix = new Float32Array(base.prefill(prompt.tokens));
        await tick();
        const live = level.candidates === 1;
        const scores: number[] = [];
        let best: number[] = [];
        let bestScore = -Infinity;
        for (let c = 0; c < level.candidates; c++) {
          if (!live) send({ type: "status", text: `Sampling candidate ${c + 1} of ${level.candidates}` });
          const sess = c === 0 ? base : new KVSession(model);
          let logits: Float32Array = c === 0 ? prefix : new Float32Array(sess.prefill(prompt.tokens));
          const rand = rng(seed + c * 7919);
          const decode = tok.streamDecoder();
          const out: number[] = [];
          let lp = 0;
          for (let i = 0; i < limit; i++) {
            const t = sample(logits, out.slice(-64), opts, rand, banned, out);
            lp += logProb(logits, t);
            if (t === END) break;
            out.push(t);
            if (live) {
              const piece = decode(t);
              if (piece) send({ type: "token", text: piece });
            }
            if (sess.pos >= model.config.ctx) break;
            logits = sess.step(t);
            if (i % 4 === 3) await tick();
          }
          const score = lp / Math.max(1, out.length + 1);
          scores.push(Math.round(score * 1000) / 1000);
          if (score > bestScore) { bestScore = score; best = out; }
          await tick();
        }
        if (!live) {
          send({ type: "status", text: `Selected the most likely of ${level.candidates} candidates` });
          const decode = tok.streamDecoder();
          for (const t of best) { const piece = decode(t); if (piece) send({ type: "token", text: piece }); }
        }
        const content = tok.decode(best).trim();
        const ms = Date.now() - t0;
        const metaOut = {
          modelId: spec.id, modelName: spec.name, level: level.id, params: meta.numParams, checkpoint: `${meta.stage}@${meta.step}`,
          promptTokens: prompt.tokens.length, contextWindow: model.config.ctx, generatedTokens: best.length,
          droppedTurns: prompt.droppedTurns, memoryNotes: memoryNotes.length, candidates: scores, ms,
          tokensPerSecond: Math.round((best.length * level.candidates) / Math.max(0.001, ms / 1000)),
          evidence,
        };
        let messageId: string | null = null;
        if (!incognito && conversationId) {
          const [m] = await db.insert(messages).values({ conversationId, role: "assistant", content: content || "(The model produced no text.)", model: spec.id, level: level.id, citations, meta: metaOut }).returning();
          messageId = m.id;
          await db.update(conversations).set({ updatedAt: new Date(), model: spec.id, level: level.id }).where(eq(conversations.id, conversationId));
        }
        if (!content) send({ type: "status", text: "The model ended its turn without producing text" });
        send({ type: "done", messageId, conversationId, meta: metaOut });
      } catch (e) {
        console.error("[chat]", e);
        send({ type: "error", message: (e as Error).message || "Unknown error", conversationId });
      } finally {
        controller.close();
      }
    },
  });
  return new Response(stream, { headers: { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no" } });
}
