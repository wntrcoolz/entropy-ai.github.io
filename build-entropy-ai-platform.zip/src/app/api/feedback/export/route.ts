import { and, eq, isNotNull } from "drizzle-orm";
import { db } from "@/db";
import { feedback } from "@/db/schema";

export const dynamic = "force-dynamic";

/**
 * Curated, consent-based dataset export. Only positively rated responses whose
 * authors explicitly opted in are exported, in the SFT JSONL format consumed by
 * scripts/prepare-data.ts (save as data/sft/feedback-curated.jsonl).
 */
export async function GET() {
  const rows = await db
    .select()
    .from(feedback)
    .where(and(eq(feedback.consent, true), eq(feedback.rating, 1), isNotNull(feedback.prompt), isNotNull(feedback.response)));
  const lines = rows
    .filter((r) => r.prompt!.trim() && r.response!.trim())
    .map((r) => JSON.stringify({ messages: [{ role: "user", content: r.prompt }, { role: "assistant", content: r.response }], meta: { feedbackId: r.id, model: r.model } }));
  return new Response(lines.join("\n") + (lines.length ? "\n" : ""), {
    headers: { "Content-Type": "application/x-ndjson", "Content-Disposition": 'attachment; filename="feedback-curated.jsonl"' },
  });
}
