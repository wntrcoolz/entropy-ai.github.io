import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { feedback, messages } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { messageId?: string; rating?: number; comment?: string; consent?: boolean; prompt?: string };
  if (!body.messageId || (body.rating !== 1 && body.rating !== -1)) return Response.json({ error: "messageId and rating (1 or -1) are required" }, { status: 400 });
  const [msg] = await db.select().from(messages).where(eq(messages.id, body.messageId));
  if (!msg) return Response.json({ error: "Message not found" }, { status: 404 });
  const consent = body.consent === true;
  const [row] = await db
    .insert(feedback)
    .values({
      messageId: msg.id, conversationId: msg.conversationId, rating: body.rating, comment: body.comment?.slice(0, 2000) ?? null, consent,
      // conversation text is only copied into the feedback record when the user consents
      prompt: consent ? (body.prompt?.slice(0, 20000) ?? null) : null,
      response: consent ? msg.content : null, model: msg.model, level: msg.level,
    })
    .returning({ id: feedback.id });
  return Response.json({ id: row.id, consent });
}

export async function GET() {
  const rows = await db.select().from(feedback).orderBy(desc(feedback.createdAt)).limit(200);
  return Response.json({ feedback: rows });
}
