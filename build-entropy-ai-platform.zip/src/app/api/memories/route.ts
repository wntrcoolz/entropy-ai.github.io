import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { memories } from "@/db/schema";
import { embed } from "@/lib/entropy/text";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select({ id: memories.id, content: memories.content, source: memories.source, createdAt: memories.createdAt }).from(memories).orderBy(desc(memories.createdAt));
  return Response.json({ memories: rows });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { content?: string };
  const content = body.content?.trim();
  if (!content || content.length > 1000) return Response.json({ error: "Memory must be 1 to 1000 characters" }, { status: 400 });
  const [row] = await db.insert(memories).values({ content, embedding: embed(content), source: "manual" }).returning({ id: memories.id });
  return Response.json({ id: row.id });
}

export async function DELETE(req: Request) {
  const id = new URL(req.url).searchParams.get("id");
  if (id === "all") await db.delete(memories);
  else if (id) await db.delete(memories).where(eq(memories.id, id));
  else return Response.json({ error: "id required" }, { status: 400 });
  return Response.json({ ok: true });
}
