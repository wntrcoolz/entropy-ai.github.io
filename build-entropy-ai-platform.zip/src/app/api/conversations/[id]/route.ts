import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";

export const dynamic = "force-dynamic";

const UUID = /^[0-9a-f-]{36}$/i;

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  if (!UUID.test(id)) return Response.json({ error: "Invalid id" }, { status: 400 });
  const [conv] = await db.select().from(conversations).where(eq(conversations.id, id));
  if (!conv) return Response.json({ error: "Conversation not found" }, { status: 404 });
  const msgs = await db.select().from(messages).where(eq(messages.conversationId, id)).orderBy(asc(messages.createdAt));
  return Response.json({ conversation: conv, messages: msgs });
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as { title?: string };
  const title = body.title?.trim().slice(0, 120);
  if (!UUID.test(id) || !title) return Response.json({ error: "A title is required" }, { status: 400 });
  await db.update(conversations).set({ title }).where(eq(conversations.id, id));
  return Response.json({ ok: true });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  if (!UUID.test(id)) return Response.json({ error: "Invalid id" }, { status: 400 });
  await db.delete(conversations).where(eq(conversations.id, id));
  return Response.json({ ok: true });
}
