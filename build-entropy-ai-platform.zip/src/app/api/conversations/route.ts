import { desc } from "drizzle-orm";
import { db } from "@/db";
import { conversations } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(conversations).orderBy(desc(conversations.updatedAt)).limit(200);
  return Response.json({ conversations: rows });
}
