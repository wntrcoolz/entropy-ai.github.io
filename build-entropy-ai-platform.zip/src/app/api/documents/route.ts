import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { chunks, documents } from "@/db/schema";
import { analyzeDocument, chunkText, embed } from "@/lib/entropy/text";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_BYTES = 2_000_000;
const TEXT_TYPES = /\.(txt|md|markdown|csv|json|html?|xml|ya?ml|ts|tsx|js|jsx|py|go|rs|java|c|cpp|h|rb|php|cs|swift|kt|sql|sh|css|log)$/i;

export async function GET() {
  const rows = await db
    .select({ id: documents.id, name: documents.name, mime: documents.mime, size: documents.size, analysis: documents.analysis, createdAt: documents.createdAt })
    .from(documents)
    .orderBy(desc(documents.createdAt));
  return Response.json({ documents: rows });
}

export async function POST(req: Request) {
  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!file || typeof file === "string") return Response.json({ error: "Upload a file in the 'file' field" }, { status: 400 });
  if (file.size > MAX_BYTES) return Response.json({ error: "File is larger than 2 MB" }, { status: 413 });
  if (!TEXT_TYPES.test(file.name) && !file.type.startsWith("text/")) {
    return Response.json({ error: `Unsupported file type for "${file.name}". Entropy can analyse text, Markdown, CSV, JSON, HTML and source code. PDF and image parsing are not implemented yet.` }, { status: 415 });
  }
  let content = await file.text();
  if (/\.html?$/i.test(file.name)) content = content.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, "").replace(/<[^>]+>/g, " ");
  if (!content.trim()) return Response.json({ error: "The file is empty" }, { status: 400 });
  const analysis = analyzeDocument(file.name, content);
  const [doc] = await db.insert(documents).values({ name: file.name, mime: file.type || "text/plain", size: file.size, content, analysis }).returning({ id: documents.id });
  const parts = chunkText(content, 700);
  for (let i = 0; i < parts.length; i += 100) {
    await db.insert(chunks).values(parts.slice(i, i + 100).map((c, j) => ({ documentId: doc.id, idx: i + j, content: c, embedding: embed(c) })));
  }
  return Response.json({ id: doc.id, name: file.name, chunks: parts.length, analysis });
}

export async function DELETE(req: Request) {
  const id = new URL(req.url).searchParams.get("id");
  if (!id) return Response.json({ error: "id required" }, { status: 400 });
  await db.delete(documents).where(eq(documents.id, id));
  return Response.json({ ok: true });
}
