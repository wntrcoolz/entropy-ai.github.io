"use client";

import { useEffect, useRef, useState } from "react";
import { Card, PageFrame } from "@/components/PageFrame";
import { IconDoc, IconTrash } from "@/components/icons";
import type { DocumentAnalysis } from "@/lib/entropy/text";

interface Doc { id: string; name: string; size: number; createdAt: string; analysis: DocumentAnalysis }

export default function DocumentsPage() {
  const [docs, setDocs] = useState<Doc[] | null>(null);
  const [sel, setSel] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const load = () => fetch("/api/documents").then((r) => r.json()).then((d) => setDocs(d.documents ?? [])).catch(() => setDocs([]));
  useEffect(() => { load(); }, []);
  async function upload(f: File) {
    setMsg(`Analysing ${f.name}`);
    const fd = new FormData();
    fd.append("file", f);
    const r = await fetch("/api/documents", { method: "POST", body: fd });
    const d = await r.json();
    if (!r.ok) { setMsg(d.error); return; }
    setMsg(`${d.name}: ${d.chunks} chunks indexed`);
    setSel(d.id);
    load();
  }
  const doc = docs?.find((d) => d.id === sel);
  return (
    <PageFrame
      title="Documents"
      subtitle="Upload text, Markdown, CSV, JSON, HTML or source code. Entropy chunks and embeds each file for retrieval, and computes statistics, keywords and an extractive summary. Attach documents to a chat with the plus button."
      actions={<button onClick={() => fileRef.current?.click()} className="rounded-full bg-navy px-5 py-2.5 text-[14px] text-white hover:bg-navy-2">Upload document</button>}
    >
      <input ref={fileRef} type="file" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f); e.target.value = ""; }} />
      {msg && <p className="mb-4 text-[13.5px] text-muted">{msg}</p>}
      <div className="grid gap-5 md:grid-cols-[280px_1fr]">
        <div className="space-y-1.5">
          {docs === null ? <p className="text-muted">Loading</p> : docs.length === 0 ? <p className="text-[14px] text-muted">No documents yet.</p> : docs.map((d) => (
            <button key={d.id} onClick={() => setSel(d.id)} className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-left transition ${sel === d.id ? "bg-paper-3" : "hover:bg-paper-2"}`}>
              <IconDoc size={18} className="shrink-0 text-muted" />
              <div className="min-w-0">
                <div className="truncate text-[14.5px] text-ink">{d.name}</div>
                <div className="text-[12px] text-faint">{(d.size / 1024).toFixed(1)} KB · {d.analysis?.kind}</div>
              </div>
            </button>
          ))}
        </div>
        {doc ? (
          <Card>
            <div className="flex items-start justify-between gap-3">
              <h2 className="font-serif text-[24px] text-ink">{doc.name}</h2>
              <button aria-label="Delete" onClick={async () => { await fetch(`/api/documents?id=${doc.id}`, { method: "DELETE" }); setSel(null); load(); }} className="rounded-lg p-2 text-faint hover:bg-paper-2 hover:text-danger"><IconTrash size={16} /></button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[["Words", doc.analysis.words], ["Lines", doc.analysis.lines], ["Sentences", doc.analysis.sentences], ["Reading", `${doc.analysis.readingMinutes} min`]].map(([k, v]) => (
                <div key={k as string} className="rounded-xl bg-paper-2 px-3 py-2.5"><div className="text-[11.5px] uppercase tracking-[0.08em] text-faint">{k}</div><div className="font-serif text-[20px]">{v}</div></div>
              ))}
            </div>
            {doc.analysis.summary?.length > 0 && (
              <div className="mt-5">
                <div className="mb-2 text-[12px] font-medium uppercase tracking-[0.08em] text-faint">Extractive summary</div>
                <ul className="space-y-2 text-[15px] leading-relaxed text-ink-2">{doc.analysis.summary.map((s, i) => <li key={i} className="border-l-2 border-navy-soft pl-3">{s}</li>)}</ul>
              </div>
            )}
            {doc.analysis.symbols?.length > 0 && (
              <div className="mt-5">
                <div className="mb-2 text-[12px] font-medium uppercase tracking-[0.08em] text-faint">Symbols</div>
                <div className="flex flex-wrap gap-1.5">{doc.analysis.symbols.map((s) => <code key={s} className="rounded-md bg-paper-2 px-2 py-0.5 font-mono text-[12.5px]">{s}</code>)}</div>
              </div>
            )}
            {doc.analysis.headings?.length > 0 && (
              <div className="mt-5">
                <div className="mb-2 text-[12px] font-medium uppercase tracking-[0.08em] text-faint">Outline</div>
                <ul className="text-[14px] text-ink-2">{doc.analysis.headings.map((h, i) => <li key={i}>{h}</li>)}</ul>
              </div>
            )}
            <div className="mt-5">
              <div className="mb-2 text-[12px] font-medium uppercase tracking-[0.08em] text-faint">Keywords (TF-IDF)</div>
              <div className="flex flex-wrap gap-1.5">{doc.analysis.keywords.map((k) => <span key={k.term} className="rounded-full bg-navy-tint px-2.5 py-0.5 text-[13px] text-navy">{k.term}</span>)}</div>
            </div>
          </Card>
        ) : (
          <Card className="flex items-center justify-center text-[14px] text-muted">Select a document to see its analysis.</Card>
        )}
      </div>
    </PageFrame>
  );
}
