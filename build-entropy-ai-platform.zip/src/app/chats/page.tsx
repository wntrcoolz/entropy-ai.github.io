"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { PageFrame } from "@/components/PageFrame";
import { refreshConversations } from "@/components/AppShell";
import { IconTrash } from "@/components/icons";
import { getModel } from "@/lib/entropy/registry";

interface Conv { id: string; title: string; updatedAt: string; model: string }

export default function ChatsPage() {
  const [convs, setConvs] = useState<Conv[] | null>(null);
  const [q, setQ] = useState("");
  const load = () => fetch("/api/conversations").then((r) => r.json()).then((d) => setConvs(d.conversations ?? [])).catch(() => setConvs([]));
  useEffect(() => { load(); }, []);
  const list = (convs ?? []).filter((c) => c.title.toLowerCase().includes(q.toLowerCase()));
  return (
    <PageFrame title="Chats" subtitle="Every conversation is stored in your local database. Incognito chats are never saved.">
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search your chats" className="mb-5 w-full rounded-2xl border border-line bg-white px-4 py-3 text-[15px] outline-none placeholder:text-faint focus:border-line-2" />
      {convs === null ? <p className="text-muted">Loading</p> : list.length === 0 ? <p className="text-muted">No chats found.</p> : (
        <div className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-white/70">
          {list.map((c) => (
            <div key={c.id} className="group flex items-center gap-4 px-5 py-3.5 hover:bg-paper-2">
              <Link href={`/?c=${c.id}`} className="min-w-0 flex-1">
                <div className="truncate text-[15.5px] text-ink">{c.title}</div>
                <div className="text-[12.5px] text-faint">{getModel(c.model)?.name ?? c.model} · {new Date(c.updatedAt).toLocaleString()}</div>
              </Link>
              <button aria-label="Delete" onClick={async () => { await fetch(`/api/conversations/${c.id}`, { method: "DELETE" }); load(); refreshConversations(); }} className="rounded-lg p-2 text-faint opacity-0 hover:bg-paper-3 hover:text-danger group-hover:opacity-100">
                <IconTrash size={16} />
              </button>
            </div>
          ))}
        </div>
      )}
    </PageFrame>
  );
}
