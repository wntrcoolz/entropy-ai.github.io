import { Card, PageFrame, Stat } from "@/components/PageFrame";
import { LossChart } from "@/components/LossChart";
import { getBrainStatus } from "@/lib/entropy/status";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const fmt = (n: number) => (n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : n >= 1e3 ? (n / 1e3).toFixed(1) + "K" : String(n));

export default async function BrainPage() {
  const s = await getBrainStatus();
  return (
    <PageFrame title="Brain" subtitle="Live status of Entropy's own models, checkpoints, evaluation results, memory and data. Everything shown here is read from the checkpoint files and database at request time.">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Conversations" value={s.stats.conversations ?? "n/a"} hint={`${s.stats.messages ?? 0} messages`} />
        <Stat label="Memories" value={s.stats.memories ?? "n/a"} hint="stored notes, not training" />
        <Stat label="Documents" value={s.stats.documents ?? "n/a"} hint={`${s.stats.chunks ?? 0} indexed chunks`} />
        <Stat label="Feedback" value={s.stats.feedback ?? "n/a"} hint={`${s.stats.feedbackConsented ?? 0} consented, ${s.stats.feedbackPositive ?? 0} positive`} />
      </div>

      <h2 className="mb-3 mt-10 font-serif text-[24px] text-ink">Models</h2>
      <div className="space-y-4">
        {s.models.map((m) => {
          const active = m.checkpoints.find((c) => c.stage === m.active);
          const ev = active?.eval;
          return (
            <Card key={m.id}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2.5">
                    <span className={`h-2 w-2 rounded-full ${active ? "bg-ok" : "bg-danger"}`} />
                    <h3 className="font-serif text-[21px] text-ink">{m.name}</h3>
                  </div>
                  <p className="mt-0.5 text-[14px] text-muted">{m.tagline}. {m.description}.</p>
                </div>
                <div className="text-right text-[13px] text-muted">
                  <div className="font-serif text-[22px] text-ink">{fmt(m.params)}</div>
                  parameters
                </div>
              </div>
              <div className="mt-4 grid gap-5 md:grid-cols-[1fr_260px]">
                <div>
                  <LossChart series={m.checkpoints.map((c, i) => ({ label: c.stage, points: c.history, color: i === 0 ? "#0a0a62" : "#8b8fc4" }))} />
                  <div className="mt-1 flex gap-4 text-[12px] text-muted">
                    {m.checkpoints.map((c, i) => <span key={c.stage} className="flex items-center gap-1.5"><span className="h-0.5 w-4" style={{ background: i === 0 ? "#0a0a62" : "#8b8fc4" }} />{c.stage} loss</span>)}
                  </div>
                </div>
                <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-[13px]">
                  <dt className="text-faint">Layers</dt><dd className="text-ink-2">{m.config.nLayer}</dd>
                  <dt className="text-faint">Width</dt><dd className="text-ink-2">{m.config.dModel}</dd>
                  <dt className="text-faint">Heads</dt><dd className="text-ink-2">{m.config.nHead}</dd>
                  <dt className="text-faint">Context</dt><dd className="text-ink-2">{m.config.ctx} tokens</dd>
                  <dt className="text-faint">Vocabulary</dt><dd className="text-ink-2">{m.config.vocabSize}</dd>
                  <dt className="text-faint">Active</dt><dd className="text-ink-2">{active ? `${active.stage} @ ${active.step}` : "not trained"}</dd>
                  <dt className="text-faint">Held-out ppl</dt><dd className="text-ink-2">{ev ? ev.heldOutChat.perplexity : "n/a"}</dd>
                  <dt className="text-faint">Benchmark</dt><dd className="text-ink-2">{ev ? `${ev.benchmark.passed}/${ev.benchmark.total}` : "n/a"}</dd>
                  <dt className="text-faint">In memory</dt><dd className="text-ink-2">{m.loaded ? "loaded" : "on demand"}</dd>
                </dl>
              </div>
            </Card>
          );
        })}
      </div>

      <h2 className="mb-3 mt-10 font-serif text-[24px] text-ink">Effort levels</h2>
      <Card className="overflow-x-auto p-0">
        <table className="w-full text-left text-[13.5px]">
          <thead className="text-[11.5px] uppercase tracking-[0.08em] text-faint"><tr>{["Level", "Max tokens", "Candidates", "Temperature", "Top-k / top-p", "Retrieval"].map((h) => <th key={h} className="px-5 py-3 font-medium">{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-line">
            {s.levels.map((l) => (
              <tr key={l.id}><td className="px-5 py-2.5 text-ink">{l.label}</td><td className="px-5 text-ink-2">{l.maxNewTokens}</td><td className="px-5 text-ink-2">{l.candidates}</td><td className="px-5 text-ink-2">{l.temperature}</td><td className="px-5 text-ink-2">{l.topK} / {l.topP}</td><td className="px-5 text-ink-2">{l.retrievalDepth} passages</td></tr>
            ))}
          </tbody>
        </table>
      </Card>

      <div className="mt-10 grid gap-4 md:grid-cols-2">
        <Card>
          <h3 className="font-serif text-[19px] text-ink">Retrieval and memory</h3>
          <p className="mt-1.5 text-[14px] leading-relaxed text-muted">Embeddings: <span className="text-ink-2">{s.embeddings.model}</span>, {s.embeddings.dim} dimensions, signed feature hashing over words, bigrams and character trigrams. Used for memory recall, document search and web passage ranking.</p>
        </Card>
        <Card>
          <h3 className="font-serif text-[19px] text-ink">Feedback dataset</h3>
          <p className="mt-1.5 text-[14px] leading-relaxed text-muted">Only consented, positively rated turns are exported for curation. Ratings never change the running model.</p>
          <a href="/api/feedback/export" className="mt-3 inline-block rounded-full border border-line-2 px-4 py-1.5 text-[13px] text-ink-2 hover:bg-paper-2">Download curated JSONL</a>
        </Card>
        <Card>
          <h3 className="font-serif text-[19px] text-ink">Runtime</h3>
          <p className="mt-1.5 text-[14px] text-muted">Node {s.runtime.node} on {s.runtime.platform}, {s.runtime.memoryMB} MB resident. Database {s.dbOk ? "connected" : "unreachable"}. Inference runs on CPU in-process.</p>
        </Card>
        <Card>
          <h3 className="font-serif text-[19px] text-ink">Coming models</h3>
          <ul className="mt-1.5 space-y-1 text-[14px] text-muted">{s.coming.map((c) => <li key={c.name}><span className="text-ink-2">{c.name}</span>, {c.description.toLowerCase()}. No release date.</li>)}</ul>
        </Card>
      </div>
    </PageFrame>
  );
}
