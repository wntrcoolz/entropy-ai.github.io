import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { AppShell } from "@/components/AppShell";
import "./globals.css";

export const metadata: Metadata = {
  title: "Entropy",
  description: "Entropy, the AI assistant by Sequentia, running on its own language models.",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/entropy-logo.svg", apple: "/entropy-logo.svg" },
  appleWebApp: { capable: true, title: "Entropy", statusBarStyle: "default" },
};

export const viewport: Viewport = { themeColor: "#f9f8f5", width: "device-width", initialScale: 1, viewportFit: "cover" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
