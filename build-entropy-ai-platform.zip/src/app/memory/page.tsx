"use client";

import { useEffect, useState } from "react";
import { Card, PageFrame } from "@/components/PageFrame";
import { IconTrash } from "@/components/icons";

interface Mem { id: string; content: string; source: string; createdAt: string }

export default function MemoryPage() {
  const [items, setItems] = useState<Mem[] | null>(null);
  const [text, setText] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const load = () => fetch("/api/memories").then((r) => r.json()).then((d) => setItems(d.memories ?? [])).catch(() => setItems([]));
  useEffect(() => { load(); }, []);
  async function add() {
    setErr(null);
    const r = await fetch("/api/memories", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: text }) });
    if (!r.ok) { setErr((await r.json()).error); return; }
    setText("");
    load();
  }
  async function remove(id: string) {
    await fetch(`/api/memories?id=${id}`, { method: "DELETE" });
    load();
  }
  return (
    <PageFrame title="Memory" subtitle="Long-term memory is a set of notes stored in the database. Entropy embeds each note and retrieves the most relevant ones into its context window when you chat. Saving a memory does not train or change the model.">
      <Card className="mb-6">
        <div className="text-[14px] text-ink-2">Add a note</div>
        <div className="mt-2 flex gap-2">
          <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} placeholder="For example: I prefer concise answers with Python examples" className="flex-1 rounded-xl bg-paper-2 px-4 py-2.5 text-[15px] outline-none placeholder:text-faint" />
          <button onClick={add} disabled={!text.trim()} className="rounded-xl bg-navy px-5 text-[14px] text-white hover:bg-navy-2 disabled:opacity-50">Save</button>
        </div>
        {err && <p className="mt-2 text-[13px] text-danger">{err}</p>}
        <p className="mt-3 text-[12.5px] text-faint">You can also say &quot;Remember that ...&quot; in any chat. Incognito chats never read or write memory.</p>
      </Card>
      {items === null ? <p className="text-muted">Loading</p> : items.length === 0 ? <p className="text-muted">No memories yet.</p> : (
        <div className="space-y-2">
          {items.map((m) => (
            <div key={m.id} className="group flex items-start gap-3 rounded-2xl border border-line bg-white/70 px-5 py-3.5">
              <div className="flex-1">
                <div className="text-[15px] text-ink">{m.content}</div>
                <div className="mt-0.5 text-[12px] text-faint">{m.source === "chat" ? "Saved from chat" : "Added manually"} · {new Date(m.createdAt).toLocaleString()}</div>
              </div>
              <button aria-label="Forget" onClick={() => remove(m.id)} className="rounded-lg p-2 text-faint hover:bg-paper-2 hover:text-danger"><IconTrash size={16} /></button>
            </div>
          ))}
          <button onClick={async () => { await fetch("/api/memories?id=all", { method: "DELETE" }); load(); }} className="mt-3 text-[13px] text-muted underline-offset-2 hover:text-danger hover:underline">Forget everything</button>
        </div>
      )}
    </PageFrame>
  );
}
