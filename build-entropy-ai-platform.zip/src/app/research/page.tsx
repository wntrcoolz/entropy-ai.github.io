import { Card, PageFrame } from "@/components/PageFrame";
import { getBrainStatus } from "@/lib/entropy/status";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

interface EvalCase { category: string; prompt: string; output: string; pass: boolean }

export default async function ResearchPage() {
  const s = await getBrainStatus();
  const tk = s.tokenizerExperiments;
  const ds = s.dataset as { shards?: Record<string, number>; sources?: { name: string; chars?: number; dialogues?: number }[]; bytesPerToken?: number; sft?: { train: number; eval: number } } | null;
  return (
    <PageFrame title="Model research" subtitle="Sequentia's research track for Entropy's own models: tokenizer experiments, architecture, data, pretraining, supervised fine-tuning, evaluation and checkpoints. Pipelines live in scripts/ and research/.">
      <Section n="01" title="Tokenizer experiments">
        <p className="mb-3 text-[14px] text-muted">Byte-level BPE trained from scratch at several vocabulary sizes. Compression is measured as bytes per token on held-out text and code. {tk?.note}</p>
        {tk ? (
          <Card className="overflow-x-auto p-0">
            <table className="w-full text-left text-[13.5px]">
              <thead className="text-[11.5px] uppercase tracking-[0.08em] text-faint"><tr>{["Vocabulary", "Bytes/token text", "Bytes/token code", "Train time"].map((h) => <th key={h} className="px-5 py-3 font-medium">{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-line">{tk.results.map((r, i) => <tr key={i}><td className="px-5 py-2.5">{r.vocab}</td><td className="px-5">{r.bytesPerTokenText}</td><td className="px-5">{r.bytesPerTokenCode}</td><td className="px-5">{r.trainMs} ms</td></tr>)}</tbody>
            </table>
          </Card>
        ) : <Missing cmd="npm run research:tokenizer" />}
      </Section>

      <Section n="02" title="Transformer architecture">
        <Card>
          <p className="text-[14px] leading-relaxed text-muted">Decoder-only Transformer implemented from scratch in TypeScript (src/lib/entropy/gpt.ts): learned token and position embeddings, pre-LayerNorm blocks with causal multi-head self-attention and a GELU MLP, residual connections, a final LayerNorm and an output head tied to the token embedding. The full backward pass is hand-derived and verified against finite differences in the test suite. Inference uses a key/value cache.</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-4">
            {s.models.map((m) => <Spec key={m.id} name={m.name.replace("Entropy ", "")} rows={[["params", m.params.toLocaleString()], ["layers", m.config.nLayer], ["width", m.config.dModel], ["heads", m.config.nHead]]} />)}
            <Spec name="50M target" rows={[["params", s.research50m.params.toLocaleString()], ["layers", s.research50m.config.nLayer], ["width", s.research50m.config.dModel], ["context", s.research50m.config.ctx]]} />
          </div>
          <p className="mt-4 rounded-xl bg-navy-tint px-4 py-3 text-[13.5px] leading-relaxed text-navy">The 50M-parameter configuration uses the same architecture and checkpoint format, but pretraining it on a meaningful corpus (billions of tokens) requires GPU infrastructure. research/train_50m.py provides the PyTorch training script that exports weights in Entropy&apos;s format. It has not been trained in this environment.</p>
        </Card>
      </Section>

      <Section n="03" title="Dataset preparation">
        {ds ? (
          <Card>
            <ul className="space-y-1 text-[14px] text-ink-2">{ds.sources?.map((x) => <li key={x.name}>{x.name}: <span className="text-muted">{x.chars ? `${x.chars.toLocaleString()} chars` : `${x.dialogues} dialogues`}</span></li>)}</ul>
            <div className="mt-3 flex flex-wrap gap-2">{Object.entries(ds.shards ?? {}).map(([k, v]) => <span key={k} className="rounded-full bg-paper-2 px-3 py-1 text-[12.5px] text-ink-2">{k}: {v.toLocaleString()} tokens</span>)}</div>
            <p className="mt-3 text-[13px] text-muted">Average {ds.bytesPerToken} bytes per token. SFT split: {ds.sft?.train} train, {ds.sft?.eval} held-out dialogues. The corpus is small and hand-written, which is the main limit on model quality.</p>
          </Card>
        ) : <Missing cmd="npm run data:prepare" />}
      </Section>

      <Section n="04" title="Pretraining and supervised fine-tuning">
        <div className="grid gap-3 md:grid-cols-3">
          {s.models.map((m) => (
            <Card key={m.id}>
              <div className="font-serif text-[17px] text-ink">{m.name}</div>
              {m.checkpoints.length === 0 ? <p className="mt-2 text-[13px] text-danger">No checkpoints. Run npm run train:{m.id.split("-")[0]}</p> : m.checkpoints.map((c) => (
                <div key={c.stage} className="mt-2.5 border-t border-line pt-2.5 text-[13px] text-muted">
                  <div className="flex justify-between"><span className="text-ink-2">{c.stage}{m.active === c.stage ? " (active)" : ""}</span><span>{(c.bytes / 1e6).toFixed(2)} MB</span></div>
                  <div>{c.step} steps · {c.tokensSeen.toLocaleString()} tokens · {c.trainSeconds}s CPU</div>
                  <div>final loss {c.history.at(-1)?.loss ?? "n/a"}{c.parent ? ` · from ${c.parent}` : ""}</div>
                </div>
              ))}
            </Card>
          ))}
        </div>
      </Section>

      <Section n="05" title="Evaluation benchmarks">
        {s.models.map((m) => {
          const ev = m.checkpoints.find((c) => c.stage === m.active)?.eval as { heldOutText: { perplexity: number; accuracy: number }; heldOutChat: { perplexity: number; accuracy: number }; benchmark: { passed: number; total: number; cases: EvalCase[] } } | null | undefined;
          return (
            <Card key={m.id} className="mb-3">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <div className="font-serif text-[17px] text-ink">{m.name}</div>
                {ev && <div className="text-[13px] text-muted">prose ppl {ev.heldOutText.perplexity} · chat ppl {ev.heldOutChat.perplexity} · next-token acc {(ev.heldOutChat.accuracy * 100).toFixed(1)}% · behaviour {ev.benchmark.passed}/{ev.benchmark.total}</div>}
              </div>
              {ev ? (
                <details className="mt-2">
                  <summary className="cursor-pointer text-[13px] text-navy">Show greedy outputs</summary>
                  <div className="mt-2 space-y-1.5">{ev.benchmark.cases.map((c, i) => (
                    <div key={i} className="rounded-lg bg-paper-2 px-3 py-2 text-[13px]">
                      <span className={c.pass ? "text-ok" : "text-danger"}>{c.pass ? "pass" : "fail"}</span> <span className="text-faint">{c.category}</span> <span className="text-ink-2">{c.prompt}</span>
                      <div className="mt-0.5 font-mono text-[12px] text-muted">{c.output || "(empty)"}</div>
                    </div>
                  ))}</div>
                </details>
              ) : <p className="mt-2 text-[13px] text-muted">Not evaluated yet. Run npm run eval.</p>}
            </Card>
          );
        })}
      </Section>
    </PageFrame>
  );
}

function Section({ n, title, children }: { n: string; title: string; children: React.ReactNode }) {
  return (
    <section className="mb-10">
      <div className="mb-3 flex items-baseline gap-3"><span className="font-mono text-[12px] text-faint">{n}</span><h2 className="font-serif text-[24px] text-ink">{title}</h2></div>
      {children}
    </section>
  );
}

function Spec({ name, rows }: { name: string; rows: [string, string | number][] }) {
  return (
    <div className="rounded-xl bg-paper-2 px-3.5 py-3">
      <div className="text-[13.5px] text-ink">{name}</div>
      {rows.map(([k, v]) => <div key={k} className="flex justify-between text-[12px] text-muted"><span>{k}</span><span className="text-ink-2">{v}</span></div>)}
    </div>
  );
}

function Missing({ cmd }: { cmd: string }) {
  return <Card className="text-[13.5px] text-muted">Not generated yet. Run <code className="font-mono">{cmd}</code>.</Card>;
}
