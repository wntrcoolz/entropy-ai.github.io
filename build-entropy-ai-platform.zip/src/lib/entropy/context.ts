import type { BPETokenizer } from "./tokenizer";
import { SYSTEM_PROMPT } from "./registry";

export interface Turn { role: "user" | "assistant"; content: string }

export interface PromptInput {
  ctx: number;
  /** tokens reserved for generation */
  reserve: number;
  history: Turn[]; // last item is the current user message
  context: string[]; // retrieved passages (documents / web), highest priority first
  memories: string[];
  system?: string;
}

export interface PromptResult {
  tokens: number[];
  usedTurns: number;
  droppedTurns: number;
  contextTokens: number;
  memoryTokens: number;
  truncatedUser: boolean;
}

/**
 * Packs system prompt, memories, retrieved context and conversation history into
 * the model's fixed context window. Priority: system > current user message >
 * memories/context (capped share) > history (newest first). Nothing is silently
 * invented: anything that does not fit is dropped and reported.
 */
export function buildPrompt(tok: BPETokenizer, input: PromptInput): PromptResult {
  const S = (t: Parameters<BPETokenizer["special"]>[0]) => tok.special(t);
  const budget = input.ctx - input.reserve;
  const head = [S("<|bos|>"), S("<|system|>"), ...tok.encode(input.system ?? SYSTEM_PROMPT, false), S("<|end|>")];
  const turns = input.history.length ? input.history : [{ role: "user" as const, content: "" }];
  const current = turns[turns.length - 1];
  let userToks = tok.encode(current.content, false);
  const tail = [S("<|assistant|>")];
  const maxUser = Math.max(8, Math.floor((budget - head.length - tail.length) * 0.6));
  let truncatedUser = false;
  if (userToks.length > maxUser) { userToks = userToks.slice(-maxUser); truncatedUser = true; }
  const currentBlock = [S("<|user|>"), ...userToks, S("<|end|>")];
  let remaining = budget - head.length - currentBlock.length - tail.length;
  if (remaining < 0) throw new Error("Context window too small for the system prompt and message");

  // memories + retrieved context share at most 55% of what is left
  const ctxBudget = Math.floor(remaining * 0.55);
  const ctxToks: number[] = [];
  let memoryTokens = 0;
  const pieces = [...input.memories.map((m) => "Memory: " + m), ...input.context];
  for (const [i, piece] of pieces.entries()) {
    const room = ctxBudget - ctxToks.length - 2;
    if (room < 8) break;
    const enc = tok.encode(piece + "\n", false).slice(0, room);
    ctxToks.push(...enc);
    if (i < input.memories.length) memoryTokens += enc.length;
  }
  const contextBlock = ctxToks.length ? [S("<|context|>"), ...ctxToks, S("<|end|>")] : [];
  remaining -= contextBlock.length;

  const past: number[][] = [];
  let used = 0;
  for (let i = turns.length - 2; i >= 0; i--) {
    const t = turns[i];
    const block = [S(t.role === "user" ? "<|user|>" : "<|assistant|>"), ...tok.encode(t.content, false), S("<|end|>")];
    if (block.length > remaining) break;
    past.unshift(block);
    remaining -= block.length;
    used++;
  }
  const tokens = [...head, ...contextBlock, ...past.flat(), ...currentBlock, ...tail];
  return {
    tokens,
    usedTurns: used,
    droppedTurns: Math.max(0, turns.length - 1 - used),
    contextTokens: contextBlock.length,
    memoryTokens,
    truncatedUser,
  };
}
