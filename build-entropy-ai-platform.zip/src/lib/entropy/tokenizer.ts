/**
 * Entropy byte-level BPE tokenizer, written from scratch.
 *
 * - Base vocabulary: 256 raw bytes (any UTF-8 text is representable, no UNK token).
 * - Special tokens are reserved immediately after the bytes.
 * - Merges are learned from a corpus with the classic BPE algorithm over a
 *   GPT-2 style pre-tokenization (words keep their leading space).
 */

export const SPECIAL_TOKENS = [
  "<|pad|>",
  "<|bos|>",
  "<|end|>",
  "<|system|>",
  "<|user|>",
  "<|assistant|>",
  "<|context|>",
] as const;

export type SpecialToken = (typeof SPECIAL_TOKENS)[number];

const PRETOKENIZE =
  /'s|'t|'re|'ve|'m|'ll|'d| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+/gu;

const SPECIAL_SPLIT = new RegExp(
  "(" + SPECIAL_TOKENS.map((t) => t.replace(/[|]/g, "\\|")).join("|") + ")",
  "g",
);

export interface TokenizerJSON {
  version: 1;
  type: "byte-bpe";
  merges: [number, number][];
  specials: string[];
}

const encoder = new TextEncoder();

export class BPETokenizer {
  readonly merges: [number, number][];
  private readonly ranks = new Map<string, number>();
  private readonly vocabBytes: Uint8Array[] = [];
  private readonly specialIds = new Map<string, number>();
  private readonly cache = new Map<string, number[]>();

  constructor(merges: [number, number][] = []) {
    this.merges = merges;
    for (let i = 0; i < 256; i++) this.vocabBytes.push(new Uint8Array([i]));
    SPECIAL_TOKENS.forEach((tok, i) => {
      this.specialIds.set(tok, 256 + i);
      this.vocabBytes.push(encoder.encode(tok));
    });
    merges.forEach(([a, b], i) => {
      const id = BPETokenizer.firstMergeId + i;
      this.ranks.set(a + "," + b, id);
      const ab = new Uint8Array(this.vocabBytes[a].length + this.vocabBytes[b].length);
      ab.set(this.vocabBytes[a], 0);
      ab.set(this.vocabBytes[b], this.vocabBytes[a].length);
      this.vocabBytes.push(ab);
    });
  }

  static readonly firstMergeId = 256 + SPECIAL_TOKENS.length;

  get vocabSize(): number {
    return this.vocabBytes.length;
  }

  special(tok: SpecialToken): number {
    return this.specialIds.get(tok)!;
  }

  isSpecial(id: number): boolean {
    return id >= 256 && id < BPETokenizer.firstMergeId;
  }

  /** Learn merges until the vocabulary reaches `vocabSize`. */
  static train(text: string, vocabSize: number, onProgress?: (n: number) => void): BPETokenizer {
    const numMerges = vocabSize - BPETokenizer.firstMergeId;
    if (numMerges < 0) throw new Error("vocabSize too small for byte vocabulary + specials");
    const wordFreq = new Map<string, number>();
    for (const piece of text.split(SPECIAL_SPLIT)) {
      if (!piece || (SPECIAL_TOKENS as readonly string[]).includes(piece)) continue;
      for (const m of piece.matchAll(PRETOKENIZE)) {
        wordFreq.set(m[0], (wordFreq.get(m[0]) ?? 0) + 1);
      }
    }
    const words: number[][] = [];
    const freqs: number[] = [];
    for (const [w, f] of wordFreq) {
      words.push(Array.from(encoder.encode(w)));
      freqs.push(f);
    }
    const merges: [number, number][] = [];
    for (let m = 0; m < numMerges; m++) {
      const pairCounts = new Map<number, number>();
      for (let w = 0; w < words.length; w++) {
        const ids = words[w];
        for (let i = 0; i < ids.length - 1; i++) {
          const key = ids[i] * 65536 + ids[i + 1];
          pairCounts.set(key, (pairCounts.get(key) ?? 0) + freqs[w]);
        }
      }
      let bestKey = -1;
      let bestCount = 1; // a merge must occur at least twice to be useful
      for (const [k, c] of pairCounts) {
        if (c > bestCount || (c === bestCount && bestKey !== -1 && k < bestKey)) {
          bestCount = c;
          bestKey = k;
        }
      }
      if (bestKey < 0) break;
      const a = Math.floor(bestKey / 65536);
      const b = bestKey % 65536;
      const newId = BPETokenizer.firstMergeId + merges.length;
      merges.push([a, b]);
      for (let w = 0; w < words.length; w++) {
        const ids = words[w];
        if (ids.length < 2) continue;
        const out: number[] = [];
        for (let i = 0; i < ids.length; i++) {
          if (i < ids.length - 1 && ids[i] === a && ids[i + 1] === b) {
            out.push(newId);
            i++;
          } else out.push(ids[i]);
        }
        words[w] = out;
      }
      if (onProgress && m % 100 === 0) onProgress(m);
    }
    return new BPETokenizer(merges);
  }

  private encodeWord(word: string): number[] {
    const cached = this.cache.get(word);
    if (cached) return cached;
    let ids = Array.from(encoder.encode(word));
    while (ids.length >= 2) {
      let bestRank = Infinity;
      let bestIdx = -1;
      for (let i = 0; i < ids.length - 1; i++) {
        const r = this.ranks.get(ids[i] + "," + ids[i + 1]);
        if (r !== undefined && r < bestRank) {
          bestRank = r;
          bestIdx = i;
        }
      }
      if (bestIdx < 0) break;
      ids = [...ids.slice(0, bestIdx), bestRank, ...ids.slice(bestIdx + 2)];
    }
    if (this.cache.size < 50000) this.cache.set(word, ids);
    return ids;
  }

  /** Encode text. Special token strings are recognised only when `allowSpecial` is true. */
  encode(text: string, allowSpecial = true): number[] {
    const out: number[] = [];
    const pieces = allowSpecial ? text.split(SPECIAL_SPLIT) : [text];
    for (const piece of pieces) {
      if (!piece) continue;
      const sid = allowSpecial ? this.specialIds.get(piece) : undefined;
      if (sid !== undefined) {
        out.push(sid);
        continue;
      }
      for (const m of piece.matchAll(PRETOKENIZE)) out.push(...this.encodeWord(m[0]));
    }
    return out;
  }

  tokenBytes(id: number): Uint8Array {
    return this.vocabBytes[id] ?? new Uint8Array();
  }

  decode(ids: number[], skipSpecial = true): string {
    const parts: number[] = [];
    for (const id of ids) {
      if (skipSpecial && this.isSpecial(id)) continue;
      parts.push(...this.tokenBytes(id));
    }
    return new TextDecoder().decode(new Uint8Array(parts));
  }

  /** A streaming decoder that never emits half of a multi-byte UTF-8 character. */
  streamDecoder(): (id: number) => string {
    const dec = new TextDecoder("utf-8");
    return (id: number) => (this.isSpecial(id) ? "" : dec.decode(this.tokenBytes(id), { stream: true }));
  }

  toJSON(): TokenizerJSON {
    return { version: 1, type: "byte-bpe", merges: this.merges, specials: [...SPECIAL_TOKENS] };
  }

  static fromJSON(json: TokenizerJSON): BPETokenizer {
    if (json.type !== "byte-bpe") throw new Error("Unsupported tokenizer type");
    return new BPETokenizer(json.merges);
  }
}
