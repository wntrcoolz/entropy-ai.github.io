import { GPT, geluForward, layernormForward, matmulForward, rng } from "./gpt";

/**
 * Incremental decoding with a key/value cache: each new token costs one
 * single-row pass through every block instead of re-running the full prefix.
 */
export class KVSession {
  readonly model: GPT;
  pos = 0;
  private k: Float32Array;
  private v: Float32Array;
  private x: Float32Array;
  private buf: Float32Array;
  private qkv: Float32Array;
  private y: Float32Array;
  private h: Float32Array;
  private hg: Float32Array;
  private scores: Float32Array;
  readonly logits: Float32Array;

  constructor(model: GPT) {
    this.model = model;
    const { nLayer: L, ctx: T, dModel: C, dFF: F, vocabSize: V } = model.config;
    this.k = new Float32Array(L * T * C);
    this.v = new Float32Array(L * T * C);
    this.x = new Float32Array(C);
    this.buf = new Float32Array(C);
    this.qkv = new Float32Array(3 * C);
    this.y = new Float32Array(C);
    this.h = new Float32Array(F);
    this.hg = new Float32Array(F);
    this.scores = new Float32Array(T);
    this.logits = new Float32Array(V);
  }

  /** Feed one token; returns next-token logits (a view reused across calls). */
  step(token: number): Float32Array {
    const m = this.model, p = m.p;
    const { nLayer: L, ctx: T, dModel: C, dFF: F, nHead: NH, vocabSize: V } = m.config;
    if (this.pos >= T) throw new Error(`Context window full (${T} tokens)`);
    if (token < 0 || token >= V) throw new Error(`Token id ${token} outside vocabulary`);
    const t = this.pos, x = this.x, hs = C / NH, scale = 1 / Math.sqrt(hs);
    for (let i = 0; i < C; i++) x[i] = p.wte[token * C + i] + p.wpe[t * C + i];
    for (let l = 0; l < L; l++) {
      const sl = (a: Float32Array, per: number) => a.subarray(l * per, (l + 1) * per);
      layernormForward(this.buf, null, null, x, sl(p.ln1w, C), sl(p.ln1b, C), 1, C);
      matmulForward(this.qkv, this.buf, sl(p.qkvw, 3 * C * C), sl(p.qkvb, 3 * C), 1, C, 3 * C);
      const kc = l * T * C;
      for (let i = 0; i < C; i++) { this.k[kc + t * C + i] = this.qkv[C + i]; this.v[kc + t * C + i] = this.qkv[2 * C + i]; }
      for (let h = 0; h < NH; h++) {
        let max = -Infinity;
        for (let t2 = 0; t2 <= t; t2++) {
          let s = 0;
          const ko = kc + t2 * C + h * hs;
          for (let i = 0; i < hs; i++) s += this.qkv[h * hs + i] * this.k[ko + i];
          s *= scale;
          this.scores[t2] = s;
          if (s > max) max = s;
        }
        let sum = 0;
        for (let t2 = 0; t2 <= t; t2++) { const e = Math.exp(this.scores[t2] - max); this.scores[t2] = e; sum += e; }
        for (let i = 0; i < hs; i++) this.y[h * hs + i] = 0;
        for (let t2 = 0; t2 <= t; t2++) {
          const w = this.scores[t2] / sum, vo = kc + t2 * C + h * hs;
          for (let i = 0; i < hs; i++) this.y[h * hs + i] += w * this.v[vo + i];
        }
      }
      matmulForward(this.buf, this.y, sl(p.attprojw, C * C), sl(p.attprojb, C), 1, C, C);
      for (let i = 0; i < C; i++) x[i] += this.buf[i];
      layernormForward(this.buf, null, null, x, sl(p.ln2w, C), sl(p.ln2b, C), 1, C);
      matmulForward(this.h, this.buf, sl(p.fcw, F * C), sl(p.fcb, F), 1, C, F);
      geluForward(this.hg, this.h, F);
      matmulForward(this.buf, this.hg, sl(p.fcprojw, C * F), sl(p.fcprojb, C), 1, F, C);
      for (let i = 0; i < C; i++) x[i] += this.buf[i];
    }
    layernormForward(this.buf, null, null, x, p.lnfw, p.lnfb, 1, C);
    matmulForward(this.logits, this.buf, p.wte, null, 1, C, V);
    this.pos++;
    return this.logits;
  }

  prefill(tokens: number[]): Float32Array {
    if (tokens.length === 0) throw new Error("Empty prompt");
    let out = this.logits;
    for (const tok of tokens) out = this.step(tok);
    return out;
  }
}

export interface SamplingOptions {
  temperature: number;
  topK: number;
  topP: number;
  repetitionPenalty: number;
  /** Subtract a small logit penalty for tokens repeated in the recent window. */
  frequencyPenalty?: number;
  /** Block a token that would recreate an earlier n-gram in this response. */
  noRepeatNgramSize?: number;
  seed?: number;
}

/** Log-softmax probability of `token` under raw logits (used for candidate scoring). */
export function logProb(logits: Float32Array, token: number): number {
  let max = -Infinity;
  for (let i = 0; i < logits.length; i++) if (logits[i] > max) max = logits[i];
  let sum = 0;
  for (let i = 0; i < logits.length; i++) sum += Math.exp(logits[i] - max);
  return logits[token] - max - Math.log(sum);
}

export function sample(
  logits: Float32Array,
  recent: number[],
  opts: SamplingOptions,
  rand: () => number,
  banned?: Set<number>,
  generated: readonly number[] = recent,
): number {
  const V = logits.length;
  const adj = new Float32Array(logits);
  if (opts.repetitionPenalty !== 1) {
    for (const t of new Set(recent)) {
      if (t >= 0 && t < V) adj[t] = adj[t] > 0 ? adj[t] / opts.repetitionPenalty : adj[t] * opts.repetitionPenalty;
    }
  }
  const frequencyPenalty = Math.max(0, opts.frequencyPenalty ?? 0);
  if (frequencyPenalty > 0) {
    const counts = new Map<number, number>();
    for (const t of recent) counts.set(t, (counts.get(t) ?? 0) + 1);
    for (const [t, count] of counts) if (t >= 0 && t < V && count > 1) adj[t] -= frequencyPenalty * (count - 1);
  }
  if (banned) for (const b of banned) if (b >= 0 && b < V) adj[b] = -Infinity;

  // Block immediate copies and any continuation that would repeat an n-gram
  // already emitted. Keep an unfiltered fallback in case a tiny vocabulary has
  // no legal continuation after other token bans.
  const ngram = Math.floor(opts.noRepeatNgramSize ?? 0);
  const block = new Set<number>();
  if (generated.length && generated[generated.length - 1] >= 0) block.add(generated[generated.length - 1]);
  if (ngram >= 2 && generated.length >= ngram - 1) {
    const prefix = generated.slice(generated.length - (ngram - 1));
    for (let start = 0; start + ngram <= generated.length; start++) {
      let match = true;
      for (let j = 0; j < prefix.length; j++) {
        if (generated[start + j] !== prefix[j]) { match = false; break; }
      }
      if (match) block.add(generated[start + ngram - 1]);
    }
  }
  for (const t of block) if (t >= 0 && t < V) adj[t] = -Infinity;

  let idx = Array.from({ length: V }, (_, i) => i).filter((i) => Number.isFinite(adj[i]));
  if (!idx.length) {
    // First relax only the loop-prevention mask; explicit `banned` tokens stay banned.
    for (const t of block) if ((!banned || !banned.has(t)) && t >= 0 && t < V) adj[t] = logits[t];
    idx = Array.from({ length: V }, (_, i) => i).filter((i) => Number.isFinite(adj[i]));
  }
  if (!idx.length) throw new Error("No sampleable token remains after token constraints");
  if (opts.temperature <= 0) {
    let best = idx[0];
    for (const i of idx) if (adj[i] > adj[best]) best = i;
    return best;
  }
  idx.sort((a, b) => adj[b] - adj[a]);
  const k = Math.min(opts.topK > 0 ? opts.topK : V, idx.length);
  const top = idx.slice(0, k);
  const max = adj[top[0]];
  const probs = top.map((i) => Math.exp((adj[i] - max) / opts.temperature));
  const total = probs.reduce((a, b) => a + b, 0);
  let cum = 0, cut = top.length;
  for (let i = 0; i < top.length; i++) {
    cum += probs[i] / total;
    if (cum >= Math.max(0, Math.min(1, opts.topP))) { cut = i + 1; break; }
  }
  const kept = probs.slice(0, cut);
  const keptTotal = kept.reduce((a, b) => a + b, 0);
  let r = rand() * keptTotal;
  for (let i = 0; i < cut; i++) {
    r -= kept[i];
    if (r <= 0) return top[i];
  }
  return top[cut - 1];
}

export interface Candidate { tokens: number[]; meanLogProb: number; stoppedOnEnd: boolean }

/**
 * Generate `n` independent samples from the same prompt and score each by its
 * mean token log-likelihood under the model (best-of-N reranking).
 */
export function generateCandidates(
  model: GPT, prompt: number[], maxNew: number, n: number, stopIds: Set<number>,
  opts: SamplingOptions, banned?: Set<number>, onToken?: (tok: number, cand: number) => boolean | void,
): Candidate[] {
  const out: Candidate[] = [];
  const base = new KVSession(model);
  const prefixLogits = new Float32Array(base.prefill(prompt));
  for (let c = 0; c < n; c++) {
    const rand = rng((opts.seed ?? Date.now()) + c * 7919);
    // Each candidate re-uses a fresh session prefilled with the prompt.
    const sess = c === 0 ? base : new KVSession(model);
    let logits: Float32Array = c === 0 ? prefixLogits : new Float32Array(sess.prefill(prompt));
    const tokens: number[] = [];
    let lp = 0, stopped = false;
    const limit = Math.min(maxNew, model.config.ctx - prompt.length);
    for (let i = 0; i < limit; i++) {
      const tok = sample(logits, tokens.slice(-64), opts, rand, banned, tokens);
      lp += logProb(logits, tok);
      if (stopIds.has(tok)) { stopped = true; break; }
      tokens.push(tok);
      if (onToken && onToken(tok, c) === false) break;
      if (sess.pos >= model.config.ctx) break;
      logits = sess.step(tok);
    }
    out.push({ tokens, meanLogProb: lp / Math.max(1, tokens.length + (stopped ? 1 : 0)), stoppedOnEnd: stopped });
  }
  return out;
}
