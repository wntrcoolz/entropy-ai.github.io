import fs from "node:fs";
import path from "node:path";
import { count, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { chunks, conversations, documents, feedback, memories, messages } from "@/db/schema";
import { activeStage, CHECKPOINT_ROOT, listCheckpoints, readJSON } from "./checkpoint";
import { countParams } from "./gpt";
import { loadedModels } from "./engine";
import { COMING_MODELS, LEVELS, MODELS, RESEARCH_50M } from "./registry";
import { EMBED_DIM, EMBED_MODEL } from "./text";

export async function getBrainStatus() {
  const models = MODELS.map((m) => {
    const cps = listCheckpoints(m.id);
    const evalFile = (stage: string) => {
      const f = path.join(CHECKPOINT_ROOT, m.id, stage, "eval.json");
      return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, "utf8")) : null;
    };
    return {
      id: m.id, name: m.name, tagline: m.tagline, description: m.description, config: m.config,
      params: countParams(m.config), codeMix: m.codeMix, train: m.train,
      active: activeStage(m.id), loaded: loadedModels().includes(m.id),
      checkpoints: cps.map((c) => ({ stage: c.stage, bytes: c.bytes, step: c.meta.step, tokensSeen: c.meta.tokensSeen, trainSeconds: c.meta.trainSeconds, createdAt: c.meta.createdAt, parent: c.meta.parent, history: c.meta.history, eval: evalFile(c.stage) })),
    };
  });
  const safeCount = async (q: Promise<{ n: number }[]>) => { try { return (await q)[0]?.n ?? 0; } catch { return null; } };
  const stats = {
    conversations: await safeCount(db.select({ n: count() }).from(conversations)),
    messages: await safeCount(db.select({ n: count() }).from(messages)),
    memories: await safeCount(db.select({ n: count() }).from(memories)),
    documents: await safeCount(db.select({ n: count() }).from(documents)),
    chunks: await safeCount(db.select({ n: count() }).from(chunks)),
    feedback: await safeCount(db.select({ n: count() }).from(feedback)),
    feedbackPositive: await safeCount(db.select({ n: count() }).from(feedback).where(eq(feedback.rating, 1))),
    feedbackConsented: await safeCount(db.select({ n: count() }).from(feedback).where(eq(feedback.consent, true))),
  };
  let dbOk = true;
  try { await db.execute(sql`select 1`); } catch { dbOk = false; }
  return {
    generatedAt: new Date().toISOString(),
    dbOk,
    models,
    coming: COMING_MODELS,
    levels: LEVELS,
    research50m: { config: RESEARCH_50M, params: countParams(RESEARCH_50M) },
    embeddings: { model: EMBED_MODEL, dim: EMBED_DIM },
    stats,
    dataset: readJSON<Record<string, unknown>>("research/dataset-stats.json"),
    tokenizerExperiments: readJSON<{ results: { vocab: number; bytesPerTokenText: number; bytesPerTokenCode: number; trainMs: number }[]; note: string }>("research/tokenizer-experiments.json"),
    runtime: { node: process.version, platform: process.platform, memoryMB: Math.round(process.memoryUsage().rss / 1e6) },
  };
}

export type BrainStatus = Awaited<ReturnType<typeof getBrainStatus>>;
