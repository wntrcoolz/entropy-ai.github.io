/**
 * Entropy embeddings + text analysis, implemented without any external model.
 *
 * entropy-embed-h512: a signed feature-hashing embedding over word unigrams,
 * word bigrams and character trigrams with sublinear TF weighting and L2
 * normalisation. It is a lexical (not neural) embedding: strong for keyword and
 * phrase overlap, weaker for paraphrase. Swappable behind `embed()`.
 */

export const EMBED_DIM = 512;
export const EMBED_MODEL = "entropy-embed-h512";

const STOP = new Set(
  "a an the and or but if then else of to in on at by for with from as is are was were be been being it its this that these those i you he she we they me my your our their them his her not no do does did so than too very can will just into about over under also what which who whom how when where why there here have has had would should could may might must shall".split(" "),
);

export function words(text: string): string[] {
  return (text.toLowerCase().match(/[\p{L}\p{N}_]+/gu) ?? []).filter((w) => w.length > 1);
}

export function contentWords(text: string): string[] {
  return words(text).filter((w) => !STOP.has(w));
}

function hash(s: string, seed = 0x811c9dc5): number {
  let h = seed >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

export function embed(text: string): number[] {
  const v = new Float64Array(EMBED_DIM);
  const tf = new Map<string, number>();
  const add = (f: string, w: number) => tf.set(f, (tf.get(f) ?? 0) + w);
  const ws = contentWords(text);
  for (let i = 0; i < ws.length; i++) {
    add("w:" + ws[i], 1);
    if (i + 1 < ws.length) add("b:" + ws[i] + "_" + ws[i + 1], 0.7);
    const padded = `#${ws[i]}#`;
    for (let j = 0; j + 3 <= padded.length; j++) add("c:" + padded.slice(j, j + 3), 0.25);
  }
  for (const [f, c] of tf) {
    const h = hash(f);
    const sign = hash(f, 0x9747b28c) & 1 ? 1 : -1;
    v[h % EMBED_DIM] += sign * (1 + Math.log(c)) * (f.startsWith("c:") ? 0.25 : f.startsWith("b:") ? 0.7 : 1);
  }
  let n = 0;
  for (let i = 0; i < EMBED_DIM; i++) n += v[i] * v[i];
  n = Math.sqrt(n) || 1;
  return Array.from(v, (x) => Math.round((x / n) * 1e5) / 1e5);
}

export function cosine(a: number[], b: number[]): number {
  let s = 0;
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) s += a[i] * b[i];
  return s;
}

export function topK<T>(query: number[], items: T[], vec: (t: T) => number[], k: number, minScore = 0.05): { item: T; score: number }[] {
  return items
    .map((item) => ({ item, score: cosine(query, vec(item)) }))
    .filter((x) => x.score >= minScore)
    .sort((a, b) => b.score - a.score)
    .slice(0, k);
}

export function sentences(text: string): string[] {
  return text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?])\s+(?=[A-Z0-9"'(])/)
    .map((s) => s.trim())
    .filter((s) => s.length > 20);
}

/** Split text into ~maxChars chunks on paragraph/sentence boundaries with 1-sentence overlap. */
export function chunkText(text: string, maxChars = 700): string[] {
  const paras = text.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
  const chunks: string[] = [];
  let cur = "";
  let lastSentence = "";
  for (const para of paras) {
    const parts = para.length > maxChars ? sentences(para) : [para];
    for (const part of parts.length ? parts : [para]) {
      if (cur && cur.length + part.length + 1 > maxChars) {
        chunks.push(cur);
        cur = lastSentence ? lastSentence + " " : "";
      }
      cur += (cur && !cur.endsWith(" ") ? "\n" : "") + part;
      const ss = sentences(part);
      lastSentence = ss[ss.length - 1] ?? "";
    }
  }
  if (cur.trim()) chunks.push(cur.trim());
  return chunks.map((c) => c.slice(0, maxChars * 1.5));
}

export function keywords(text: string, k = 10): { term: string; score: number }[] {
  const sents = sentences(text);
  const docs = sents.length ? sents : [text];
  const df = new Map<string, number>();
  const tf = new Map<string, number>();
  for (const s of docs) {
    const ws = contentWords(s);
    for (const w of ws) tf.set(w, (tf.get(w) ?? 0) + 1);
    for (const w of new Set(ws)) df.set(w, (df.get(w) ?? 0) + 1);
  }
  return [...tf.entries()]
    .filter(([w]) => w.length > 2 && !/^\d+$/.test(w))
    .map(([term, f]) => ({ term, score: Math.round((1 + Math.log(f)) * Math.log(1 + docs.length / (df.get(term) ?? 1)) * 100) / 100 }))
    .sort((a, b) => b.score - a.score)
    .slice(0, k);
}

/** Extractive summary: centrality (similarity to other sentences) + keyword weight + position. */
export function summarize(text: string, n = 4, query?: string): string[] {
  const sents = sentences(text).slice(0, 400);
  if (sents.length <= n) return sents;
  const vecs = sents.map(embed);
  const q = query ? embed(query) : null;
  const kw = new Map(keywords(text, 25).map((k) => [k.term, k.score]));
  const scored = sents.map((s, i) => {
    let central = 0;
    for (let j = 0; j < sents.length; j++) if (j !== i) central += cosine(vecs[i], vecs[j]);
    central /= sents.length - 1;
    const kws = contentWords(s).reduce((a, w) => a + (kw.get(w) ?? 0), 0) / Math.max(4, contentWords(s).length);
    const pos = i < 3 ? 0.1 : 0;
    const rel = q ? cosine(q, vecs[i]) * 2 : 0;
    return { i, s, score: central + kws * 0.1 + pos + rel };
  });
  const picked: typeof scored = [];
  for (const c of scored.sort((a, b) => b.score - a.score)) {
    if (picked.some((p) => cosine(vecs[p.i], vecs[c.i]) > 0.6)) continue; // avoid redundancy
    picked.push(c);
    if (picked.length >= n) break;
  }
  return picked.sort((a, b) => a.i - b.i).map((p) => p.s);
}

export function analyzeDocument(name: string, content: string) {
  const ws = words(content);
  const lines = content.split("\n");
  const codeLike = /\.(ts|tsx|js|jsx|py|go|rs|java|c|cpp|h|rb|php|cs|swift|kt|sql|sh)$/i.test(name) || (content.match(/[{};]\s*$/gm)?.length ?? 0) > lines.length * 0.2;
  const functions = codeLike
    ? [...content.matchAll(/(?:function\s+([A-Za-z_$][\w$]*)|def\s+([A-Za-z_]\w*)|(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\(|class\s+([A-Za-z_]\w*))/g)]
        .map((m) => m[1] || m[2] || m[3] || m[4])
        .slice(0, 30)
    : [];
  return {
    kind: codeLike ? "code" : "text",
    characters: content.length,
    words: ws.length,
    lines: lines.length,
    sentences: sentences(content).length,
    readingMinutes: Math.max(1, Math.round(ws.length / 230)),
    uniqueWords: new Set(ws).size,
    keywords: keywords(content, 12),
    summary: codeLike ? [] : summarize(content, 5),
    symbols: functions,
    headings: lines.filter((l) => /^#{1,3}\s/.test(l)).map((l) => l.replace(/^#+\s*/, "")).slice(0, 20),
  };
}

export type DocumentAnalysis = ReturnType<typeof analyzeDocument>;
