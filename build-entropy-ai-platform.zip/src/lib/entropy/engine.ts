import { activeStage, loadCheckpoint, loadTokenizer, type CheckpointMeta } from "./checkpoint";
import type { GPT } from "./gpt";
import type { BPETokenizer } from "./tokenizer";

interface Loaded { model: GPT; meta: CheckpointMeta; loadedAt: number; stage: string }

const g = globalThis as typeof globalThis & { __entropyModels?: Map<string, Loaded>; __entropyTok?: BPETokenizer };

export function getTokenizer(): BPETokenizer {
  if (!g.__entropyTok) g.__entropyTok = loadTokenizer();
  return g.__entropyTok;
}

/** Load (and cache) the active checkpoint for a model. Reloads if the active stage changed. */
export function getEngine(modelId: string): Loaded {
  g.__entropyModels ??= new Map();
  const stage = activeStage(modelId);
  const cached = g.__entropyModels.get(modelId);
  if (cached && cached.stage === stage) return cached;
  const { model, meta } = loadCheckpoint(modelId);
  const loaded = { model, meta, loadedAt: Date.now(), stage: meta.stage };
  g.__entropyModels.set(modelId, loaded);
  return loaded;
}

export function loadedModels(): string[] {
  return [...(g.__entropyModels?.keys() ?? [])];
}
