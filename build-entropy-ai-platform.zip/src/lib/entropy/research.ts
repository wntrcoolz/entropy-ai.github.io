import { chunkText, contentWords, cosine, embed, sentences } from "./text";

export interface WebSource { title: string; url: string; text: string; provider: string }

const UA = "EntropyResearch/1.0 (Sequentia; open-source assistant)";

async function getJSON(url: string, ms = 8000): Promise<unknown> {
  const res = await fetch(url, { headers: { "User-Agent": UA, Accept: "application/json" }, signal: AbortSignal.timeout(ms) });
  if (!res.ok) throw new Error(`${new URL(url).hostname} responded ${res.status}`);
  return res.json();
}

function stripHtml(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<nav[\s\S]*?<\/nav>|<footer[\s\S]*?<\/footer>/gi, " ")
    .replace(/<\/(p|div|h\d|li|br)>/gi, "\n\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s*\n\s*(\n\s*)+/g, "\n\n")
    .trim();
}

async function wikipedia(query: string, limit: number): Promise<WebSource[]> {
  const q = contentWords(query).join(" ") || query;
  const url = `https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(q)}&gsrlimit=${limit}&prop=extracts|info&explaintext=1&exsentences=14&exlimit=max&inprop=url&format=json&origin=*`;
  const data = (await getJSON(url)) as { query?: { pages?: Record<string, { title: string; extract?: string; fullurl: string; index: number }> } };
  return Object.values(data.query?.pages ?? {})
    .sort((a, b) => a.index - b.index)
    .filter((p) => p.extract)
    .map((p) => ({ title: p.title + " - Wikipedia", url: p.fullurl, text: p.extract!, provider: "wikipedia" }));
}

async function duckduckgo(query: string): Promise<WebSource[]> {
  const data = (await getJSON(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`)) as {
    AbstractText?: string; AbstractURL?: string; Heading?: string; AbstractSource?: string;
  };
  if (!data.AbstractText || !data.AbstractURL) return [];
  return [{ title: `${data.Heading} - ${data.AbstractSource}`, url: data.AbstractURL, text: data.AbstractText, provider: "duckduckgo" }];
}

async function fetchPage(url: string): Promise<WebSource[]> {
  const res = await fetch(url, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(`${url} responded ${res.status}`);
  const html = (await res.text()).slice(0, 600_000);
  const title = html.match(/<title[^>]*>([^<]*)<\/title>/i)?.[1]?.trim() || url;
  return [{ title, url, text: stripHtml(html).slice(0, 30000), provider: "page" }];
}

/** Gather sources from the open web. Errors per provider are reported, never hidden. */
export async function searchWeb(query: string, limit = 4): Promise<{ sources: WebSource[]; errors: string[] }> {
  const urls = query.match(/https?:\/\/[^\s)]+/g) ?? [];
  const jobs: Promise<WebSource[]>[] = [...urls.slice(0, 3).map(fetchPage), wikipedia(query, limit), duckduckgo(query)];
  const settled = await Promise.allSettled(jobs);
  const sources: WebSource[] = [];
  const errors: string[] = [];
  for (const s of settled) {
    if (s.status === "fulfilled") sources.push(...s.value);
    else errors.push(String(s.reason instanceof Error ? s.reason.message : s.reason));
  }
  const seen = new Set<string>();
  return { sources: sources.filter((s) => (seen.has(s.url) ? false : (seen.add(s.url), true))), errors };
}

export interface Passage { title: string; url?: string; text: string; kind: "web" | "document"; score: number }

export function rankPassages(query: string, sources: { title: string; url?: string; text: string; kind: "web" | "document" }[], k: number): Passage[] {
  const q = embed(query);
  const all: Passage[] = [];
  for (const s of sources) for (const c of chunkText(s.text, 600)) all.push({ title: s.title, url: s.url, text: c, kind: s.kind, score: cosine(q, embed(c)) });
  return all.sort((a, b) => b.score - a.score).slice(0, k);
}

/** Extract the sentences from cited passages that best match the query; each keeps its citation number. */
export function extractEvidence(query: string, passages: { n: number; text: string }[], max = 4): { n: number; sentence: string }[] {
  const q = embed(query);
  const cands = passages.flatMap((p) => sentences(p.text).map((s) => ({ n: p.n, sentence: s, v: embed(s) })));
  const picked: typeof cands = [];
  for (const c of cands.map((c) => ({ ...c, score: cosine(q, c.v) })).sort((a, b) => b.score - a.score)) {
    if (c.score < 0.08) break;
    if (picked.some((p) => cosine(p.v, c.v) > 0.7)) continue;
    picked.push(c);
    if (picked.length >= max) break;
  }
  return picked.map(({ n, sentence }) => ({ n, sentence }));
}
