/**
 * Entropy Transformer: a decoder-only GPT-style language model implemented from
 * scratch in TypeScript (no ML framework). Includes the full forward pass,
 * hand-derived backward pass, and AdamW optimizer, so the model can be genuinely
 * pre-trained and fine-tuned. Architecture: learned token + position embeddings,
 * pre-LayerNorm blocks with causal multi-head self-attention and a GELU MLP,
 * final LayerNorm and an LM head tied to the token embedding.
 *
 * Weight layout follows [outFeatures, inFeatures] row-major matrices.
 */

export interface GPTConfig {
  vocabSize: number;
  ctx: number;
  dModel: number;
  nLayer: number;
  nHead: number;
  dFF: number;
}

export const PARAM_NAMES = [
  "wte", "wpe", "ln1w", "ln1b", "qkvw", "qkvb", "attprojw", "attprojb",
  "ln2w", "ln2b", "fcw", "fcb", "fcprojw", "fcprojb", "lnfw", "lnfb",
] as const;
export type ParamName = (typeof PARAM_NAMES)[number];
export type ParamViews = Record<ParamName, Float32Array>;

export function paramSizes(c: GPTConfig): Record<ParamName, number> {
  const { vocabSize: V, ctx: T, dModel: C, nLayer: L, dFF: F } = c;
  return {
    wte: V * C, wpe: T * C, ln1w: L * C, ln1b: L * C, qkvw: L * 3 * C * C, qkvb: L * 3 * C,
    attprojw: L * C * C, attprojb: L * C, ln2w: L * C, ln2b: L * C, fcw: L * F * C, fcb: L * F,
    fcprojw: L * C * F, fcprojb: L * C, lnfw: C, lnfb: C,
  };
}

export function countParams(c: GPTConfig): number {
  const s = paramSizes(c);
  return PARAM_NAMES.reduce((a, n) => a + s[n], 0);
}

export function makeViews(buf: Float32Array, c: GPTConfig): ParamViews {
  const sizes = paramSizes(c);
  const out = {} as ParamViews;
  let off = 0;
  for (const n of PARAM_NAMES) {
    out[n] = buf.subarray(off, off + sizes[n]);
    off += sizes[n];
  }
  return out;
}

/** Deterministic PRNG (mulberry32) so training runs are reproducible. */
export function rng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function gaussian(r: () => number): number {
  const u = Math.max(r(), 1e-12);
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * r());
}

// ---------------------------------------------------------------- kernels

export function encoderForward(out: Float32Array, inp: Int32Array, wte: Float32Array, wpe: Float32Array, B: number, T: number, C: number) {
  for (let b = 0; b < B; b++)
    for (let t = 0; t < T; t++) {
      const o = (b * T + t) * C, ix = inp[b * T + t] * C, p = t * C;
      for (let i = 0; i < C; i++) out[o + i] = wte[ix + i] + wpe[p + i];
    }
}

function encoderBackward(dwte: Float32Array, dwpe: Float32Array, dout: Float32Array, inp: Int32Array, B: number, T: number, C: number) {
  for (let b = 0; b < B; b++)
    for (let t = 0; t < T; t++) {
      const o = (b * T + t) * C, ix = inp[b * T + t] * C, p = t * C;
      for (let i = 0; i < C; i++) {
        const d = dout[o + i];
        dwte[ix + i] += d;
        dwpe[p + i] += d;
      }
    }
}

export function layernormForward(out: Float32Array, mean: Float32Array | null, rstd: Float32Array | null, inp: Float32Array, w: Float32Array, bias: Float32Array, N: number, C: number) {
  const eps = 1e-5;
  for (let n = 0; n < N; n++) {
    const o = n * C;
    let m = 0;
    for (let i = 0; i < C; i++) m += inp[o + i];
    m /= C;
    let v = 0;
    for (let i = 0; i < C; i++) { const x = inp[o + i] - m; v += x * x; }
    v /= C;
    const s = 1 / Math.sqrt(v + eps);
    for (let i = 0; i < C; i++) out[o + i] = (inp[o + i] - m) * s * w[i] + bias[i];
    if (mean) mean[n] = m;
    if (rstd) rstd[n] = s;
  }
}

function layernormBackward(dinp: Float32Array, dw: Float32Array, db: Float32Array, dout: Float32Array, inp: Float32Array, w: Float32Array, mean: Float32Array, rstd: Float32Array, N: number, C: number) {
  for (let n = 0; n < N; n++) {
    const o = n * C, m = mean[n], s = rstd[n];
    let dnormMean = 0, dnormNormMean = 0;
    for (let i = 0; i < C; i++) {
      const norm = (inp[o + i] - m) * s;
      const dnorm = w[i] * dout[o + i];
      dnormMean += dnorm;
      dnormNormMean += dnorm * norm;
    }
    dnormMean /= C;
    dnormNormMean /= C;
    for (let i = 0; i < C; i++) {
      const norm = (inp[o + i] - m) * s;
      const dnorm = w[i] * dout[o + i];
      db[i] += dout[o + i];
      dw[i] += norm * dout[o + i];
      dinp[o + i] += (dnorm - dnormMean - norm * dnormNormMean) * s;
    }
  }
}

/** out[N,OC] = inp[N,C] @ W[OC,C]^T + bias */
export function matmulForward(out: Float32Array, inp: Float32Array, w: Float32Array, bias: Float32Array | null, N: number, C: number, OC: number) {
  for (let n = 0; n < N; n++) {
    const io = n * C, oo = n * OC;
    for (let o = 0; o < OC; o++) {
      const wo = o * C;
      let v0 = 0, v1 = 0, v2 = 0, v3 = 0;
      let i = 0;
      for (; i + 3 < C; i += 4) {
        v0 += inp[io + i] * w[wo + i];
        v1 += inp[io + i + 1] * w[wo + i + 1];
        v2 += inp[io + i + 2] * w[wo + i + 2];
        v3 += inp[io + i + 3] * w[wo + i + 3];
      }
      for (; i < C; i++) v0 += inp[io + i] * w[wo + i];
      out[oo + o] = v0 + v1 + v2 + v3 + (bias ? bias[o] : 0);
    }
  }
}

function matmulBackward(dinp: Float32Array, dw: Float32Array, dbias: Float32Array | null, dout: Float32Array, inp: Float32Array, w: Float32Array, N: number, C: number, OC: number) {
  for (let n = 0; n < N; n++) {
    const io = n * C, oo = n * OC;
    for (let o = 0; o < OC; o++) {
      const d = dout[oo + o];
      if (d === 0) continue;
      const wo = o * C;
      for (let i = 0; i < C; i++) dinp[io + i] += w[wo + i] * d;
    }
  }
  for (let o = 0; o < OC; o++) {
    const wo = o * C;
    for (let n = 0; n < N; n++) {
      const d = dout[n * OC + o];
      if (d === 0) continue;
      if (dbias) dbias[o] += d;
      const io = n * C;
      for (let i = 0; i < C; i++) dw[wo + i] += inp[io + i] * d;
    }
  }
}

function attentionForward(out: Float32Array, att: Float32Array, qkv: Float32Array, B: number, T: number, C: number, NH: number) {
  const C3 = C * 3, hs = C / NH, scale = 1 / Math.sqrt(hs);
  for (let b = 0; b < B; b++)
    for (let t = 0; t < T; t++)
      for (let h = 0; h < NH; h++) {
        const q = b * T * C3 + t * C3 + h * hs;
        const a = ((b * NH + h) * T + t) * T;
        let max = -Infinity;
        for (let t2 = 0; t2 <= t; t2++) {
          const k = b * T * C3 + t2 * C3 + h * hs + C;
          let v = 0;
          for (let i = 0; i < hs; i++) v += qkv[q + i] * qkv[k + i];
          v *= scale;
          att[a + t2] = v;
          if (v > max) max = v;
        }
        let sum = 0;
        for (let t2 = 0; t2 <= t; t2++) { const e = Math.exp(att[a + t2] - max); att[a + t2] = e; sum += e; }
        const inv = 1 / sum;
        for (let t2 = 0; t2 < T; t2++) att[a + t2] = t2 <= t ? att[a + t2] * inv : 0;
        const o = b * T * C + t * C + h * hs;
        for (let i = 0; i < hs; i++) out[o + i] = 0;
        for (let t2 = 0; t2 <= t; t2++) {
          const vv = b * T * C3 + t2 * C3 + h * hs + 2 * C;
          const p = att[a + t2];
          for (let i = 0; i < hs; i++) out[o + i] += p * qkv[vv + i];
        }
      }
}

function attentionBackward(dqkv: Float32Array, datt: Float32Array, dout: Float32Array, qkv: Float32Array, att: Float32Array, B: number, T: number, C: number, NH: number) {
  const C3 = C * 3, hs = C / NH, scale = 1 / Math.sqrt(hs);
  for (let b = 0; b < B; b++)
    for (let t = 0; t < T; t++)
      for (let h = 0; h < NH; h++) {
        const a = ((b * NH + h) * T + t) * T;
        const q = b * T * C3 + t * C3 + h * hs;
        const o = b * T * C + t * C + h * hs;
        // through the weighted sum of values
        for (let t2 = 0; t2 <= t; t2++) {
          const vv = b * T * C3 + t2 * C3 + h * hs + 2 * C;
          let s = 0;
          const p = att[a + t2];
          for (let i = 0; i < hs; i++) {
            s += qkv[vv + i] * dout[o + i];
            dqkv[vv + i] += p * dout[o + i];
          }
          datt[a + t2] = s;
        }
        // through softmax: dpre = att * (datt - sum(att * datt))
        let dot = 0;
        for (let t2 = 0; t2 <= t; t2++) dot += att[a + t2] * datt[a + t2];
        for (let t2 = 0; t2 <= t; t2++) {
          const dpre = att[a + t2] * (datt[a + t2] - dot) * scale;
          if (dpre === 0) continue;
          const k = b * T * C3 + t2 * C3 + h * hs + C;
          for (let i = 0; i < hs; i++) {
            dqkv[q + i] += qkv[k + i] * dpre;
            dqkv[k + i] += qkv[q + i] * dpre;
          }
        }
      }
}

const GELU_S = Math.sqrt(2 / Math.PI);
export function geluForward(out: Float32Array, inp: Float32Array, N: number) {
  for (let i = 0; i < N; i++) {
    const x = inp[i];
    out[i] = 0.5 * x * (1 + Math.tanh(GELU_S * (x + 0.044715 * x * x * x)));
  }
}

function geluBackward(dinp: Float32Array, inp: Float32Array, dout: Float32Array, N: number) {
  for (let i = 0; i < N; i++) {
    const x = inp[i];
    const th = Math.tanh(GELU_S * (x + 0.044715 * x * x * x));
    const sech2 = 1 - th * th;
    const g = 0.5 * (1 + th) + x * 0.5 * sech2 * GELU_S * (1 + 3 * 0.044715 * x * x);
    dinp[i] += g * dout[i];
  }
}

function residualForward(out: Float32Array, a: Float32Array, b: Float32Array, N: number) {
  for (let i = 0; i < N; i++) out[i] = a[i] + b[i];
}

function residualBackward(da: Float32Array, db: Float32Array, dout: Float32Array, N: number) {
  for (let i = 0; i < N; i++) { da[i] += dout[i]; db[i] += dout[i]; }
}

// ---------------------------------------------------------------- model

interface Acts {
  B: number; T: number;
  encoded: Float32Array; ln1: Float32Array; ln1Mean: Float32Array; ln1Rstd: Float32Array;
  qkv: Float32Array; atty: Float32Array; att: Float32Array; attproj: Float32Array;
  residual2: Float32Array; ln2: Float32Array; ln2Mean: Float32Array; ln2Rstd: Float32Array;
  fch: Float32Array; fchGelu: Float32Array; fcproj: Float32Array; residual3: Float32Array;
  lnf: Float32Array; lnfMean: Float32Array; lnfRstd: Float32Array; logits: Float32Array;
}

function allocActs(c: GPTConfig, B: number, T: number): Acts {
  const { dModel: C, nLayer: L, nHead: NH, dFF: F, vocabSize: V } = c;
  const BT = B * T;
  const f = (n: number) => new Float32Array(n);
  return {
    B, T, encoded: f(BT * C), ln1: f(L * BT * C), ln1Mean: f(L * BT), ln1Rstd: f(L * BT),
    qkv: f(L * BT * 3 * C), atty: f(L * BT * C), att: f(L * B * NH * T * T), attproj: f(L * BT * C),
    residual2: f(L * BT * C), ln2: f(L * BT * C), ln2Mean: f(L * BT), ln2Rstd: f(L * BT),
    fch: f(L * BT * F), fchGelu: f(L * BT * F), fcproj: f(L * BT * C), residual3: f(L * BT * C),
    lnf: f(BT * C), lnfMean: f(BT), lnfRstd: f(BT), logits: f(BT * V),
  };
}

export interface StepOptions { lr: number; beta1?: number; beta2?: number; eps?: number; weightDecay?: number; clip?: number }

export class GPT {
  readonly config: GPTConfig;
  readonly params: Float32Array;
  readonly p: ParamViews;
  grads: Float32Array | null = null;
  private g: ParamViews | null = null;
  private m: Float32Array | null = null;
  private v: Float32Array | null = null;
  private stepCount = 0;
  private acts: Acts | null = null;
  private dacts: Acts | null = null;
  private inputs: Int32Array | null = null;
  private targets: Int32Array | null = null;
  private dlogitsScale = 0;

  constructor(config: GPTConfig, params?: Float32Array) {
    if (config.dModel % config.nHead !== 0) throw new Error("dModel must be divisible by nHead");
    this.config = config;
    const n = countParams(config);
    if (params && params.length !== n) throw new Error(`Checkpoint has ${params.length} params, config expects ${n}`);
    this.params = params ?? new Float32Array(n);
    this.p = makeViews(this.params, config);
  }

  static init(config: GPTConfig, seed = 1337): GPT {
    const model = new GPT(config);
    const r = rng(seed);
    const projStd = 0.02 / Math.sqrt(2 * config.nLayer);
    for (const name of PARAM_NAMES) {
      const arr = model.p[name];
      if (name === "ln1w" || name === "ln2w" || name === "lnfw") arr.fill(1);
      else if (name.endsWith("b") && name !== "wte") arr.fill(0);
      else {
        const std = name === "attprojw" || name === "fcprojw" ? projStd : 0.02;
        for (let i = 0; i < arr.length; i++) arr[i] = gaussian(r) * std;
      }
    }
    return model;
  }

  get numParams(): number { return this.params.length; }

  /**
   * Forward pass over a batch of B sequences of length T. When targets are given,
   * returns mean cross-entropy over positions whose target is >= 0 (-1 = masked).
   */
  forward(inputs: Int32Array, targets: Int32Array | null, B: number, T: number): number {
    const c = this.config;
    const { dModel: C, nLayer: L, nHead: NH, dFF: F, vocabSize: V } = c;
    if (T > c.ctx) throw new Error(`Sequence length ${T} exceeds context ${c.ctx}`);
    if (!this.acts || this.acts.B !== B || this.acts.T !== T) {
      this.acts = allocActs(c, B, T);
      this.dacts = null;
    }
    const a = this.acts, p = this.p, BT = B * T;
    this.inputs = inputs;
    this.targets = targets;
    encoderForward(a.encoded, inputs, p.wte, p.wpe, B, T, C);
    for (let l = 0; l < L; l++) {
      const residual = l === 0 ? a.encoded : a.residual3.subarray((l - 1) * BT * C, l * BT * C);
      const sl = (arr: Float32Array, per: number) => arr.subarray(l * per, (l + 1) * per);
      const ln1 = sl(a.ln1, BT * C), qkv = sl(a.qkv, BT * 3 * C), atty = sl(a.atty, BT * C);
      const att = sl(a.att, B * NH * T * T), attproj = sl(a.attproj, BT * C), res2 = sl(a.residual2, BT * C);
      const ln2 = sl(a.ln2, BT * C), fch = sl(a.fch, BT * F), fchG = sl(a.fchGelu, BT * F);
      const fcproj = sl(a.fcproj, BT * C), res3 = sl(a.residual3, BT * C);
      layernormForward(ln1, sl(a.ln1Mean, BT), sl(a.ln1Rstd, BT), residual, sl(p.ln1w, C), sl(p.ln1b, C), BT, C);
      matmulForward(qkv, ln1, sl(p.qkvw, 3 * C * C), sl(p.qkvb, 3 * C), BT, C, 3 * C);
      attentionForward(atty, att, qkv, B, T, C, NH);
      matmulForward(attproj, atty, sl(p.attprojw, C * C), sl(p.attprojb, C), BT, C, C);
      residualForward(res2, residual, attproj, BT * C);
      layernormForward(ln2, sl(a.ln2Mean, BT), sl(a.ln2Rstd, BT), res2, sl(p.ln2w, C), sl(p.ln2b, C), BT, C);
      matmulForward(fch, ln2, sl(p.fcw, F * C), sl(p.fcb, F), BT, C, F);
      geluForward(fchG, fch, BT * F);
      matmulForward(fcproj, fchG, sl(p.fcprojw, C * F), sl(p.fcprojb, C), BT, F, C);
      residualForward(res3, res2, fcproj, BT * C);
    }
    const last = L > 0 ? a.residual3.subarray((L - 1) * BT * C, L * BT * C) : a.encoded;
    layernormForward(a.lnf, a.lnfMean, a.lnfRstd, last, p.lnfw, p.lnfb, BT, C);
    matmulForward(a.logits, a.lnf, p.wte, null, BT, C, V);
    if (!targets) return NaN;
    // softmax in place (logits -> probs) + cross-entropy
    let loss = 0, count = 0;
    for (let n = 0; n < BT; n++) {
      const o = n * V;
      let max = -Infinity;
      for (let i = 0; i < V; i++) if (a.logits[o + i] > max) max = a.logits[o + i];
      let sum = 0;
      for (let i = 0; i < V; i++) { const e = Math.exp(a.logits[o + i] - max); a.logits[o + i] = e; sum += e; }
      for (let i = 0; i < V; i++) a.logits[o + i] /= sum;
      const tgt = targets[n];
      if (tgt >= 0) { loss -= Math.log(Math.max(a.logits[o + tgt], 1e-30)); count++; }
    }
    this.dlogitsScale = count > 0 ? 1 / count : 0;
    return count > 0 ? loss / count : 0;
  }

  /** Logits of the last forward pass (only meaningful when called without targets). */
  get lastLogits(): Float32Array | null { return this.acts?.logits ?? null; }

  zeroGrad() {
    if (!this.grads) {
      this.grads = new Float32Array(this.params.length);
      this.g = makeViews(this.grads, this.config);
    } else this.grads.fill(0);
  }

  backward() {
    const a = this.acts, inputs = this.inputs, targets = this.targets;
    if (!a || !inputs || !targets) throw new Error("forward() with targets must be called before backward()");
    if (!this.grads || !this.g) this.zeroGrad();
    const g = this.g!, p = this.p, c = this.config;
    const { dModel: C, nLayer: L, nHead: NH, dFF: F, vocabSize: V } = c;
    const { B, T } = a;
    const BT = B * T;
    if (!this.dacts || this.dacts.B !== B || this.dacts.T !== T) this.dacts = allocActs(c, B, T);
    const d = this.dacts;
    for (const k of Object.keys(d) as (keyof Acts)[]) { const x = d[k]; if (x instanceof Float32Array) x.fill(0); }
    // dlogits = (probs - onehot) / count
    for (let n = 0; n < BT; n++) {
      const tgt = targets[n], o = n * V;
      if (tgt < 0) continue;
      for (let i = 0; i < V; i++) d.logits[o + i] = (a.logits[o + i] - (i === tgt ? 1 : 0)) * this.dlogitsScale;
    }
    matmulBackward(d.lnf, g.wte, null, d.logits, a.lnf, p.wte, BT, C, V);
    const last = L > 0 ? a.residual3.subarray((L - 1) * BT * C, L * BT * C) : a.encoded;
    const dlast = L > 0 ? d.residual3.subarray((L - 1) * BT * C, L * BT * C) : d.encoded;
    layernormBackward(dlast, g.lnfw, g.lnfb, d.lnf, last, p.lnfw, a.lnfMean, a.lnfRstd, BT, C);
    for (let l = L - 1; l >= 0; l--) {
      const sl = (arr: Float32Array, per: number) => arr.subarray(l * per, (l + 1) * per);
      const residual = l === 0 ? a.encoded : a.residual3.subarray((l - 1) * BT * C, l * BT * C);
      const dresidual = l === 0 ? d.encoded : d.residual3.subarray((l - 1) * BT * C, l * BT * C);
      const dres3 = sl(d.residual3, BT * C), dres2 = sl(d.residual2, BT * C);
      residualBackward(dres2, sl(d.fcproj, BT * C), dres3, BT * C);
      matmulBackward(sl(d.fchGelu, BT * F), sl(g.fcprojw, C * F), sl(g.fcprojb, C), sl(d.fcproj, BT * C), sl(a.fchGelu, BT * F), sl(p.fcprojw, C * F), BT, F, C);
      geluBackward(sl(d.fch, BT * F), sl(a.fch, BT * F), sl(d.fchGelu, BT * F), BT * F);
      matmulBackward(sl(d.ln2, BT * C), sl(g.fcw, F * C), sl(g.fcb, F), sl(d.fch, BT * F), sl(a.ln2, BT * C), sl(p.fcw, F * C), BT, C, F);
      layernormBackward(dres2, sl(g.ln2w, C), sl(g.ln2b, C), sl(d.ln2, BT * C), sl(a.residual2, BT * C), sl(p.ln2w, C), sl(a.ln2Mean, BT), sl(a.ln2Rstd, BT), BT, C);
      residualBackward(dresidual, sl(d.attproj, BT * C), dres2, BT * C);
      matmulBackward(sl(d.atty, BT * C), sl(g.attprojw, C * C), sl(g.attprojb, C), sl(d.attproj, BT * C), sl(a.atty, BT * C), sl(p.attprojw, C * C), BT, C, C);
      attentionBackward(sl(d.qkv, BT * 3 * C), sl(d.att, B * NH * T * T), sl(d.atty, BT * C), sl(a.qkv, BT * 3 * C), sl(a.att, B * NH * T * T), B, T, C, NH);
      matmulBackward(sl(d.ln1, BT * C), sl(g.qkvw, 3 * C * C), sl(g.qkvb, 3 * C), sl(d.qkv, BT * 3 * C), sl(a.ln1, BT * C), sl(p.qkvw, 3 * C * C), BT, C, 3 * C);
      layernormBackward(dresidual, sl(g.ln1w, C), sl(g.ln1b, C), sl(d.ln1, BT * C), residual, sl(p.ln1w, C), sl(a.ln1Mean, BT), sl(a.ln1Rstd, BT), BT, C);
    }
    encoderBackward(g.wte, g.wpe, d.encoded, inputs, B, T, C);
  }

  /** AdamW update with global-norm gradient clipping. Returns the pre-clip grad norm. */
  step(opts: StepOptions): number {
    const grads = this.grads;
    if (!grads) throw new Error("No gradients");
    const { lr, beta1 = 0.9, beta2 = 0.95, eps = 1e-8, weightDecay = 0.01, clip = 1.0 } = opts;
    if (!this.m || !this.v) { this.m = new Float32Array(this.params.length); this.v = new Float32Array(this.params.length); }
    let norm = 0;
    for (let i = 0; i < grads.length; i++) norm += grads[i] * grads[i];
    norm = Math.sqrt(norm);
    const scale = clip > 0 && norm > clip ? clip / norm : 1;
    this.stepCount++;
    const bc1 = 1 - Math.pow(beta1, this.stepCount), bc2 = 1 - Math.pow(beta2, this.stepCount);
    const m = this.m, v = this.v, w = this.params;
    for (let i = 0; i < w.length; i++) {
      const gi = grads[i] * scale;
      m[i] = beta1 * m[i] + (1 - beta1) * gi;
      v[i] = beta2 * v[i] + (1 - beta2) * gi * gi;
      w[i] -= lr * ((m[i] / bc1) / (Math.sqrt(v[i] / bc2) + eps) + weightDecay * w[i]);
    }
    return norm;
  }
}
