import type { GPTConfig } from "./gpt";

export const VOCAB_SIZE = 1024;

export type ModelId = "gloss-1" | "distich-1" | "codex-1";
export type LevelId = "low" | "medium" | "high" | "extra" | "ultra";

export interface ModelSpec {
  id: ModelId;
  name: string;
  short: string;
  tagline: string;
  description: string;
  config: GPTConfig;
  /** Fraction of code in the pretraining mixture (Codex is code-heavy). */
  codeMix: number;
  train: { batch: number; seqLen: number; pretrainSteps: number; sftSteps: number; lr: number };
}

export const MODELS: ModelSpec[] = [
  {
    id: "gloss-1",
    name: "Entropy Gloss 1",
    short: "Gloss 1",
    tagline: "Fast and lightweight",
    description: "Best for everyday chatting",
    config: { vocabSize: VOCAB_SIZE, ctx: 256, dModel: 64, nLayer: 2, nHead: 4, dFF: 256 },
    codeMix: 0.15,
    train: { batch: 4, seqLen: 128, pretrainSteps: 1600, sftSteps: 900, lr: 3e-3 },
  },
  {
    id: "distich-1",
    name: "Entropy Distich 1",
    short: "Distich 1",
    tagline: "Balanced",
    description: "Best for balanced tasks",
    config: { vocabSize: VOCAB_SIZE, ctx: 256, dModel: 96, nLayer: 3, nHead: 4, dFF: 384 },
    codeMix: 0.25,
    train: { batch: 4, seqLen: 128, pretrainSteps: 900, sftSteps: 600, lr: 2e-3 },
  },
  {
    id: "codex-1",
    name: "Entropy Codex 1",
    short: "Codex 1",
    tagline: "Heavy tasks",
    description: "Best for heavy tasks and code, requires more time",
    config: { vocabSize: VOCAB_SIZE, ctx: 256, dModel: 128, nLayer: 4, nHead: 4, dFF: 512 },
    codeMix: 0.45,
    train: { batch: 4, seqLen: 128, pretrainSteps: 600, sftSteps: 500, lr: 1.5e-3 },
  },
];

export const COMING_MODELS = [
  { name: "Entropy Gloss 1.5", description: "Faster everyday model" },
  { name: "Entropy Distich 1.5", description: "Next balanced model" },
  { name: "Entropy Codex 1.5", description: "Next heavy-task model" },
  { name: "Entropy Muse 1", description: "Best overall" },
];

/**
 * The 50M-parameter research target. Same architecture and checkpoint format as
 * the shipped models; pretraining it needs GPU infrastructure (see research/).
 */
export const RESEARCH_50M: GPTConfig = { vocabSize: 16384, ctx: 1024, dModel: 512, nLayer: 13, nHead: 8, dFF: 2048 };

export interface LevelSpec {
  id: LevelId;
  label: string;
  maxNewTokens: number;
  candidates: number;
  temperature: number;
  topK: number;
  topP: number;
  retrievalDepth: number;
  description: string;
}

/**
 * Effort levels map to real inference compute: longer generation budgets,
 * more sampled candidates reranked by likelihood, and deeper retrieval.
 */
export const LEVELS: LevelSpec[] = [
  { id: "low", label: "Low", maxNewTokens: 48, candidates: 1, temperature: 0.6, topK: 20, topP: 0.9, retrievalDepth: 2, description: "Single sample, short answer" },
  { id: "medium", label: "Medium", maxNewTokens: 80, candidates: 1, temperature: 0.7, topK: 30, topP: 0.92, retrievalDepth: 3, description: "Single sample, standard budget" },
  { id: "high", label: "High", maxNewTokens: 112, candidates: 2, temperature: 0.75, topK: 40, topP: 0.94, retrievalDepth: 4, description: "Best of 2 candidates" },
  { id: "extra", label: "Extra High", maxNewTokens: 128, candidates: 3, temperature: 0.8, topK: 40, topP: 0.95, retrievalDepth: 5, description: "Best of 3, deeper retrieval" },
  { id: "ultra", label: "Ultra High", maxNewTokens: 128, candidates: 5, temperature: 0.85, topK: 50, topP: 0.96, retrievalDepth: 6, description: "Best of 5, deepest retrieval" },
];

export function getModel(id: string): ModelSpec | undefined {
  return MODELS.find((m) => m.id === id);
}

export function getLevel(id: string): LevelSpec {
  return LEVELS.find((l) => l.id === id) ?? LEVELS[1];
}

export const SYSTEM_PROMPT = "You are Entropy, an AI assistant made by Sequentia. Write clearly using standard English spelling and grammar. Answer directly and concisely. Do not repeat words, sentences, or ideas unnecessarily. If you are unsure, say so rather than inventing facts. Keep code valid and put code in fenced blocks.";
