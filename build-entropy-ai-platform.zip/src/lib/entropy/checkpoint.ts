import fs from "node:fs";
import path from "node:path";
import { GPT, type GPTConfig } from "./gpt";
import { BPETokenizer, type TokenizerJSON } from "./tokenizer";

export const CHECKPOINT_ROOT = process.env.ENTROPY_CHECKPOINT_DIR || path.join(process.cwd(), "checkpoints");

export type Stage = "pretrain" | "sft";

export interface CheckpointMeta {
  modelId: string;
  stage: Stage;
  config: GPTConfig;
  numParams: number;
  step: number;
  tokensSeen: number;
  trainSeconds: number;
  createdAt: string;
  parent?: string;
  history: { step: number; loss: number; lr: number }[];
  dataset: { name: string; tokens: number; sha?: string }[];
}

export function tokenizerPath() {
  return path.join(CHECKPOINT_ROOT, "tokenizer.json");
}

export function saveTokenizer(tok: BPETokenizer) {
  fs.mkdirSync(CHECKPOINT_ROOT, { recursive: true });
  fs.writeFileSync(tokenizerPath(), JSON.stringify(tok.toJSON()));
}

export function loadTokenizer(): BPETokenizer {
  const p = tokenizerPath();
  if (!fs.existsSync(p)) throw new Error(`Tokenizer not found at ${p}. Run "npm run data:prepare".`);
  return BPETokenizer.fromJSON(JSON.parse(fs.readFileSync(p, "utf8")) as TokenizerJSON);
}

function stageDir(modelId: string, stage: Stage) {
  return path.join(CHECKPOINT_ROOT, modelId, stage);
}

export function saveCheckpoint(model: GPT, meta: Omit<CheckpointMeta, "numParams" | "createdAt" | "config">) {
  const dir = stageDir(meta.modelId, meta.stage);
  fs.mkdirSync(dir, { recursive: true });
  const full: CheckpointMeta = { ...meta, config: model.config, numParams: model.numParams, createdAt: new Date().toISOString() };
  fs.writeFileSync(path.join(dir, "model.bin"), Buffer.from(model.params.buffer, model.params.byteOffset, model.params.byteLength));
  fs.writeFileSync(path.join(dir, "model.json"), JSON.stringify(full, null, 1));
  return full;
}

export function setActive(modelId: string, stage: Stage) {
  fs.writeFileSync(path.join(CHECKPOINT_ROOT, modelId, "ACTIVE"), stage);
}

export function activeStage(modelId: string): Stage | null {
  const f = path.join(CHECKPOINT_ROOT, modelId, "ACTIVE");
  if (fs.existsSync(f)) return fs.readFileSync(f, "utf8").trim() as Stage;
  for (const s of ["sft", "pretrain"] as Stage[]) if (fs.existsSync(path.join(stageDir(modelId, s), "model.bin"))) return s;
  return null;
}

export function readMeta(modelId: string, stage: Stage): CheckpointMeta | null {
  const f = path.join(stageDir(modelId, stage), "model.json");
  return fs.existsSync(f) ? (JSON.parse(fs.readFileSync(f, "utf8")) as CheckpointMeta) : null;
}

export function loadCheckpoint(modelId: string, stage?: Stage): { model: GPT; meta: CheckpointMeta } {
  const s = stage ?? activeStage(modelId);
  if (!s) throw new Error(`No checkpoint for ${modelId}. Run "npm run train:${modelId.split("-")[0]}".`);
  const meta = readMeta(modelId, s);
  const bin = path.join(stageDir(modelId, s), "model.bin");
  if (!meta || !fs.existsSync(bin)) throw new Error(`Checkpoint ${modelId}/${s} is incomplete.`);
  const buf = fs.readFileSync(bin);
  const params = new Float32Array(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
  return { model: new GPT(meta.config, params), meta };
}

export function listCheckpoints(modelId: string) {
  return (["pretrain", "sft"] as Stage[])
    .map((s) => {
      const meta = readMeta(modelId, s);
      if (!meta) return null;
      const bin = path.join(stageDir(modelId, s), "model.bin");
      return { stage: s, meta, bytes: fs.existsSync(bin) ? fs.statSync(bin).size : 0 };
    })
    .filter((x): x is NonNullable<typeof x> => x !== null);
}

export function readJSON<T>(rel: string): T | null {
  const f = path.join(process.cwd(), rel);
  return fs.existsSync(f) ? (JSON.parse(fs.readFileSync(f, "utf8")) as T) : null;
}
