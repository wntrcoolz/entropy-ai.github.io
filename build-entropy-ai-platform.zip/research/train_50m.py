"""
Entropy 50M pretraining (GPU). Same architecture as src/lib/entropy/gpt.ts:
pre-LN decoder, causal MHA with qkv bias, tanh-GELU MLP, tied LM head, LN eps 1e-5.
Exports checkpoints in Entropy's binary format (float32, PARAM_NAMES order,
[out, in] row-major, per-layer tensors concatenated) so the TypeScript runtime
can load them directly from checkpoints/<model-id>/<stage>/.

Requirements: python>=3.10, torch>=2.2, numpy. A single 24 GB GPU trains
~50M params on ~2-5B tokens in roughly 1-3 days; multi-GPU via torchrun works too.

Usage:
  npx tsx scripts/tokenize-large.ts --input corpus/ --vocab 16384 --out data/large
  python research/train_50m.py --data data/large/train.bin --model-id muse-1 --steps 100000
"""
import argparse, json, math, os, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

CFG = dict(vocabSize=16384, ctx=1024, dModel=512, nLayer=13, nHead=8, dFF=2048)


class Block(nn.Module):
    def __init__(s, c):
        super().__init__()
        C = c["dModel"]
        s.ln1, s.ln2 = nn.LayerNorm(C, eps=1e-5), nn.LayerNorm(C, eps=1e-5)
        s.qkv, s.proj = nn.Linear(C, 3 * C), nn.Linear(C, C)
        s.fc, s.fcproj = nn.Linear(C, c["dFF"]), nn.Linear(c["dFF"], C)
        s.nh = c["nHead"]

    def forward(s, x):
        B, T, C = x.shape
        q, k, v = s.qkv(s.ln1(x)).split(C, dim=2)
        q, k, v = (t.view(B, T, s.nh, C // s.nh).transpose(1, 2) for t in (q, k, v))
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True).transpose(1, 2).reshape(B, T, C)
        x = x + s.proj(y)
        return x + s.fcproj(F.gelu(s.fc(s.ln2(x)), approximate="tanh"))


class EntropyGPT(nn.Module):
    def __init__(s, c):
        super().__init__()
        s.c = c
        s.wte, s.wpe = nn.Embedding(c["vocabSize"], c["dModel"]), nn.Embedding(c["ctx"], c["dModel"])
        s.blocks = nn.ModuleList(Block(c) for _ in range(c["nLayer"]))
        s.lnf = nn.LayerNorm(c["dModel"], eps=1e-5)
        s.apply(s._init)
        for b in s.blocks:
            for w in (b.proj.weight, b.fcproj.weight):
                nn.init.normal_(w, std=0.02 / math.sqrt(2 * c["nLayer"]))

    def _init(s, m):
        if isinstance(m, (nn.Linear, nn.Embedding)):
            nn.init.normal_(m.weight, std=0.02)
        if isinstance(m, nn.Linear) and m.bias is not None:
            nn.init.zeros_(m.bias)

    def forward(s, idx, targets=None):
        x = s.wte(idx) + s.wpe(torch.arange(idx.size(1), device=idx.device))
        for b in s.blocks:
            x = b(x)
        logits = s.lnf(x) @ s.wte.weight.T
        loss = None if targets is None else F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1), ignore_index=-1)
        return logits, loss


def export(model, out_dir, meta):
    """Write model.bin/model.json in the exact layout of gpt.ts PARAM_NAMES."""
    os.makedirs(out_dir, exist_ok=True)
    B = model.blocks
    cat = lambda f: torch.cat([f(b).detach().float().reshape(-1).cpu() for b in B])
    tensors = [
        model.wte.weight, model.wpe.weight,
        cat(lambda b: b.ln1.weight), cat(lambda b: b.ln1.bias), cat(lambda b: b.qkv.weight), cat(lambda b: b.qkv.bias),
        cat(lambda b: b.proj.weight), cat(lambda b: b.proj.bias), cat(lambda b: b.ln2.weight), cat(lambda b: b.ln2.bias),
        cat(lambda b: b.fc.weight), cat(lambda b: b.fc.bias), cat(lambda b: b.fcproj.weight), cat(lambda b: b.fcproj.bias),
        model.lnf.weight, model.lnf.bias,
    ]
    flat = torch.cat([t.detach().float().reshape(-1).cpu() for t in tensors]).numpy().astype("<f4")
    flat.tofile(os.path.join(out_dir, "model.bin"))
    meta = dict(meta, config=model.c, numParams=int(flat.size), createdAt=time.strftime("%Y-%m-%dT%H:%M:%SZ"))
    json.dump(meta, open(os.path.join(out_dir, "model.json"), "w"), indent=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--model-id", default="muse-1")
    ap.add_argument("--steps", type=int, default=100000)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--lr", type=float, default=6e-4)
    ap.add_argument("--out", default="checkpoints")
    a = ap.parse_args()
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    if dev == "cpu":
        print("WARNING: no GPU found. 50M pretraining on CPU is impractically slow.")
    data = np.memmap(a.data, dtype=np.int32, mode="r")
    model = EntropyGPT(CFG).to(dev)
    print(f"params: {sum(p.numel() for p in model.parameters()):,}")
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.1)
    T, hist, t0 = CFG["ctx"], [], time.time()
    for step in range(a.steps):
        ix = np.random.randint(0, len(data) - T - 1, a.batch)
        x = torch.from_numpy(np.stack([data[i:i + T] for i in ix]).astype(np.int64)).to(dev)
        y = torch.from_numpy(np.stack([data[i + 1:i + T + 1] for i in ix]).astype(np.int64)).to(dev)
        lr = a.lr * min(1, (step + 1) / 2000) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * step / a.steps)))
        for g in opt.param_groups:
            g["lr"] = lr
        with torch.autocast(device_type=dev, dtype=torch.bfloat16, enabled=dev == "cuda"):
            _, loss = model(x, y)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        if step % 100 == 0:
            hist.append(dict(step=step, loss=round(loss.item(), 4), lr=lr))
            print(f"step {step} loss {loss.item():.4f}")
        if (step + 1) % 5000 == 0 or step == a.steps - 1:
            export(model, os.path.join(a.out, a.model_id, "pretrain"), dict(
                modelId=a.model_id, stage="pretrain", step=step + 1, tokensSeen=(step + 1) * a.batch * T,
                trainSeconds=int(time.time() - t0), history=hist, dataset=[dict(name=a.data, tokens=int(len(data)))]))


if __name__ == "__main__":
    main()
