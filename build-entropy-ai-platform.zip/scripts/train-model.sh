#!/usr/bin/env bash
# Full pipeline for one model: pretrain -> supervised fine-tune -> evaluate.
set -euo pipefail
MODEL="${1:?usage: scripts/train-model.sh gloss-1|distich-1|codex-1}"
npx tsx scripts/pretrain.ts --model "$MODEL"
npx tsx scripts/finetune.ts --model "$MODEL"
npx tsx scripts/evaluate.ts --model "$MODEL"
