/**
 * Download a small, reproducible English corpus from Project Gutenberg.
 * Text is public domain in the United States; check local copyright law before
 * redistributing elsewhere. The source and book ID are retained in each file.
 * No generated or model-written data is used.
 *
 * Usage: npx tsx scripts/fetch-corpus.ts
 */
import fs from "node:fs";
import path from "node:path";

const BOOKS = [
  { id: 1342, title: "Pride and Prejudice", author: "Jane Austen" },
  { id: 11, title: "Alice's Adventures in Wonderland", author: "Lewis Carroll" },
  { id: 1661, title: "The Adventures of Sherlock Holmes", author: "Arthur Conan Doyle" },
  { id: 84, title: "Frankenstein", author: "Mary Shelley" },
  { id: 98, title: "A Tale of Two Cities", author: "Charles Dickens" },
  { id: 74, title: "The Adventures of Tom Sawyer", author: "Mark Twain" },
  { id: 120, title: "Treasure Island", author: "Robert Louis Stevenson" },
  { id: 55, title: "The Wonderful Wizard of Oz", author: "L. Frank Baum" },
  { id: 345, title: "Around the World in Eighty Days", author: "Jules Verne" },
  { id: 2701, title: "Moby-Dick", author: "Herman Melville" },
  { id: 45, title: "Anne of Green Gables", author: "L. M. Montgomery" },
  { id: 514, title: "Little Women", author: "Louisa May Alcott" },
  { id: 35, title: "The Time Machine", author: "H. G. Wells" },
  { id: 46, title: "A Christmas Carol", author: "Charles Dickens" },
  { id: 113, title: "The Secret Garden", author: "Frances Hodgson Burnett" },
  { id: 43, title: "The Strange Case of Dr. Jekyll and Mr. Hyde", author: "Robert Louis Stevenson" },
  { id: 76, title: "Adventures of Huckleberry Finn", author: "Mark Twain" },
  { id: 174, title: "The Picture of Dorian Gray", author: "Oscar Wilde" },
];

const OUT = path.join(process.cwd(), "data/corpus/literature");
const UA = "Entropy-Sequentia/1.0 (research corpus; contact: sequentia)";
fs.mkdirSync(OUT, { recursive: true });

function clean(raw: string): string {
  let text = raw.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
  const start = text.search(/\*\*\*\s*START OF (?:THE|THIS) PROJECT GUTENBERG EBOOK[^\n]*\*\*\*/i);
  const endMatch = [...text.matchAll(/\*\*\*\s*END OF (?:THE|THIS) PROJECT GUTENBERG EBOOK[^\n]*\*\*\*/gi)].at(-1);
  if (start >= 0) text = text.slice(text.indexOf("\n", start) + 1);
  if (endMatch?.index !== undefined) text = text.slice(0, endMatch.index);
  // Gutenberg editions wrap prose to a fixed line width. Rejoin wrapped lines,
  // while retaining paragraph and chapter boundaries.
  const blocks = text.split(/\n\s*\n/);
  const out: string[] = [];
  for (const block of blocks) {
    const lines = block.split("\n").map((x) => x.trim()).filter(Boolean);
    if (!lines.length) continue;
    if (lines.length === 1) {
      out.push(lines[0]);
      continue;
    }
    let para = "";
    for (const line of lines) {
      if (!para) para = line;
      else if (para.endsWith("-")) para = para.slice(0, -1) + line;
      else para += " " + line;
    }
    out.push(para);
  }
  return out.join("\n\n").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").normalize("NFC").trim();
}

async function main() {
  let total = 0;
  const stats: { id: number; title: string; author: string; bytes: number; paragraphs: number; url: string; status: string }[] = [];
  for (const book of BOOKS) {
    const file = path.join(OUT, `${book.id}.txt`);
    const url = `https://www.gutenberg.org/cache/epub/${book.id}/pg${book.id}.txt`;
    if (!fs.existsSync(file) || fs.statSync(file).size < 5000) {
      process.stdout.write(`Downloading ${book.title} ... `);
      const res = await fetch(url, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(30000) });
      if (!res.ok) throw new Error(`${url} returned ${res.status}`);
      const body = await res.text();
      const cleaned = clean(body);
      if (cleaned.length < 5000) throw new Error(`Could not find book text in Gutenberg response for ${book.title}`);
      const header = `Source: Project Gutenberg ebook ${book.id}\nTitle: ${book.title}\nAuthor: ${book.author}\nURL: ${url}\nText is public domain in the United States; consult the Project Gutenberg license and local law.\n\n`;
      fs.writeFileSync(file, header + cleaned + "\n");
      process.stdout.write(`${(Buffer.byteLength(cleaned) / 1024).toFixed(0)} KB\n`);
    }
    const bytes = fs.statSync(file).size;
    total += bytes;
    const text = fs.readFileSync(file, "utf8");
    stats.push({ ...book, bytes, paragraphs: text.split(/\n\s*\n/).length, url, status: "downloaded and cleaned" });
  }
  fs.writeFileSync(path.join(OUT, "manifest.json"), JSON.stringify({ source: "Project Gutenberg", createdAt: new Date().toISOString(), books: stats, totalBytes: total, note: "Public domain in the United States; verify local jurisdiction. Original attribution and ebook IDs retained." }, null, 2));
  console.log(`Prepared ${BOOKS.length} books, ${(total / 1024 / 1024).toFixed(2)} MiB total at ${OUT}`);
}

main().catch((e) => { console.error(e); process.exitCode = 1; });
