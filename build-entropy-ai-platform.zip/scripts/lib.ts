import fs from "node:fs";
import path from "node:path";
import type { BPETokenizer } from "../src/lib/entropy/tokenizer";
import { SYSTEM_PROMPT } from "../src/lib/entropy/registry";

export const ROOT = process.cwd();
export const PROCESSED = path.join(ROOT, "data", "processed");

export interface Dialogue { messages: { role: "user" | "assistant" | "context"; content: string }[] }

export function arg(name: string, fallback?: string): string | undefined {
  const i = process.argv.indexOf("--" + name);
  return i >= 0 ? process.argv[i + 1] : fallback;
}

export function readJSONL(file: string): Dialogue[] {
  if (!fs.existsSync(file)) return [];
  return fs.readFileSync(file, "utf8").split("\n").filter((l) => l.trim()).map((l) => JSON.parse(l) as Dialogue);
}

/** Encode a dialogue in the exact chat format used at inference. Targets mask everything but assistant replies. */
export function encodeDialogue(tok: BPETokenizer, d: Dialogue): { ids: number[]; targets: number[] } {
  const ids: number[] = [tok.special("<|bos|>"), tok.special("<|system|>"), ...tok.encode(SYSTEM_PROMPT, false), tok.special("<|end|>")];
  const train: boolean[] = ids.map(() => false);
  for (const m of d.messages) {
    const open = tok.special(m.role === "user" ? "<|user|>" : m.role === "assistant" ? "<|assistant|>" : "<|context|>");
    const body = [...tok.encode(m.content, false), tok.special("<|end|>")];
    ids.push(open, ...body);
    train.push(false, ...body.map(() => m.role === "assistant"));
  }
  // targets[i] = ids[i+1] when that next token belongs to an assistant reply
  const targets = ids.map((_, i) => (i + 1 < ids.length && train[i + 1] ? ids[i + 1] : -1));
  return { ids, targets };
}

export function writeInt32(file: string, arr: number[]) {
  fs.writeFileSync(file, Buffer.from(Int32Array.from(arr).buffer));
}

export function readInt32(file: string): Int32Array {
  const b = fs.readFileSync(file);
  return new Int32Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength));
}

export function cosineLR(step: number, total: number, maxLR: number, warmup: number): number {
  if (step < warmup) return (maxLR * (step + 1)) / warmup;
  const p = (step - warmup) / Math.max(1, total - warmup);
  return maxLR * (0.1 + 0.9 * 0.5 * (1 + Math.cos(Math.PI * p)));
}

export function sha(text: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619) >>> 0;
  return h.toString(16).padStart(8, "0");
}

export function log(msg: string) {
  process.stdout.write(`[${new Date().toISOString().slice(11, 19)}] ${msg}\n`);
}
