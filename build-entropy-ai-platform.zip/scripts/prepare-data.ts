/**
 * Dataset preparation. Reads the hand-authored corpus, downloaded public-domain
 * literature and SFT examples; splits evaluation data; trains byte-BPE; writes
 * tokenized shards. Feedback is included only from its explicit consent export.
 */
import fs from "node:fs";
import path from "node:path";
import { BPETokenizer } from "../src/lib/entropy/tokenizer";
import { loadTokenizer, saveTokenizer, tokenizerPath } from "../src/lib/entropy/checkpoint";
import { VOCAB_SIZE } from "../src/lib/entropy/registry";
import { PROCESSED, ROOT, encodeDialogue, log, readJSONL, sha, writeInt32, type Dialogue } from "./lib";

const text = fs.readFileSync(path.join(ROOT, "data/corpus/general.txt"), "utf8").replace(/\r/g, "");
const code = fs.readFileSync(path.join(ROOT, "data/corpus/code.txt"), "utf8").replace(/\r/g, "");
const literatureDir = path.join(ROOT, "data/corpus/literature");
const books = fs.existsSync(literatureDir)
  ? fs.readdirSync(literatureDir).filter((f) => f.endsWith(".txt")).sort().map((name) => ({ name, content: fs.readFileSync(path.join(literatureDir, name), "utf8").replace(/\r/g, "") }))
  : [];
const textCorpus = [text, ...books.map((b) => b.content)].join("\n\n");
const dialogues = readJSONL(path.join(ROOT, "data/sft/dialogues.jsonl"));
const assistantExamples = readJSONL(path.join(ROOT, "data/sft/assistant_examples.jsonl"));
const curated = readJSONL(path.join(ROOT, "data/sft/feedback-curated.jsonl"));

// Keep held-out examples out of both training and augmentation. Memory notes
// are retrieved from PostgreSQL at inference; synthetic names are not training data.
const baseDialogues = [...dialogues, ...assistantExamples, ...curated];
const evalDialogues = baseDialogues.filter((_, i) => i % 10 === 7);
const evalSet = new Set(evalDialogues);
const trainDialogues: Dialogue[] = baseDialogues.filter((d) => !evalSet.has(d));
const allDialogues: Dialogue[] = baseDialogues;

const paragraphs = textCorpus.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
const evalParas = paragraphs.filter((_, i) => i % 10 === 7);
const trainParas = paragraphs.filter((_, i) => i % 10 !== 7);
const codeBlocks = code.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);

const chatText = allDialogues.map((d) => d.messages.map((m) => m.content).join("\n")).join("\n");
const tokText = [textCorpus, code, chatText].join("\n\n");
let tok: BPETokenizer;
if (fs.existsSync(tokenizerPath()) && !process.argv.includes("--retrain-tokenizer")) {
  tok = loadTokenizer();
  log("reusing existing tokenizer (pass --retrain-tokenizer when adding new vocabulary; retrain all checkpoints afterward)");
} else {
  log(`training byte-BPE tokenizer to ${VOCAB_SIZE} tokens on ${(tokText.length / 1e6).toFixed(2)} million characters`);
  tok = BPETokenizer.train(tokText, VOCAB_SIZE, (n) => n > 0 && n % 100 === 0 && log(`BPE merge ${n}`));
  saveTokenizer(tok);
}
log(`tokenizer vocab ${tok.vocabSize}; corpus ${books.length} books, ${(Buffer.byteLength(textCorpus) / 1024 / 1024).toFixed(2)} MiB prose`);

fs.mkdirSync(PROCESSED, { recursive: true });
const END = tok.special("<|end|>");
const stream = (docs: string[]) => docs.flatMap((d) => [...tok.encode(d, false), END]);
const chatStream = (ds: Dialogue[]) => ds.flatMap((d) => encodeDialogue(tok, d).ids);
const shards: Record<string, number[]> = {
  "text.train": stream(trainParas),
  "text.eval": stream(evalParas),
  "code.train": stream(codeBlocks),
  "chat.train": chatStream(trainDialogues),
  "chat.eval": chatStream(evalDialogues),
};
for (const [key, values] of Object.entries(shards)) writeInt32(path.join(PROCESSED, key + ".bin"), values);
fs.writeFileSync(path.join(PROCESSED, "sft.train.json"), JSON.stringify(trainDialogues.map((d) => encodeDialogue(tok, d))));
fs.writeFileSync(path.join(PROCESSED, "sft.eval.json"), JSON.stringify(evalDialogues.map((d) => encodeDialogue(tok, d))));

const stats = {
  createdAt: new Date().toISOString(),
  tokenizer: { type: "byte-bpe", vocabSize: tok.vocabSize, merges: tok.merges.length },
  sources: [
    { name: "general.txt", chars: text.length, sha: sha(text) },
    { name: "code.txt", chars: code.length, sha: sha(code) },
    { name: "Project Gutenberg public-domain books", books: books.length, chars: books.reduce((n, b) => n + b.content.length, 0), bytes: books.reduce((n, b) => n + Buffer.byteLength(b.content), 0) },
    { name: "dialogues.jsonl", dialogues: dialogues.length },
    { name: "assistant_examples.jsonl (human-authored)", dialogues: assistantExamples.length },
    { name: "feedback-curated.jsonl (consented)", dialogues: curated.length },
  ],
  shards: Object.fromEntries(Object.entries(shards).map(([key, values]) => [key, values.length])),
  sft: { train: trainDialogues.length, eval: evalDialogues.length },
  bytesPerToken: Math.round((Buffer.byteLength(tokText) / tok.encode(tokText, false).length) * 100) / 100,
};
fs.writeFileSync(path.join(PROCESSED, "stats.json"), JSON.stringify(stats, null, 1));
fs.mkdirSync(path.join(ROOT, "research"), { recursive: true });
fs.writeFileSync(path.join(ROOT, "research/dataset-stats.json"), JSON.stringify(stats, null, 1));
log(JSON.stringify(stats.shards));
