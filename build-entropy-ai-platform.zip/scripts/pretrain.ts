/**
 * Pretraining: next-token prediction over a mixture of prose, code and
 * chat-formatted text. Usage: tsx scripts/pretrain.ts --model gloss-1 [--steps 700] [--resume]
 */
import path from "node:path";
import { GPT, rng } from "../src/lib/entropy/gpt";
import { loadCheckpoint, loadTokenizer, saveCheckpoint, setActive } from "../src/lib/entropy/checkpoint";
import { getModel } from "../src/lib/entropy/registry";
import { PROCESSED, arg, cosineLR, log, readInt32 } from "./lib";

const spec = getModel(arg("model", "gloss-1")!);
if (!spec) throw new Error("Unknown model. Use gloss-1, distich-1 or codex-1");
const tok = loadTokenizer();
if (tok.vocabSize > spec.config.vocabSize) throw new Error("Tokenizer larger than model vocabulary");
const steps = Number(arg("steps", String(spec.train.pretrainSteps)));
const { batch: B, seqLen: T, lr } = spec.train;

const streams = {
  text: readInt32(path.join(PROCESSED, "text.train.bin")),
  code: readInt32(path.join(PROCESSED, "code.train.bin")),
  chat: readInt32(path.join(PROCESSED, "chat.train.bin")),
};
const mix = { code: spec.codeMix, chat: 0.05, text: 1 - spec.codeMix - 0.05 };

const resume = process.argv.includes("--resume");
const previous = resume ? loadCheckpoint(spec.id, "pretrain") : null;
const model = previous?.model ?? GPT.init(spec.config, 1337);
const stepOffset = previous?.meta.step ?? 0;
const tokenOffset = previous?.meta.tokensSeen ?? 0;
const timeOffset = previous?.meta.trainSeconds ?? 0;
log(`${spec.name}: ${model.numParams.toLocaleString()} params, B=${B} T=${T}, ${steps} steps${resume ? ` (continuing after step ${stepOffset})` : ""}, mix ${JSON.stringify(mix)}`);

const rand = rng(2024);
const inputs = new Int32Array(B * T), targets = new Int32Array(B * T);
function fillBatch() {
  for (let b = 0; b < B; b++) {
    const r = rand();
    const s = r < mix.code ? streams.code : r < mix.code + mix.chat ? streams.chat : streams.text;
    const start = Math.floor(rand() * Math.max(1, s.length - T - 1));
    for (let t = 0; t < T; t++) {
      inputs[b * T + t] = s[(start + t) % s.length];
      targets[b * T + t] = s[(start + t + 1) % s.length];
    }
  }
}

const history: { step: number; loss: number; lr: number }[] = [...(previous?.meta.history ?? [])];
const t0 = Date.now();
let ema = 0;
for (let step = 0; step < steps; step++) {
  fillBatch();
  const loss = model.forward(inputs, targets, B, T);
  model.zeroGrad();
  model.backward();
  const curLR = cosineLR(step, steps, lr, Math.min(50, steps / 10));
  model.step({ lr: curLR, weightDecay: 0.01 });
  ema = step === 0 ? loss : 0.9 * ema + 0.1 * loss;
  if (step % 10 === 0 || step === steps - 1) {
    history.push({ step: stepOffset + step, loss: Math.round(ema * 1e4) / 1e4, lr: curLR });
    const sec = (Date.now() - t0) / 1000;
    log(`step ${stepOffset + step}/${stepOffset + steps} loss ${loss.toFixed(4)} ema ${ema.toFixed(4)} lr ${curLR.toExponential(2)} ${Math.round(((step + 1) * B * T) / sec)} tok/s`);
  }
  if ((step > 0 && step % 200 === 0) || step === steps - 1) {
    saveCheckpoint(model, {
      modelId: spec.id, stage: "pretrain", step: stepOffset + step + 1, tokensSeen: tokenOffset + (step + 1) * B * T,
      trainSeconds: timeOffset + Math.round((Date.now() - t0) / 1000), history,
      dataset: Object.entries(streams).map(([name, s]) => ({ name, tokens: s.length })),
    });
  }
}
setActive(spec.id, "pretrain");
log(`done in ${Math.round((Date.now() - t0) / 1000)}s`);
