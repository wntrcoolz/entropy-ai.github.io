/**
 * Train a large-vocabulary BPE tokenizer and tokenize a directory of text files
 * for GPU pretraining (research/train_50m.py). Streams files to keep memory low.
 * Usage: tsx scripts/tokenize-large.ts --input corpus/ --vocab 16384 --out data/large [--sample-mb 50]
 */
import fs from "node:fs";
import path from "node:path";
import { BPETokenizer } from "../src/lib/entropy/tokenizer";
import { arg, log } from "./lib";

const input = arg("input");
const out = arg("out", "data/large")!;
const vocab = Number(arg("vocab", "16384"));
const sampleMB = Number(arg("sample-mb", "50"));
if (!input || !fs.existsSync(input)) throw new Error("--input <dir> with .txt files is required");
const files = fs.readdirSync(input).filter((f) => /\.(txt|md|jsonl)$/.test(f)).map((f) => path.join(input, f));
let sample = "";
for (const f of files) { if (sample.length > sampleMB * 1e6) break; sample += fs.readFileSync(f, "utf8").slice(0, 5e6) + "\n"; }
log(`training tokenizer (${vocab}) on ${(sample.length / 1e6).toFixed(1)} MB sample from ${files.length} files`);
const tok = BPETokenizer.train(sample, vocab, (n) => n % 1000 === 0 && log(`merge ${n}`));
fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, "tokenizer.json"), JSON.stringify(tok.toJSON()));
const fd = fs.openSync(path.join(out, "train.bin"), "w");
let total = 0;
const END = tok.special("<|end|>");
for (const f of files) {
  const ids = [...tok.encode(fs.readFileSync(f, "utf8"), false), END];
  fs.writeSync(fd, Buffer.from(Int32Array.from(ids).buffer));
  total += ids.length;
}
fs.closeSync(fd);
log(`wrote ${total.toLocaleString()} tokens to ${out}/train.bin`);
