/**
 * Supervised fine-tuning, separate from next-token pretraining.
 * Trains on assistant tokens only, uses a low learning rate, evaluates on held-out
 * dialogues during training, and restores the best held-out checkpoint to limit
 * catastrophic forgetting. `--resume` continues from the existing SFT checkpoint.
 */
import fs from "node:fs";
import path from "node:path";
import { rng } from "../src/lib/entropy/gpt";
import { loadCheckpoint, loadTokenizer, saveCheckpoint, setActive } from "../src/lib/entropy/checkpoint";
import { getModel } from "../src/lib/entropy/registry";
import { PROCESSED, arg, cosineLR, log } from "./lib";

interface Example { ids: number[]; targets: number[] }

const spec = getModel(arg("model", "gloss-1")!);
if (!spec) throw new Error("Unknown model");
const tok = loadTokenizer();
const PAD = tok.special("<|pad|>");
const steps = Number(arg("steps", String(spec.train.sftSteps)));
const { batch: B, seqLen: T } = spec.train;
// Smaller research models forget their language prior quickly; use a conservative step size.
const lr = spec.train.lr * 0.05;

const resumeSft = process.argv.includes("--resume");
const { model, meta } = loadCheckpoint(spec.id, resumeSft ? "sft" : "pretrain");
const stepOffset = resumeSft ? meta.step : 0;
const tokenOffset = resumeSft ? meta.tokensSeen : 0;
const timeOffset = resumeSft ? meta.trainSeconds : 0;
const examples = JSON.parse(fs.readFileSync(path.join(PROCESSED, "sft.train.json"), "utf8")) as Example[];
const validation = JSON.parse(fs.readFileSync(path.join(PROCESSED, "sft.eval.json"), "utf8")) as Example[];
if (examples.length === 0 || validation.length === 0) throw new Error("SFT train and held-out splits must both be non-empty");
log(`${spec.name} SFT ${resumeSft ? `continuing from SFT step ${meta.step}` : `from pretrain step ${meta.step}`}: ${examples.length} train, ${validation.length} held-out dialogues, ${steps} max steps, lr=${lr}`);

const rand = rng(77);
const inputs = new Int32Array(B * T), targets = new Int32Array(B * T);
const history: { step: number; loss: number; lr: number }[] = resumeSft ? [...meta.history] : [];
const t0 = Date.now();
let ema = 0, tokens = 0, bestStep = 0, bestTokens = 0, stale = 0;
let bestValidation = Infinity;
let bestParams = new Float32Array(model.params);

function validationLoss(): number {
  let lossSum = 0, targetCount = 0;
  for (const ex of validation) {
    const off = Math.max(0, ex.ids.length - model.config.ctx);
    const ids = ex.ids.slice(off);
    const ys = ex.targets.slice(off);
    if (!ids.length) continue;
    const n = ys.reduce((sum, y) => sum + (y >= 0 ? 1 : 0), 0);
    if (!n) continue;
    const loss = model.forward(Int32Array.from(ids), Int32Array.from(ys), 1, ids.length);
    lossSum += loss * n;
    targetCount += n;
  }
  return targetCount ? lossSum / targetCount : Infinity;
}

// The unmodified pretrained model is a candidate and serves as a safe fallback.
bestValidation = validationLoss();
log(`initial held-out assistant loss ${bestValidation.toFixed(4)}`);

const evalEvery = 100;
const patience = 5;
let stepsRun = 0;
for (let step = 0; step < steps; step++) {
  for (let b = 0; b < B; b++) {
    const ex = examples[Math.floor(rand() * examples.length)];
    const off = Math.max(0, ex.ids.length - T);
    for (let t = 0; t < T; t++) {
      const i = off + t;
      inputs[b * T + t] = i < ex.ids.length ? ex.ids[i] : PAD;
      targets[b * T + t] = i < ex.targets.length ? ex.targets[i] : -1;
    }
    tokens += Math.min(T, ex.ids.length);
  }
  const loss = model.forward(inputs, targets, B, T);
  model.zeroGrad();
  model.backward();
  const curLR = cosineLR(step, steps, lr, Math.min(20, Math.floor(steps / 10)));
  model.step({ lr: curLR, weightDecay: 0.0, clip: 1.0 });
  ema = step === 0 ? loss : 0.9 * ema + 0.1 * loss;
  stepsRun = step + 1;
  if (step % 10 === 0 || step === steps - 1) {
    history.push({ step: stepOffset + step, loss: Math.round(ema * 1e4) / 1e4, lr: curLR });
    log(`sft step ${stepOffset + step}/${stepOffset + steps} loss ${loss.toFixed(4)} ema ${ema.toFixed(4)}`);
  }
  if (stepsRun % evalEvery === 0 || stepsRun === steps) {
    const val = validationLoss();
    log(`held-out assistant loss ${val.toFixed(4)} at SFT step ${stepOffset + stepsRun}`);
    if (val < bestValidation) {
      bestValidation = val;
      bestParams = new Float32Array(model.params);
      bestStep = stepsRun;
      bestTokens = tokens;
      stale = 0;
    } else {
      stale++;
      if (stale >= patience) {
        log(`early stopping after ${stale} evaluations without improvement`);
        break;
      }
    }
  }
}

model.params.set(bestParams);
const chosenStep = stepOffset + bestStep;
const chosenTokens = tokenOffset + bestTokens;
const chosenHistory = history.filter((h) => h.step < chosenStep);
saveCheckpoint(model, {
  modelId: spec.id, stage: "sft", step: chosenStep, tokensSeen: chosenTokens,
  trainSeconds: timeOffset + Math.round((Date.now() - t0) / 1000),
  parent: `${meta.stage}@${meta.step}`, history: chosenHistory,
  dataset: [{ name: "sft.train", tokens: chosenTokens }],
});
setActive(spec.id, "sft");
log(`SFT saved best held-out loss ${bestValidation.toFixed(4)} at step ${chosenStep}; completed ${stepsRun} steps in ${Math.round((Date.now() - t0) / 1000)}s`);
