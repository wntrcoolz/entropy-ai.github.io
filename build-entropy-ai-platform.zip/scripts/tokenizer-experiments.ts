/**
 * Tokenizer experiments: train byte-level BPE at several vocabulary sizes and
 * measure compression (bytes per token) on held-out text and code, plus the
 * embedding-table cost each choice implies for each model width.
 */
import fs from "node:fs";
import path from "node:path";
import { BPETokenizer } from "../src/lib/entropy/tokenizer";
import { MODELS } from "../src/lib/entropy/registry";
import { ROOT, log } from "./lib";

const text = fs.readFileSync(path.join(ROOT, "data/corpus/general.txt"), "utf8");
const code = fs.readFileSync(path.join(ROOT, "data/corpus/code.txt"), "utf8");
const paras = text.split(/\n\s*\n/);
const train = paras.filter((_, i) => i % 5 !== 0).join("\n\n") + code.slice(0, Math.floor(code.length * 0.8));
const heldText = paras.filter((_, i) => i % 5 === 0).join("\n\n");
const heldCode = code.slice(Math.floor(code.length * 0.8));

const results = [384, 512, 768, 1024, 1536].map((vocab) => {
  const t0 = Date.now();
  const tok = BPETokenizer.train(train, vocab);
  const bpt = (s: string) => Math.round((Buffer.byteLength(s) / tok.encode(s, false).length) * 1000) / 1000;
  const r = {
    vocab: tok.vocabSize,
    trainMs: Date.now() - t0,
    bytesPerTokenText: bpt(heldText),
    bytesPerTokenCode: bpt(heldCode),
    embeddingParams: Object.fromEntries(MODELS.map((m) => [m.id, tok.vocabSize * m.config.dModel])),
  };
  log(JSON.stringify(r));
  return r;
});
fs.mkdirSync(path.join(ROOT, "research"), { recursive: true });
fs.writeFileSync(
  path.join(ROOT, "research/tokenizer-experiments.json"),
  JSON.stringify({ createdAt: new Date().toISOString(), note: "Higher bytes/token = better compression. 1024 chosen as the trade-off for the small models.", results }, null, 1),
);
