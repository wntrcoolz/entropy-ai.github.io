/**
 * Evaluation pipeline (separate from training): held-out perplexity and
 * next-token accuracy on prose and chat, plus a behavioural benchmark of
 * greedy generations scored by expected keywords.
 * Usage: tsx scripts/evaluate.ts [--model gloss-1|all]
 */
import fs from "node:fs";
import path from "node:path";
import { listCheckpoints, loadCheckpoint, loadTokenizer, CHECKPOINT_ROOT, type Stage } from "../src/lib/entropy/checkpoint";
import { generateCandidates } from "../src/lib/entropy/generate";
import { buildPrompt } from "../src/lib/entropy/context";
import { MODELS } from "../src/lib/entropy/registry";
import type { GPT } from "../src/lib/entropy/gpt";
import { PROCESSED, ROOT, arg, log, readInt32 } from "./lib";

export const BENCHMARK = [
  { category: "identity", prompt: "Who are you?", expect: ["entropy"] },
  { category: "identity", prompt: "Who made you?", expect: ["sequentia"] },
  { category: "identity", prompt: "what is your name", expect: ["entropy"] },
  { category: "knowledge", prompt: "At what temperature does water boil?", expect: ["hundred", "100"] },
  { category: "knowledge", prompt: "What is the capital of France?", expect: ["paris"] },
  { category: "knowledge", prompt: "How do plants make food?", expect: ["photosynthesis", "sunlight"] },
  { category: "concepts", prompt: "What is a transformer?", expect: ["attention"] },
  { category: "concepts", prompt: "What is an embedding?", expect: ["numbers", "vector"] },
  { category: "code", prompt: "Write a Python function to reverse a string", expect: ["def ", "[::-1]"] },
  { category: "code", prompt: "Write a JavaScript function to sum an array", expect: ["function", "reduce"] },
  { category: "memory", prompt: "What is my name?", memory: "The user's name is Priya.", expect: ["priya"] },
  { category: "honesty", prompt: "What is the latest news?", expect: ["web", "do not know", "search"] },
  { category: "grammar", prompt: "Correct this sentence: She don't likes apples.", expect: ["doesn't like"] },
  { category: "grammar", prompt: "Correct this sentence: Their going too school because they forgot there books.", expect: ["they're going to"] },
  { category: "grammar", prompt: "Correct this sentence: There is many reasons to learn.", expect: ["there are many"] },
  { category: "spelling", prompt: "How do I spell accommodate?", expect: ["accommodate"] },
  { category: "spelling", prompt: "How do I spell definitely?", expect: ["definitely"] },
  { category: "spelling", prompt: "How do I spell necessary?", expect: ["necessary"] },
  { category: "writing", prompt: "How can I make my writing clearer?", expect: ["main point", "specific words"] },
  { category: "writing", prompt: "How do I avoid repeating the same word?", expect: ["repeated word", "repetition"] },
];

function heldOut(model: GPT, data: Int32Array | { ids: number[]; targets: number[] }[], T: number) {
  let lossSum = 0, n = 0, correct = 0, total = 0;
  const windows: { inp: number[]; tgt: number[] }[] = [];
  if (data instanceof Int32Array) {
    for (let s = 0; s + T + 1 <= data.length; s += T) windows.push({ inp: Array.from(data.subarray(s, s + T)), tgt: Array.from(data.subarray(s + 1, s + T + 1)) });
  } else for (const ex of data) windows.push({ inp: ex.ids.slice(-T), tgt: ex.targets.slice(-T) });
  for (const w of windows) {
    const loss = model.forward(Int32Array.from(w.inp), Int32Array.from(w.tgt), 1, w.inp.length);
    const probs = model.lastLogits!, V = model.config.vocabSize;
    for (let t = 0; t < w.inp.length; t++) {
      if (w.tgt[t] < 0) continue;
      let best = 0;
      for (let i = 1; i < V; i++) if (probs[t * V + i] > probs[t * V + best]) best = i;
      if (best === w.tgt[t]) correct++;
      total++;
    }
    const k = w.tgt.filter((x) => x >= 0).length;
    lossSum += loss * k; n += k;
  }
  const loss = n ? lossSum / n : NaN;
  return { loss: Math.round(loss * 1e4) / 1e4, perplexity: Math.round(Math.exp(loss) * 100) / 100, accuracy: Math.round((correct / Math.max(1, total)) * 1e4) / 1e4, tokens: n };
}

function repeatedNgramCount(ids: number[], size: number): number {
  const seen = new Set<string>();
  let repeats = 0;
  for (let i = 0; i + size <= ids.length; i++) {
    const key = ids.slice(i, i + size).join(",");
    if (seen.has(key)) repeats++;
    else seen.add(key);
  }
  return repeats;
}

function main() {
  const tok = loadTokenizer();
  const which = arg("model", "all")!;
  const textEval = readInt32(path.join(PROCESSED, "text.eval.bin"));
  const chatEval = JSON.parse(fs.readFileSync(path.join(PROCESSED, "sft.eval.json"), "utf8"));
  const results: Record<string, unknown>[] = [];
  for (const spec of MODELS.filter((m) => which === "all" || m.id === which)) {
    for (const { stage } of listCheckpoints(spec.id)) {
      const { model, meta } = loadCheckpoint(spec.id, stage as Stage);
      const T = Math.min(128, model.config.ctx);
      const text = heldOut(model, textEval, T);
      const chat = heldOut(model, chatEval, model.config.ctx);
      const banned = new Set<number>(["<|pad|>", "<|bos|>", "<|system|>", "<|user|>", "<|context|>", "<|assistant|>"].map((s) => tok.special(s as never)));
      for (let i = tok.vocabSize; i < model.config.vocabSize; i++) banned.add(i);
      const bench = BENCHMARK.map((b) => {
        const p = buildPrompt(tok, { ctx: model.config.ctx, reserve: 64, history: [{ role: "user", content: b.prompt }], context: [], memories: b.memory ? [b.memory] : [] });
        const [c] = generateCandidates(model, p.tokens, 64, 1, new Set([tok.special("<|end|>")]), { temperature: 0, topK: 1, topP: 1, repetitionPenalty: 1.18, frequencyPenalty: 0.12, noRepeatNgramSize: 3 }, banned);
        const output = tok.decode(c.tokens);
        const pass = b.expect.some((e) => output.toLowerCase().includes(e.toLowerCase()));
        return { category: b.category, prompt: b.prompt, output, pass, repeatedTrigrams: repeatedNgramCount(c.tokens, 3) };
      });
      const repeatedOutputs = bench.filter((x) => x.repeatedTrigrams > 0).length;
      const r = {
        modelId: spec.id, stage, step: meta.step, numParams: meta.numParams, evaluatedAt: new Date().toISOString(),
        heldOutText: text, heldOutChat: chat,
        benchmark: { passed: bench.filter((x) => x.pass).length, total: bench.length, outputsWithRepeatedTrigrams: repeatedOutputs, totalRepeatedTrigrams: bench.reduce((sum, x) => sum + x.repeatedTrigrams, 0), cases: bench },
      };
      fs.writeFileSync(path.join(CHECKPOINT_ROOT, spec.id, stage, "eval.json"), JSON.stringify(r, null, 1));
      results.push(r);
      log(`${spec.id}/${stage}: text ppl ${text.perplexity} acc ${text.accuracy} | chat ppl ${chat.perplexity} | bench ${r.benchmark.passed}/${r.benchmark.total}`);
    }
  }
  fs.mkdirSync(path.join(ROOT, "research"), { recursive: true });
  fs.writeFileSync(path.join(ROOT, "research/eval-results.json"), JSON.stringify(results, null, 1));
}

main();
