# Entropy, by Sequentia

Entropy is an AI assistant that runs on **its own language models**. Sequentia built the tokenizer, the Transformer, the training, fine-tuning and evaluation pipelines, the embeddings, the retrieval and the app from scratch. No external AI model or AI API is called anywhere: no OpenAI, Anthropic, Google, Hugging Face models or browser speech/AI APIs.

This README describes what the code actually does today, including what it can't do yet.

---

## Honest status

| Area | Status |
| --- | --- |
| Transformer LLM (decoder-only, multi-head causal attention, GELU MLP, pre-LN, tied head) | **Works.** Pure TypeScript forward pass plus a hand-derived backward pass, verified against finite differences in `tests/gpt.test.ts` |
| Pretraining → SFT → evaluation | **Works on CPU** for the three shipped models (0.18M, 0.44M and 0.96M parameters). Training time depends on CPU; current defaults use the expanded corpus and longer runs |
| Streaming chat | **Works.** Real token-by-token decoding with a KV cache, streamed as NDJSON |
| Effort levels (Low to Ultra High) | **Works.** They change the generation budget, best-of-N candidate reranking by model likelihood, sampling and retrieval depth |
| Persistent conversations, incognito mode | **Works** (PostgreSQL). Incognito chats are never stored, never read or write memory, and never enter datasets |
| Long-term memory | **Works.** Notes are embedded and retrieved into the context. **This is not training**, and the UI says so |
| Document analysis | **Works** for text, Markdown, CSV, JSON, HTML and code: chunking, embeddings, statistics, TF-IDF keywords, extractive summary, symbol listing. **PDF and images are not supported yet** |
| Web research with citations | **Works.** Wikipedia and DuckDuckGo APIs plus direct URL fetching, passage ranking and numbered citations. Verbatim evidence sentences are labelled as extracted, not generated |
| Feedback | **Works.** Ratings plus an explicit consent checkbox. Only consented, positive turns are exported (`/api/feedback/export`) |
| Brain dashboard and Research track | **Works.** Live data from the checkpoints and the database |
| 50M-parameter model | **Not trained.** The config (`RESEARCH_50M`, 50.3M params) and a PyTorch GPU script (`research/train_50m.py`) that exports Entropy-format checkpoints are included. Pretraining it needs GPUs and billions of tokens |
| "Competes with Claude, ChatGPT and Gemini" | **No.** Those are frontier models with vastly larger architectures, datasets and GPU budgets. The shipped models are tiny (0.18M–0.96M parameters) and are trained on a small research corpus: about 8.9 MiB of cleaned public-domain literature, project-authored prose/code and a few hundred human-authored SFT examples. They produce real model output, but can still be wrong or garbled. The included 50M config is not pretrained. |
| iOS IPA | **Not produced here** (it needs macOS, Xcode and an Apple developer account). The app is an installable PWA on iPhone and iPad; see the Capacitor steps below |

Entropy never fabricates a reply. If a checkpoint is missing, retrieval fails, or the model ends its turn without text, the UI shows the real error or status.

---

## Quick start

```bash
cp .env.example .env              # set DATABASE_URL
npm install
npx drizzle-kit push              # create tables
npm test                          # gradient check, tokenizer, retrieval, context tests
npm run build && npm start        # http://localhost:3000
```

Trained checkpoints are committed under `checkpoints/`, so the app works right away. To reproduce the models from scratch:

```bash
npm run data:fetch                            # download/clean 18 Project Gutenberg books
npm run sft:prepare                           # regenerate 226 human-authored SFT examples
npm run data:prepare -- --retrain-tokenizer   # rebuild BPE + ~3.5M train tokens
npm run research:tokenizer                    # tokenizer experiments -> research/
npm run train:gloss                           # pretrain -> SFT -> eval (CPU; hardware-dependent)
npm run train:distich                         # CPU; hardware-dependent
npm run train:codex                           # CPU; hardware-dependent
```

For a second continued-pretraining round, after the first pretraining checkpoint exists, use `npm run pretrain -- --model gloss-1 --steps 300 --resume`. For a separate second SFT round, `npm run finetune -- --model gloss-1 --steps 100 --resume` continues from its SFT checkpoint. Always evaluate on held-out data afterward. Individual evaluation: `npm run eval -- --model all`.

The sampler also suppresses immediate duplicate tokens and repeated token trigrams and applies a modest recent-frequency penalty. This reduces exact loops; it does not guarantee grammatical or factually correct text.

## Architecture

```
src/lib/entropy/
  tokenizer.ts   byte-level BPE (training, encode/decode, streaming UTF-8 decoder, special tokens)
  gpt.ts         Transformer: params, forward, backward, AdamW, init
  generate.ts    KV-cache incremental decoding, temperature/top-k/top-p/repetition sampling, best-of-N
  context.ts     context window manager (system > current message > memory/RAG > history, newest first)
  text.ts        entropy-embed-h512 hashed embeddings, chunking, keywords, extractive summary, document analysis
  research.ts    web research (Wikipedia, DuckDuckGo, URL fetch), passage ranking, evidence extraction
  checkpoint.ts  stage-based checkpoints (pretrain/sft), ACTIVE pointer, metadata and loss history
  engine.ts      in-process model cache
  registry.ts    models, effort levels, 50M research config
scripts/         prepare-data, tokenizer-experiments, pretrain, finetune, evaluate, tokenize-large
research/        train_50m.py (GPU), dataset stats, tokenizer experiments, eval results
src/app/api/     chat (streaming), conversations, memories, documents, feedback (+ export), brain, health
```

**Chat format:** `<|bos|><|system|>…<|end|><|context|>memories and passages<|end|><|user|>…<|end|><|assistant|>…<|end|>`. SFT masks the loss to assistant tokens only.

**Models**

| Model | Layers | Width | Heads | Context | Params | Code mix |
| --- | --- | --- | --- | --- | --- | --- |
| Entropy Gloss 1 | 2 | 64 | 4 | 256 | 0.18M | 15% |
| Entropy Distich 1 | 3 | 96 | 4 | 256 | 0.44M | 25% |
| Entropy Codex 1 | 4 | 128 | 4 | 256 | 0.96M | 45% |
| 50M research target | 13 | 512 | 8 | 1024 | 50.3M | n/a (GPU) |

Coming later, with no date: Gloss 1.5, Distich 1.5, Codex 1.5 and Muse 1 (best overall).

**Feedback to dataset loop:** rate a response, then tick consent. Download `/api/feedback/export` to `data/sft/feedback-curated.jsonl`, review it by hand, then run `npm run data:prepare` and `npm run finetune`. Nothing reaches a model without this explicit offline step.

## Scaling to the 50M model (GPU)

1. Gather a licensed or public-domain corpus (for example FineWeb-Edu or The Stack subsets) into `corpus/*.txt`.
2. `npx tsx scripts/tokenize-large.ts --input corpus --vocab 16384 --out data/large`
3. `python research/train_50m.py --data data/large/train.bin --model-id muse-1` (1 to 3 days on one 24 GB GPU for a few billion tokens).
4. Copy `data/large/tokenizer.json` and `checkpoints/muse-1/` to the server, add the model to `registry.ts` and run `npm run eval`. CPU inference of 50M params in TypeScript is feasible but slow; for production, port `generate.ts` to WebGPU or WASM SIMD.

## Deployment

- **Any Node host (Docker, VM, Vercel Node runtime):** `npm run build && npm start`. You need `DATABASE_URL` and a readable `checkpoints/` directory (or `ENTROPY_CHECKPOINT_DIR`).
- **Tencent EdgeOne Pages:** import the repo as a Next.js project (build `npm run build`, output `.next`). API routes run as Node functions (`runtime = "nodejs"`), which inference needs because it reads checkpoints from disk. Point `DATABASE_URL` at a reachable PostgreSQL (for example TencentDB for PostgreSQL). The Edge (V8 isolate) runtime is not used, because it has no file system and its CPU limits are too tight for inference.
- **iPhone and iPad:** open the site in Safari and use Share → Add to Home Screen (standalone PWA). For a native IPA, on macOS run `npm i @capacitor/core @capacitor/cli @capacitor/ios && npx cap init Entropy com.sequentia.entropy && npx cap add ios`, set `server.url` in `capacitor.config.ts` to your deployed URL, then `npx cap open ios` and archive in Xcode.

## Tests

`npm test` runs:
- an analytic vs. numerical gradient check across every parameter tensor
- a check that training reduces loss
- a check that KV-cache decoding equals the full forward pass
- best-of-N budget limits, and the 50M parameter count
- BPE round-trip (including Unicode and special tokens), embedding ranking, chunking, extractive summary faithfulness, and the context-window budget
